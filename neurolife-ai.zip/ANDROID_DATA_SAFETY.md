# Android Data Safety Disclosure

This document outlines the data collection practices for NeuroLife AI on Google Play Store.

## Data Collection

### Device or Other IDs
- **Collected**: Yes
- **Purpose**: Advertising or Marketing (via Google AdMob)
- **Details**: Device identifiers are used to serve personalized ads and measure ad performance

### Usage Data
- **Collected**: Yes
- **Purpose**: Advertising or Marketing (via Google AdMob)
- **Details**: App usage patterns are tracked to optimize ad delivery and user experience

## Data Sharing

### Third-Party Services
- **Google AdMob**: Receives device IDs and usage data for ad serving and analytics
- **Google Analytics**: Receives aggregated usage data for app performance monitoring

## Data Retention

- Device IDs and usage data are retained for the duration of the app installation
- Data is deleted when the app is uninstalled or user clears app data

## User Controls

- Users can opt out of personalized ads in device settings (Android Settings > Google > Manage your Google Account > Data & Privacy)
- Users can clear app data at any time via Android Settings > Apps > NeuroLife AI > Storage > Clear Data

## Compliance

- This app complies with Google Play Store policies
- All data collection is disclosed in the app's Privacy Policy
- iOS App Tracking Transparency (ATT) is implemented for iOS users
- Google User Messaging Platform (UMP) consent is integrated for GDPR/CCPA compliance

## Contact

For questions about data practices, contact: [your-email@example.com]
