/**
 * AppContext — lightweight in-memory cache + helpers shared across screens.
 * All server data is fetched via tRPC hooks; this context holds UI state
 * (selected date, active filters, etc.) and auth-gated user info.
 */
import React, { createContext, useContext, useState } from "react";

interface AppContextValue {
  selectedDate: Date;
  setSelectedDate: (d: Date) => void;
}

const AppContext = createContext<AppContextValue>({
  selectedDate: new Date(),
  setSelectedDate: () => {},
});

export function AppProvider({ children }: { children: React.ReactNode }) {
  const [selectedDate, setSelectedDate] = useState(new Date());

  return (
    <AppContext.Provider value={{ selectedDate, setSelectedDate }}>
      {children}
    </AppContext.Provider>
  );
}

export function useAppContext() {
  return useContext(AppContext);
}
