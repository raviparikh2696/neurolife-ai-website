/**
 * AdMobProvider
 *
 * Wraps the app to:
 *  1. Initialize the Google Mobile Ads SDK on native platforms
 *  2. Load and show an App Open Ad on cold launch and every foreground resume
 *
 * All ad logic lives in useAppOpenAd().
 * On web the hook is a no-op (native module is stubbed in metro.config.js).
 */
import React from 'react';
import { useAppOpenAd } from '@/hooks/use-app-open-ad';

function AppOpenAdController() {
  // Mounting this component activates the App Open Ad lifecycle:
  //  - SDK init → load → show on first ready → re-show on foreground
  useAppOpenAd();
  return null;
}

export function AdMobProvider({ children }: { children: React.ReactNode }) {
  return (
    <>
      <AppOpenAdController />
      {children}
    </>
  );
}
