/**
 * Grocery Engine — Emoji dictionary, category mapping, and smart suggestion system.
 *
 * Every product added must display the correct emoji and appear in the correct category.
 * Unknown items fall back to 📦 Other.
 */

// ─── Category Definitions ────────────────────────────────────────────────────

export const GROCERY_CATEGORIES = {
  fruits:     { label: "Fruits",      icon: "🍎", color: "#EF4444" },
  vegetables: { label: "Vegetables",  icon: "🥦", color: "#22C55E" },
  dairy:      { label: "Dairy",       icon: "🥛", color: "#3B82F6" },
  meat:       { label: "Meat & Fish", icon: "🍗", color: "#F97316" },
  bakery:     { label: "Bakery",      icon: "🍞", color: "#EAB308" },
  pantry:     { label: "Pantry",      icon: "🛒", color: "#8B5CF6" },
  other:      { label: "Other",       icon: "📦", color: "#6B7280" },
} as const;

export type GroceryCategory = keyof typeof GROCERY_CATEGORIES;

// ─── Emoji Dictionary ────────────────────────────────────────────────────────

export interface GroceryEntry {
  name: string;
  emoji: string;
  category: GroceryCategory;
  aliases?: string[];
}

export const GROCERY_DICTIONARY: GroceryEntry[] = [
  // ── Fruits ──
  { name: "Apple",       emoji: "🍎", category: "fruits", aliases: ["apples", "red apple", "green apple"] },
  { name: "Banana",      emoji: "🍌", category: "fruits", aliases: ["bananas"] },
  { name: "Orange",      emoji: "🍊", category: "fruits", aliases: ["oranges", "tangerine", "mandarin"] },
  { name: "Grapes",      emoji: "🍇", category: "fruits", aliases: ["grape"] },
  { name: "Strawberry",  emoji: "🍓", category: "fruits", aliases: ["strawberries"] },
  { name: "Pineapple",   emoji: "🍍", category: "fruits", aliases: ["pineapples"] },
  { name: "Watermelon",  emoji: "🍉", category: "fruits", aliases: ["watermelons", "melon"] },
  { name: "Mango",       emoji: "🥭", category: "fruits", aliases: ["mangoes", "mangos"] },
  { name: "Peach",       emoji: "🍑", category: "fruits", aliases: ["peaches"] },
  { name: "Pear",        emoji: "🍐", category: "fruits", aliases: ["pears"] },
  { name: "Lemon",       emoji: "🍋", category: "fruits", aliases: ["lemons"] },
  { name: "Cherry",      emoji: "🍒", category: "fruits", aliases: ["cherries"] },
  { name: "Blueberry",   emoji: "🫐", category: "fruits", aliases: ["blueberries"] },
  { name: "Kiwi",        emoji: "🥝", category: "fruits", aliases: ["kiwis", "kiwifruit"] },
  { name: "Coconut",     emoji: "🥥", category: "fruits", aliases: ["coconuts"] },
  { name: "Avocado",     emoji: "🥑", category: "fruits", aliases: ["avocados"] },

  // ── Vegetables ──
  { name: "Carrot",      emoji: "🥕", category: "vegetables", aliases: ["carrots"] },
  { name: "Broccoli",    emoji: "🥦", category: "vegetables" },
  { name: "Corn",        emoji: "🌽", category: "vegetables", aliases: ["sweet corn", "corn on the cob"] },
  { name: "Cucumber",    emoji: "🥒", category: "vegetables", aliases: ["cucumbers"] },
  { name: "Eggplant",    emoji: "🍆", category: "vegetables", aliases: ["eggplants", "aubergine"] },
  { name: "Potato",      emoji: "🥔", category: "vegetables", aliases: ["potatoes"] },
  { name: "Tomato",      emoji: "🍅", category: "vegetables", aliases: ["tomatoes"] },
  { name: "Lettuce",     emoji: "🥬", category: "vegetables", aliases: ["salad", "romaine"] },
  { name: "Onion",       emoji: "🧅", category: "vegetables", aliases: ["onions", "red onion"] },
  { name: "Garlic",      emoji: "🧄", category: "vegetables", aliases: ["garlic cloves"] },
  { name: "Pepper",      emoji: "🫑", category: "vegetables", aliases: ["peppers", "bell pepper", "capsicum"] },
  { name: "Hot Pepper",  emoji: "🌶️", category: "vegetables", aliases: ["chili", "chilli", "jalapeno"] },
  { name: "Mushroom",    emoji: "🍄", category: "vegetables", aliases: ["mushrooms"] },
  { name: "Spinach",     emoji: "🥬", category: "vegetables" },
  { name: "Celery",      emoji: "🥬", category: "vegetables" },
  { name: "Beans",       emoji: "🫘", category: "vegetables", aliases: ["bean", "green beans"] },
  { name: "Peas",        emoji: "🫛", category: "vegetables", aliases: ["pea", "green peas"] },
  { name: "Ginger",      emoji: "🫚", category: "vegetables" },

  // ── Dairy ──
  { name: "Milk",        emoji: "🥛", category: "dairy", aliases: ["whole milk", "skim milk", "2% milk"] },
  { name: "Cheese",      emoji: "🧀", category: "dairy", aliases: ["cheddar", "mozzarella", "parmesan"] },
  { name: "Butter",      emoji: "🧈", category: "dairy" },
  { name: "Yogurt",      emoji: "🍨", category: "dairy", aliases: ["yoghurt", "greek yogurt"] },
  { name: "Ice Cream",   emoji: "🍦", category: "dairy", aliases: ["icecream"] },
  { name: "Cream",       emoji: "🥛", category: "dairy", aliases: ["heavy cream", "whipping cream", "sour cream"] },
  { name: "Egg",         emoji: "🥚", category: "dairy", aliases: ["eggs"] },

  // ── Meat & Fish ──
  { name: "Chicken",     emoji: "🍗", category: "meat", aliases: ["chicken breast", "chicken thigh", "chicken wings"] },
  { name: "Steak",       emoji: "🥩", category: "meat", aliases: ["beef", "beef steak", "ribeye"] },
  { name: "Fish",        emoji: "🐟", category: "meat", aliases: ["salmon", "tuna", "cod", "tilapia"] },
  { name: "Shrimp",      emoji: "🦐", category: "meat", aliases: ["shrimps", "prawns"] },
  { name: "Bacon",       emoji: "🥓", category: "meat" },
  { name: "Sausage",     emoji: "🌭", category: "meat", aliases: ["sausages", "hot dog"] },
  { name: "Turkey",      emoji: "🦃", category: "meat" },
  { name: "Pork",        emoji: "🥩", category: "meat", aliases: ["pork chop", "pork loin"] },
  { name: "Lamb",        emoji: "🥩", category: "meat", aliases: ["lamb chop"] },
  { name: "Crab",        emoji: "🦀", category: "meat" },
  { name: "Lobster",     emoji: "🦞", category: "meat" },

  // ── Bakery ──
  { name: "Bread",       emoji: "🍞", category: "bakery", aliases: ["loaf", "white bread", "wheat bread"] },
  { name: "Bagel",       emoji: "🥯", category: "bakery", aliases: ["bagels"] },
  { name: "Croissant",   emoji: "🥐", category: "bakery", aliases: ["croissants"] },
  { name: "Pretzel",     emoji: "🥨", category: "bakery", aliases: ["pretzels"] },
  { name: "Pancakes",    emoji: "🥞", category: "bakery", aliases: ["pancake", "pancake mix"] },
  { name: "Waffle",      emoji: "🧇", category: "bakery", aliases: ["waffles"] },
  { name: "Cake",        emoji: "🎂", category: "bakery", aliases: ["cakes"] },
  { name: "Cookie",      emoji: "🍪", category: "bakery", aliases: ["cookies", "biscuit", "biscuits"] },
  { name: "Donut",       emoji: "🍩", category: "bakery", aliases: ["donuts", "doughnut"] },
  { name: "Muffin",      emoji: "🧁", category: "bakery", aliases: ["muffins", "cupcake"] },
  { name: "Pie",         emoji: "🥧", category: "bakery", aliases: ["pies"] },
  { name: "Tortilla",    emoji: "🫓", category: "bakery", aliases: ["tortillas", "wrap", "wraps"] },

  // ── Pantry ──
  { name: "Salt",        emoji: "🧂", category: "pantry" },
  { name: "Honey",       emoji: "🍯", category: "pantry" },
  { name: "Olive Oil",   emoji: "🫒", category: "pantry", aliases: ["oil", "cooking oil", "vegetable oil"] },
  { name: "Peanut",      emoji: "🥜", category: "pantry", aliases: ["peanuts", "peanut butter"] },
  { name: "Rice",        emoji: "🍚", category: "pantry", aliases: ["white rice", "brown rice", "basmati"] },
  { name: "Pasta",       emoji: "🍝", category: "pantry", aliases: ["spaghetti", "penne", "noodles", "macaroni"] },
  { name: "Pizza",       emoji: "🍕", category: "pantry", aliases: ["frozen pizza"] },
  { name: "Burger",      emoji: "🍔", category: "pantry", aliases: ["hamburger", "burger buns"] },
  { name: "Sandwich",    emoji: "🥪", category: "pantry" },
  { name: "Sugar",       emoji: "🍬", category: "pantry", aliases: ["brown sugar", "powdered sugar"] },
  { name: "Flour",       emoji: "🌾", category: "pantry", aliases: ["all purpose flour", "wheat flour"] },
  { name: "Cereal",      emoji: "🥣", category: "pantry", aliases: ["cereals", "oats", "oatmeal", "granola"] },
  { name: "Coffee",      emoji: "☕", category: "pantry", aliases: ["coffee beans", "ground coffee", "instant coffee"] },
  { name: "Tea",         emoji: "🍵", category: "pantry", aliases: ["green tea", "black tea", "herbal tea"] },
  { name: "Juice",       emoji: "🧃", category: "pantry", aliases: ["orange juice", "apple juice", "grape juice"] },
  { name: "Water",       emoji: "💧", category: "pantry", aliases: ["bottled water", "sparkling water"] },
  { name: "Soda",        emoji: "🥤", category: "pantry", aliases: ["cola", "coke", "sprite", "soft drink"] },
  { name: "Ketchup",     emoji: "🍅", category: "pantry", aliases: ["tomato sauce", "tomato paste"] },
  { name: "Chocolate",   emoji: "🍫", category: "pantry", aliases: ["chocolates", "cocoa"] },
  { name: "Chips",       emoji: "🍟", category: "pantry", aliases: ["potato chips", "crisps", "fries"] },
  { name: "Popcorn",     emoji: "🍿", category: "pantry" },
  { name: "Nuts",        emoji: "🥜", category: "pantry", aliases: ["almonds", "cashews", "walnuts", "mixed nuts"] },
  { name: "Jam",         emoji: "🍓", category: "pantry", aliases: ["jelly", "marmalade", "preserves"] },
  { name: "Vinegar",     emoji: "🫗", category: "pantry", aliases: ["balsamic vinegar", "apple cider vinegar"] },
  { name: "Soy Sauce",   emoji: "🫗", category: "pantry", aliases: ["soya sauce"] },
  { name: "Mayonnaise",  emoji: "🫙", category: "pantry", aliases: ["mayo"] },
  { name: "Mustard",     emoji: "🟡", category: "pantry" },
];

// ─── Lookup Index (built once) ───────────────────────────────────────────────

const _lookupMap = new Map<string, GroceryEntry>();

function buildLookup() {
  if (_lookupMap.size > 0) return;
  for (const entry of GROCERY_DICTIONARY) {
    _lookupMap.set(entry.name.toLowerCase(), entry);
    if (entry.aliases) {
      for (const alias of entry.aliases) {
        _lookupMap.set(alias.toLowerCase(), entry);
      }
    }
  }
}

// ─── Auto-detect Category & Emoji ────────────────────────────────────────────

export interface GroceryMatch {
  name: string;
  emoji: string;
  category: GroceryCategory;
}

/**
 * Given a raw item name, find the best matching emoji and category.
 * Falls back to 📦 Other if no match.
 */
export function detectGrocery(rawName: string): GroceryMatch {
  buildLookup();
  const lower = rawName.trim().toLowerCase();

  // Exact match
  const exact = _lookupMap.get(lower);
  if (exact) return { name: exact.name, emoji: exact.emoji, category: exact.category };

  // Partial match — check if input contains or is contained by a dictionary key
  for (const [key, entry] of _lookupMap) {
    if (lower.includes(key) || key.includes(lower)) {
      return { name: rawName.trim(), emoji: entry.emoji, category: entry.category };
    }
  }

  // Fallback
  return { name: rawName.trim(), emoji: "📦", category: "other" };
}

/**
 * Get the emoji for an item name. Fast lookup.
 */
export function getEmoji(rawName: string): string {
  return detectGrocery(rawName).emoji;
}

/**
 * Get the category for an item name. Fast lookup.
 */
export function getCategory(rawName: string): GroceryCategory {
  return detectGrocery(rawName).category;
}

// ─── Smart Suggestions ───────────────────────────────────────────────────────

/**
 * Return matching suggestions as the user types.
 * Uses prefix + fuzzy matching. Returns up to `limit` results.
 */
export function getSuggestions(query: string, existingNames: string[], limit = 6): GroceryEntry[] {
  if (!query || query.length < 1) return [];
  buildLookup();
  const lower = query.toLowerCase();
  const existingSet = new Set(existingNames.map((n) => n.toLowerCase()));

  const results: GroceryEntry[] = [];
  const seen = new Set<string>();

  // 1. Prefix matches first (highest priority)
  for (const entry of GROCERY_DICTIONARY) {
    if (seen.has(entry.name.toLowerCase())) continue;
    if (existingSet.has(entry.name.toLowerCase())) continue;
    if (entry.name.toLowerCase().startsWith(lower)) {
      results.push(entry);
      seen.add(entry.name.toLowerCase());
    }
    if (results.length >= limit) return results;
  }

  // 2. Contains matches
  for (const entry of GROCERY_DICTIONARY) {
    if (seen.has(entry.name.toLowerCase())) continue;
    if (existingSet.has(entry.name.toLowerCase())) continue;
    if (entry.name.toLowerCase().includes(lower)) {
      results.push(entry);
      seen.add(entry.name.toLowerCase());
    }
    if (results.length >= limit) return results;
  }

  // 3. Alias matches
  for (const entry of GROCERY_DICTIONARY) {
    if (seen.has(entry.name.toLowerCase())) continue;
    if (existingSet.has(entry.name.toLowerCase())) continue;
    if (entry.aliases?.some((a) => a.toLowerCase().includes(lower) || lower.includes(a.toLowerCase()))) {
      results.push(entry);
      seen.add(entry.name.toLowerCase());
    }
    if (results.length >= limit) return results;
  }

  return results;
}

// ─── Popular Quick-Add Items ─────────────────────────────────────────────────

export const POPULAR_ITEMS: GroceryEntry[] = [
  GROCERY_DICTIONARY.find((e) => e.name === "Milk")!,
  GROCERY_DICTIONARY.find((e) => e.name === "Egg")!,
  GROCERY_DICTIONARY.find((e) => e.name === "Bread")!,
  GROCERY_DICTIONARY.find((e) => e.name === "Banana")!,
  GROCERY_DICTIONARY.find((e) => e.name === "Chicken")!,
  GROCERY_DICTIONARY.find((e) => e.name === "Apple")!,
  GROCERY_DICTIONARY.find((e) => e.name === "Butter")!,
  GROCERY_DICTIONARY.find((e) => e.name === "Rice")!,
  GROCERY_DICTIONARY.find((e) => e.name === "Tomato")!,
  GROCERY_DICTIONARY.find((e) => e.name === "Cheese")!,
  GROCERY_DICTIONARY.find((e) => e.name === "Pasta")!,
  GROCERY_DICTIONARY.find((e) => e.name === "Onion")!,
];

// ─── Category Display Order ──────────────────────────────────────────────────

export const CATEGORY_ORDER: GroceryCategory[] = [
  "fruits",
  "vegetables",
  "dairy",
  "meat",
  "bakery",
  "pantry",
  "other",
];
