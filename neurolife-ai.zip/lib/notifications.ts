import * as Notifications from "expo-notifications";
import { Platform } from "react-native";

// Configure notification handler (show alerts in foreground)
Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowAlert: true,
    shouldPlaySound: true,
    shouldSetBadge: true,
    shouldShowBanner: true,
    shouldShowList: true,
  }),
});

export async function requestNotificationPermissions(): Promise<boolean> {
  if (Platform.OS === "web") return false;

  if (Platform.OS === "android") {
    await Notifications.setNotificationChannelAsync("neurolife-reminders", {
      name: "NeuroLife Reminders",
      importance: Notifications.AndroidImportance.MAX,
      vibrationPattern: [0, 250, 250, 250],
      lightColor: "#6C63FF",
    });
    await Notifications.setNotificationChannelAsync("neurolife-daily", {
      name: "Daily Schedule",
      importance: Notifications.AndroidImportance.HIGH,
    });
  }

  const { status: existingStatus } = await Notifications.getPermissionsAsync();
  if (existingStatus === "granted") return true;

  const { status } = await Notifications.requestPermissionsAsync();
  return status === "granted";
}

export interface ReminderOptions {
  title: string;
  body: string;
  date: Date;
  data?: Record<string, unknown>;
}

/**
 * Schedule reminders at 60min, 30min, and 10min before the given date.
 * Returns an array of notification identifiers.
 */
export async function scheduleEventReminders(opts: ReminderOptions): Promise<string[]> {
  if (Platform.OS === "web") return [];

  const ids: string[] = [];
  const offsets = [60, 30, 10]; // minutes before

  for (const minutes of offsets) {
    const triggerDate = new Date(opts.date.getTime() - minutes * 60 * 1000);
    if (triggerDate <= new Date()) continue; // skip past dates

    const id = await Notifications.scheduleNotificationAsync({
      content: {
        title: opts.title,
        body: `${opts.body} — in ${minutes} minute${minutes > 1 ? "s" : ""}`,
        data: opts.data ?? {},
        sound: true,
      },
      trigger: {
        type: Notifications.SchedulableTriggerInputTypes.DATE,
        date: triggerDate,
      },
    });
    ids.push(id);
  }

  return ids;
}

/**
 * Schedule a single reminder at the exact date.
 */
export async function scheduleReminder(opts: ReminderOptions): Promise<string | null> {
  if (Platform.OS === "web") return null;
  if (opts.date <= new Date()) return null;

  const id = await Notifications.scheduleNotificationAsync({
    content: {
      title: opts.title,
      body: opts.body,
      data: opts.data ?? {},
      sound: true,
    },
    trigger: {
      type: Notifications.SchedulableTriggerInputTypes.DATE,
      date: opts.date,
    },
  });
  return id;
}

/**
 * Schedule daily morning schedule notification at 8:00 AM.
 */
export async function scheduleDailyMorningBriefing(): Promise<void> {
  if (Platform.OS === "web") return;

  // Cancel existing daily briefing first
  const scheduled = await Notifications.getAllScheduledNotificationsAsync();
  for (const n of scheduled) {
    if (n.content.data?.type === "daily_briefing") {
      await Notifications.cancelScheduledNotificationAsync(n.identifier);
    }
  }

  await Notifications.scheduleNotificationAsync({
    content: {
      title: "Good morning! ☀️",
      body: "Your daily schedule is ready. Tap to view today's plan.",
      data: { type: "daily_briefing" },
      sound: true,
    },
    trigger: {
      type: Notifications.SchedulableTriggerInputTypes.CALENDAR,
      hour: 8,
      minute: 0,
      repeats: true,
    },
  });
}

/**
 * Schedule evening reminder for unfinished tasks at 8:00 PM.
 */
export async function scheduleEveningReminder(): Promise<void> {
  if (Platform.OS === "web") return;

  const scheduled = await Notifications.getAllScheduledNotificationsAsync();
  for (const n of scheduled) {
    if (n.content.data?.type === "evening_reminder") {
      await Notifications.cancelScheduledNotificationAsync(n.identifier);
    }
  }

  await Notifications.scheduleNotificationAsync({
    content: {
      title: "Evening check-in 🌙",
      body: "You have unfinished tasks. Review your day before it ends.",
      data: { type: "evening_reminder" },
      sound: true,
    },
    trigger: {
      type: Notifications.SchedulableTriggerInputTypes.CALENDAR,
      hour: 20,
      minute: 0,
      repeats: true,
    },
  });
}

export async function cancelNotifications(ids: string[]): Promise<void> {
  await Promise.all(ids.map((id) => Notifications.cancelScheduledNotificationAsync(id)));
}
