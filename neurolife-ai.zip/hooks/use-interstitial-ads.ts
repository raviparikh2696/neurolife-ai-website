import { useEffect, useRef, useCallback, useState } from 'react';
import { Platform } from 'react-native';
import { useAuth } from './use-auth';

let InterstitialAd: any = null;
let AdEventType: any = null;

if (Platform.OS !== 'web') {
  try {
    const module = require('react-native-google-mobile-ads');
    InterstitialAd = module.InterstitialAd;
    AdEventType = module.AdEventType;
  } catch (error) {
    console.warn('[AdMob] Failed to load interstitial ad module:', error);
  }
}

const INTERSTITIAL_AD_UNIT_ID = 'ca-app-pub-1720679341163644/8564987627';

/**
 * Hook to manage interstitial ads
 * - Loads ads only after user authentication
 * - Shows ads at natural transition points
 * - Auto-preloads next ad after showing
 * - Provides error handling and logging
 */
export function useInterstitialAds() {
  const { isAuthenticated } = useAuth();
  const adRef = useRef<any>(null);
  const [isAdLoaded, setIsAdLoaded] = useState(false);
  const [isAdLoading, setIsAdLoading] = useState(false);
  const loadAttemptRef = useRef(0);
  const MAX_LOAD_ATTEMPTS = 3;

  // Load interstitial ad
  const loadInterstitialAd = useCallback(async () => {
    // Skip on web platform
    if (Platform.OS === 'web' || !InterstitialAd || !AdEventType) {
      return;
    }

    // Prevent infinite retry loops
    if (loadAttemptRef.current >= MAX_LOAD_ATTEMPTS) {
      console.log('[AdMob] Max load attempts reached, skipping ad load');
      return;
    }

    try {
      setIsAdLoading(true);
      loadAttemptRef.current += 1;

      // Create new interstitial ad instance
      const interstitialAd = InterstitialAd.createForAdRequest(INTERSTITIAL_AD_UNIT_ID, {
        keywords: ['productivity', 'task', 'organizer', 'planner'],
      });

      // Handle ad loaded event
      const unsubscribeLoaded = interstitialAd.addAdEventListener(AdEventType.LOADED, () => {
        console.log('[AdMob] Interstitial ad loaded successfully');
        setIsAdLoaded(true);
        setIsAdLoading(false);
        loadAttemptRef.current = 0; // Reset attempts on success
      });

      // Handle ad closed event (user dismissed ad)
      const unsubscribeClosed = interstitialAd.addAdEventListener(AdEventType.CLOSED, () => {
        console.log('[AdMob] Interstitial ad closed, preloading next ad');
        setIsAdLoaded(false);
        adRef.current = null;
        // Preload next ad after a short delay
        setTimeout(() => loadInterstitialAd(), 1000);
      });

      // Handle ad failed to load event
      const unsubscribeFailed = interstitialAd.addAdEventListener(AdEventType.ERROR, (error: any) => {
        console.warn('[AdMob] Interstitial ad failed to load:', error);
        setIsAdLoaded(false);
        setIsAdLoading(false);
        // Retry after exponential backoff
        const retryDelay = Math.min(1000 * Math.pow(2, loadAttemptRef.current), 10000);
        setTimeout(() => loadInterstitialAd(), retryDelay);
      });

      // Store ad instance and unsubscribe functions
      adRef.current = interstitialAd;

      // Load the ad
      await interstitialAd.load();

      // Return cleanup function
      return () => {
        unsubscribeLoaded();
        unsubscribeClosed();
        unsubscribeFailed();
      };
    } catch (error: any) {
      console.error('[AdMob] Error loading interstitial ad:', error);
      setIsAdLoading(false);
    }
  }, []);

  // Auto-load ad after authentication
  useEffect(() => {
    if (isAuthenticated && !isAdLoading && !isAdLoaded) {
      loadInterstitialAd();
    }
  }, [isAuthenticated, isAdLoading, isAdLoaded, loadInterstitialAd]);

  // Show interstitial ad
  const showInterstitialAd = useCallback(async () => {
    if (Platform.OS === 'web' || !adRef.current) {
      console.log('[AdMob] Ad not available or on web platform');
      return;
    }

    try {
      if (isAdLoaded && adRef.current) {
        console.log('[AdMob] Showing interstitial ad');
        await adRef.current.show();
      }
    } catch (error: any) {
      console.error('[AdMob] Error showing interstitial ad:', error);
    }
  }, [isAdLoaded]);

  return {
    isAdLoaded,
    isAdLoading,
    showInterstitialAd,
    loadInterstitialAd,
  };
}
