/**
 * useAppOpenAd — App Open Ad hook for NeuroLife AI
 *
 * Follows Google AdMob App Open Ad best practices:
 *  - Shows on cold launch (first mount) and every time the app returns to foreground
 *  - Enforces a 4-hour cooldown between shows (AdMob policy: don't over-serve)
 *  - Never shows on web (native-only module)
 *  - Never shows while another ad is already visible
 *  - Loads the next ad immediately after the current one is dismissed
 *
 * Platform-specific Ad Unit IDs:
 *  - Android: ca-app-pub-1720679341163644/8260086478
 *  - iOS:     ca-app-pub-1720679341163644/2465205443
 */

import { useEffect, useRef, useCallback } from 'react';
import { AppState, AppStateStatus, Platform } from 'react-native';

// ─── Native module guard ──────────────────────────────────────────────────────
// Only load on Android or iOS — not on web.
let AppOpenAd: any = null;
let AdEventType: any = null;
let MobileAds: any = null;

if (Platform.OS === 'android' || Platform.OS === 'ios') {
  try {
    const module = require('react-native-google-mobile-ads');
    AppOpenAd = module.AppOpenAd;
    AdEventType = module.AdEventType;
    MobileAds = module.default;
  } catch (e) {
    console.warn('[AppOpenAd] Failed to load react-native-google-mobile-ads:', e);
  }
}

// ─── Platform-specific Ad Unit IDs ───────────────────────────────────────────
const APP_OPEN_AD_UNIT_ID = Platform.select({
  android: 'ca-app-pub-1720679341163644/8260086478',
  ios: 'ca-app-pub-1720679341163644/2465205443',
  default: '',
});

/**
 * Minimum time (ms) between two consecutive ad shows.
 * Google recommends not showing app open ads more than once every 4 hours.
 */
const MIN_SHOW_INTERVAL_MS = 4 * 60 * 60 * 1000; // 4 hours

// ─── Hook ─────────────────────────────────────────────────────────────────────
export function useAppOpenAd() {
  const adRef = useRef<any>(null);
  const isLoadedRef = useRef(false);
  const isShowingRef = useRef(false);
  const lastShownAtRef = useRef<number>(0);
  const isLoadingRef = useRef(false);
  const cleanupRef = useRef<(() => void) | null>(null);

  // ── Load ad ────────────────────────────────────────────────────────────────
  const loadAd = useCallback(() => {
    if (Platform.OS === 'web' || !AppOpenAd || !AdEventType || !APP_OPEN_AD_UNIT_ID) return;
    if (isLoadingRef.current || isLoadedRef.current) return;

    try {
      isLoadingRef.current = true;

      // Clean up previous listeners if any
      if (cleanupRef.current) {
        cleanupRef.current();
        cleanupRef.current = null;
      }

      const ad = AppOpenAd.createForAdRequest(APP_OPEN_AD_UNIT_ID, {
        keywords: ['productivity', 'task management', 'organizer', 'planner', 'calendar'],
        requestNonPersonalizedAdsOnly: false,
      });

      const unsubLoaded = ad.addAdEventListener(AdEventType.LOADED, () => {
        console.log('[AppOpenAd] Ad loaded successfully');
        isLoadedRef.current = true;
        isLoadingRef.current = false;
        adRef.current = ad;
      });

      const unsubClosed = ad.addAdEventListener(AdEventType.CLOSED, () => {
        console.log('[AppOpenAd] Ad closed by user — preloading next ad');
        isShowingRef.current = false;
        isLoadedRef.current = false;
        adRef.current = null;
        // Preload next ad after a short delay (policy: don't spam requests)
        setTimeout(() => loadAd(), 2000);
      });

      const unsubError = ad.addAdEventListener(AdEventType.ERROR, (error: any) => {
        console.warn('[AppOpenAd] Failed to load ad:', error?.message ?? error);
        isLoadedRef.current = false;
        isLoadingRef.current = false;
        adRef.current = null;
        // Retry after 30 seconds on failure
        setTimeout(() => loadAd(), 30_000);
      });

      cleanupRef.current = () => {
        unsubLoaded();
        unsubClosed();
        unsubError();
      };

      ad.load();
    } catch (e) {
      console.warn('[AppOpenAd] Error creating ad request:', e);
      isLoadingRef.current = false;
    }
  }, []);

  // ── Show ad (respects cooldown + policy) ──────────────────────────────────
  const showAd = useCallback(() => {
    if (Platform.OS === 'web') return;
    if (!isLoadedRef.current || !adRef.current) {
      console.log('[AppOpenAd] Ad not ready yet — skipping show');
      return;
    }
    if (isShowingRef.current) {
      console.log('[AppOpenAd] Ad already showing — skipping');
      return;
    }

    const now = Date.now();
    const elapsed = now - lastShownAtRef.current;
    if (lastShownAtRef.current > 0 && elapsed < MIN_SHOW_INTERVAL_MS) {
      const remainingMins = Math.ceil((MIN_SHOW_INTERVAL_MS - elapsed) / 60_000);
      console.log(`[AppOpenAd] Cooldown active — next show in ~${remainingMins} min`);
      return;
    }

    try {
      console.log('[AppOpenAd] Showing app open ad');
      isShowingRef.current = true;
      lastShownAtRef.current = now;
      adRef.current.show();
    } catch (e) {
      console.warn('[AppOpenAd] Error showing ad:', e);
      isShowingRef.current = false;
    }
  }, []);

  // ── Initialize SDK and load first ad on mount ─────────────────────────────
  useEffect(() => {
    if (Platform.OS === 'web' || !MobileAds) return;

    let cancelled = false;

    const init = async () => {
      try {
        await MobileAds().initialize();
        console.log('[AppOpenAd] SDK initialized');
        if (!cancelled) loadAd();
      } catch (e) {
        console.warn('[AppOpenAd] SDK init failed:', e);
        if (!cancelled) loadAd(); // still try to load
      }
    };

    init();

    return () => {
      cancelled = true;
      if (cleanupRef.current) {
        cleanupRef.current();
        cleanupRef.current = null;
      }
    };
  }, [loadAd]);

  // ── Show ad on cold launch (after first load) ─────────────────────────────
  // We watch isLoadedRef via a polling effect that fires once when the ad
  // becomes ready for the first time (lastShownAt === 0 means never shown).
  useEffect(() => {
    if (Platform.OS === 'web') return;

    const interval = setInterval(() => {
      if (isLoadedRef.current && lastShownAtRef.current === 0) {
        clearInterval(interval);
        // Small delay so the app UI is fully rendered before the ad appears
        setTimeout(() => showAd(), 800);
      }
    }, 500);

    return () => clearInterval(interval);
  }, [showAd]);

  // ── Show ad when app returns to foreground ────────────────────────────────
  useEffect(() => {
    if (Platform.OS === 'web') return;

    const handleAppStateChange = (nextState: AppStateStatus) => {
      if (nextState === 'active') {
        console.log('[AppOpenAd] App foregrounded — attempting to show ad');
        showAd();
      }
    };

    const subscription = AppState.addEventListener('change', handleAppStateChange);
    return () => subscription.remove();
  }, [showAd]);

  return { loadAd, showAd };
}
