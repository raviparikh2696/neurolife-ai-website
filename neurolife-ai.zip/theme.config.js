/** @type {const} */
const themeColors = {
  primary:     { light: '#6C63FF', dark: '#7C74FF' },
  background:  { light: '#F8F7FF', dark: '#0F0E1A' },
  surface:     { light: '#FFFFFF', dark: '#1C1B2E' },
  foreground:  { light: '#1A1A2E', dark: '#E8E6FF' },
  muted:       { light: '#7B7A9D', dark: '#9B99C0' },
  border:      { light: '#E2E0F5', dark: '#2E2C4A' },
  success:     { light: '#34D399', dark: '#4ADE80' },
  warning:     { light: '#FBBF24', dark: '#FCD34D' },
  error:       { light: '#F87171', dark: '#FCA5A5' },
  // Accent colors for categories
  accent1:     { light: '#FF6B6B', dark: '#FF8080' }, // tasks/urgency
  accent2:     { light: '#4ECDC4', dark: '#5EDDD4' }, // groceries
  accent3:     { light: '#45B7D1', dark: '#55C7E1' }, // calendar
  accent4:     { light: '#A78BFA', dark: '#B79BFF' }, // notes/memory
};

module.exports = { themeColors };
