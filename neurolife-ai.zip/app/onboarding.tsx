import {
  Dimensions,
  FlatList,
  Platform,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from "react-native";
import { StatusBar } from "expo-status-bar";
import { useRef, useState, useCallback } from "react";
import { router } from "expo-router";
import AsyncStorage from "@react-native-async-storage/async-storage";
import * as Haptics from "expo-haptics";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useColors } from "@/hooks/use-colors";

const { width: W, height: H } = Dimensions.get("window");
export const ONBOARDING_DONE_KEY = "neurolife_onboarding_done";

// ─── Slide Data ───────────────────────────────────────────────────────────────
const SLIDES = [
  {
    id: "1",
    emoji: "🧠",
    title: "Your Second Brain",
    subtitle: "NeuroLife AI remembers everything so you don't have to.",
    features: [
      { icon: "✅", text: "Create tasks with natural language" },
      { icon: "📅", text: "Schedule events by just describing them" },
      { icon: "🛒", text: "Build grocery lists in seconds" },
    ],
    bg: "#667eea20",
    accent: "#667eea",
  },
  {
    id: "2",
    emoji: "✨",
    title: "AI That Understands You",
    subtitle: "Just talk to it. NeuroLife figures out what you mean.",
    features: [
      { icon: "🎤", text: "Voice commands — speak your thoughts" },
      { icon: "📝", text: "Smart notes from meetings & ideas" },
      { icon: "🔄", text: "Everything syncs instantly across all tabs" },
    ],
    bg: "#f093fb20",
    accent: "#f5576c",
  },
  {
    id: "3",
    emoji: "🚀",
    title: "Stay On Top of Everything",
    subtitle: "Your tasks, calendar, groceries, and notes — all in one place.",
    features: [
      { icon: "🏠", text: "Home dashboard with today's overview" },
      { icon: "🔔", text: "Smart reminders before deadlines" },
      { icon: "🌙", text: "Dark mode & full customisation" },
    ],
    bg: "#4facfe20",
    accent: "#4facfe",
  },
];

// ─── Dot Indicator ────────────────────────────────────────────────────────────
function DotIndicator({
  count,
  active,
  colors,
}: {
  count: number;
  active: number;
  colors: any;
}) {
  return (
    <View style={styles.dots}>
      {Array.from({ length: count }).map((_, i) => (
        <View
          key={i}
          style={[
            styles.dot,
            {
              backgroundColor: i === active ? colors.primary : colors.border,
              width: i === active ? 24 : 8,
            },
          ]}
        />
      ))}
    </View>
  );
}

// ─── Single Slide ─────────────────────────────────────────────────────────────
function OnboardingSlide({
  slide,
  colors,
  slideHeight,
}: {
  slide: (typeof SLIDES)[0];
  colors: any;
  slideHeight: number;
}) {
  return (
    <View style={[styles.slide, { width: W, height: slideHeight }]}>
      {/* Hero circle */}
      <View style={[styles.heroCircle, { backgroundColor: slide.bg }]}>
        <Text style={styles.heroEmoji}>{slide.emoji}</Text>
      </View>

      {/* Title */}
      <Text style={[styles.slideTitle, { color: colors.foreground }]}>
        {slide.title}
      </Text>

      {/* Subtitle */}
      <Text style={[styles.slideSubtitle, { color: colors.muted }]}>
        {slide.subtitle}
      </Text>

      {/* Feature card */}
      <View
        style={[
          styles.featureCard,
          {
            backgroundColor: colors.surface,
            borderColor: colors.border,
          },
        ]}
      >
        {slide.features.map((f, i) => (
          <View
            key={i}
            style={[
              styles.featureRow,
              i > 0 && {
                borderTopWidth: StyleSheet.hairlineWidth,
                borderTopColor: colors.border,
              },
            ]}
          >
            <Text style={styles.featureIcon}>{f.icon}</Text>
            <Text style={[styles.featureText, { color: colors.foreground }]}>
              {f.text}
            </Text>
          </View>
        ))}
      </View>
    </View>
  );
}

// ─── Main Screen ──────────────────────────────────────────────────────────────
export default function OnboardingScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const [activeIndex, setActiveIndex] = useState(0);
  const flatListRef = useRef<FlatList>(null);

  // Reserve space for skip button (44) + bottom bar (~110)
  const topPad = insets.top + 44;
  const bottomBarH = 80 + insets.bottom;
  const slideHeight = H - topPad - bottomBarH;

  const handleScroll = useCallback(
    (e: any) => {
      const idx = Math.round(e.nativeEvent.contentOffset.x / W);
      setActiveIndex(idx);
    },
    []
  );

  const goNext = useCallback(async () => {
    if (Platform.OS !== "web") {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    }
    if (activeIndex < SLIDES.length - 1) {
      flatListRef.current?.scrollToIndex({
        index: activeIndex + 1,
        animated: true,
      });
    } else {
      await AsyncStorage.setItem(ONBOARDING_DONE_KEY, "true");
      router.replace("/sign-in" as any);
    }
  }, [activeIndex]);

  const skip = useCallback(async () => {
    await AsyncStorage.setItem(ONBOARDING_DONE_KEY, "true");
    router.replace("/sign-in" as any);
  }, []);

  const isLast = activeIndex === SLIDES.length - 1;

  return (
    <View
      style={[
        styles.root,
        { backgroundColor: colors.background, paddingTop: insets.top },
      ]}
    >
      <StatusBar style="auto" />

      {/* Skip button row */}
      <View style={styles.skipRow}>
        {!isLast ? (
          <TouchableOpacity
            onPress={skip}
            style={styles.skipBtn}
            activeOpacity={0.7}
          >
            <Text style={[styles.skipText, { color: colors.muted }]}>Skip</Text>
          </TouchableOpacity>
        ) : (
          <View style={styles.skipBtn} />
        )}
      </View>

      {/* Slides */}
      <FlatList
        ref={flatListRef}
        data={SLIDES}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <OnboardingSlide
            slide={item}
            colors={colors}
            slideHeight={slideHeight}
          />
        )}
        horizontal
        pagingEnabled
        showsHorizontalScrollIndicator={false}
        onMomentumScrollEnd={handleScroll}
        scrollEventThrottle={16}
        bounces={false}
        getItemLayout={(_, index) => ({
          length: W,
          offset: W * index,
          index,
        })}
        style={{ flexGrow: 0, height: slideHeight }}
      />

      {/* Bottom bar */}
      <View
        style={[
          styles.bottomBar,
          {
            backgroundColor: colors.background,
            paddingBottom: Math.max(insets.bottom, 24),
            borderTopColor: colors.border,
          },
        ]}
      >
        <DotIndicator count={SLIDES.length} active={activeIndex} colors={colors} />

        <TouchableOpacity
          onPress={goNext}
          style={[styles.nextBtn, { backgroundColor: colors.primary }]}
          activeOpacity={0.85}
        >
          <Text style={styles.nextBtnText}>
            {isLast ? "Get Started  →" : "Next  →"}
          </Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

// ─── Styles ───────────────────────────────────────────────────────────────────
const styles = StyleSheet.create({
  root: {
    flex: 1,
  },
  skipRow: {
    height: 44,
    alignItems: "flex-end",
    justifyContent: "center",
    paddingHorizontal: 20,
  },
  skipBtn: {
    paddingHorizontal: 4,
    paddingVertical: 8,
  },
  skipText: {
    fontSize: 15,
    fontWeight: "500",
  },
  slide: {
    alignItems: "center",
    justifyContent: "center",
    paddingHorizontal: 28,
    paddingVertical: 16,
    gap: 16,
  },
  heroCircle: {
    width: 130,
    height: 130,
    borderRadius: 65,
    alignItems: "center",
    justifyContent: "center",
    marginBottom: 4,
  },
  heroEmoji: {
    fontSize: 64,
    lineHeight: 80,
  },
  slideTitle: {
    fontSize: 26,
    fontWeight: "800",
    textAlign: "center",
    letterSpacing: -0.5,
    lineHeight: 34,
  },
  slideSubtitle: {
    fontSize: 15,
    textAlign: "center",
    lineHeight: 22,
    marginTop: -4,
    paddingHorizontal: 8,
  },
  featureCard: {
    width: "100%",
    borderRadius: 16,
    borderWidth: StyleSheet.hairlineWidth,
    overflow: "hidden",
    marginTop: 4,
  },
  featureRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 12,
    paddingHorizontal: 16,
    paddingVertical: 13,
  },
  featureIcon: {
    fontSize: 20,
    width: 28,
    textAlign: "center",
    lineHeight: 26,
  },
  featureText: {
    fontSize: 14,
    fontWeight: "500",
    flex: 1,
    lineHeight: 20,
  },
  dots: {
    flexDirection: "row",
    gap: 6,
    alignItems: "center",
  },
  dot: {
    height: 8,
    borderRadius: 4,
  },
  bottomBar: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 28,
    paddingTop: 16,
    borderTopWidth: StyleSheet.hairlineWidth,
  },
  nextBtn: {
    paddingHorizontal: 28,
    paddingVertical: 14,
    borderRadius: 50,
    minWidth: 140,
    alignItems: "center",
  },
  nextBtnText: {
    color: "#fff",
    fontSize: 15,
    fontWeight: "700",
    letterSpacing: 0.2,
  },
});
