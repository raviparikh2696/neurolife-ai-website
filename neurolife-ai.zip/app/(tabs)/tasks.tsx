import { useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import {
  Alert,
  FlatList,
  KeyboardAvoidingView,
  Modal,
  Platform,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
  Animated,
} from "react-native";
import * as Haptics from "expo-haptics";
import { Swipeable } from "react-native-gesture-handler";

import { ScreenContainer } from "@/components/screen-container";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { useColors } from "@/hooks/use-colors";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/hooks/use-auth";
import { scheduleEventReminders } from "@/lib/notifications";
import { NativeAdCard } from "@/components/native-ad-card";

// Platform-specific ad unit IDs for Tasks screen
const TASKS_AD_UNIT_ID = Platform.select({
  android: 'ca-app-pub-1720679341163644/5215120737',
  ios: 'ca-app-pub-1720679341163644/4837752761',
  default: '',
});

const PRIORITY_CONFIG = {
  high:   { color: "#F87171", label: "High",   icon: "🔴" },
  medium: { color: "#FBBF24", label: "Medium",  icon: "🟡" },
  low:    { color: "#34D399", label: "Low",     icon: "🟢" },
} as const;

type Priority = keyof typeof PRIORITY_CONFIG;
type Recurrence = "none" | "daily" | "weekly" | "monthly";

// ─── Helpers ──────────────────────────────────────────────────────────────────

function pad(n: number) { return String(n).padStart(2, "0"); }

function formatDueDate(iso: string) {
  const d = new Date(iso);
  return d.toLocaleDateString("en-US", { month: "short", day: "numeric" }) +
    " at " + d.toLocaleTimeString("en-US", { hour: "numeric", minute: "2-digit", hour12: true });
}

// ─── Sub-components ───────────────────────────────────────────────────────────

function PriorityBadge({ priority, colors }: { priority: Priority; colors: any }) {
  const cfg = PRIORITY_CONFIG[priority];
  return (
    <View style={[styles.badge, { backgroundColor: cfg.color + "22" }]}>
      <Text style={[styles.badgeText, { color: cfg.color }]}>{cfg.label}</Text>
    </View>
  );
}

function TaskRow({ task, colors, onComplete, onDelete }: {
  task: any; colors: any;
  onComplete: () => void; onDelete: () => void;
}) {
  const cfg = PRIORITY_CONFIG[task.priority as Priority] ?? PRIORITY_CONFIG.medium;
  const isCompleted = task.completed;

  // Swipe actions
  const renderRightActions = (progress: Animated.AnimatedInterpolation<number>, dragAnimatedValue: Animated.AnimatedInterpolation<number>) => {
    const trans = dragAnimatedValue.interpolate({
      inputRange: [-100, 0],
      outputRange: [0, 1],
      extrapolate: "clamp",
    });
    return (
      <Animated.View style={[styles.swipeAction, { transform: [{ translateX: trans }] }]}>
        <TouchableOpacity
          style={[styles.swipeActionBtn, { backgroundColor: colors.success }]}
          onPress={onComplete}
        >
          <IconSymbol name="checkmark" size={20} color="#fff" />
        </TouchableOpacity>
      </Animated.View>
    );
  };

  return (
    <Swipeable renderRightActions={renderRightActions}>
      <View style={[styles.taskRow, { backgroundColor: colors.surface, borderColor: colors.border }]}>
        <TouchableOpacity
          onPress={onComplete}
          style={[styles.checkbox, {
            borderColor: isCompleted ? colors.success : cfg.color,
            backgroundColor: isCompleted ? colors.success : "transparent",
          }]}
          hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}
        >
          {isCompleted && <IconSymbol name="checkmark" size={12} color="#fff" />}
        </TouchableOpacity>

        <View style={styles.taskBody}>
          <Text
            style={[styles.taskTitle, { color: isCompleted ? colors.muted : colors.foreground, textDecorationLine: isCompleted ? "line-through" : "none" }]}
            numberOfLines={2}
          >
            {task.title}
          </Text>
          {task.notes ? (
            <Text style={[styles.taskNotes, { color: colors.muted }]} numberOfLines={1}>{task.notes}</Text>
          ) : null}
          {task.dueDate ? (
            <Text style={[styles.taskDue, { color: isCompleted ? colors.muted : colors.warning }]}>
              ⏰ {formatDueDate(task.dueDate)}
            </Text>
          ) : null}
          {task.recurrence && task.recurrence !== "none" ? (
            <Text style={[styles.taskRecur, { color: colors.primary }]}>
              🔄 {task.recurrence.charAt(0).toUpperCase() + task.recurrence.slice(1)}
            </Text>
          ) : null}
        </View>

        <View style={styles.taskMeta}>
          <PriorityBadge priority={task.priority as Priority} colors={colors} />
          <TouchableOpacity
            onPress={onDelete}
            hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}
            style={{ marginTop: 6 }}
          >
            <IconSymbol name="trash" size={16} color={colors.muted} />
          </TouchableOpacity>
        </View>
      </View>
    </Swipeable>
  );
}

// ─── Add Task Modal ───────────────────────────────────────────────────────────

function AddTaskModal({ visible, onClose, onAdd, colors }: {
  visible: boolean; onClose: () => void;
  onAdd: (title: string, notes: string, priority: Priority, dueDate?: string, recurrence?: Recurrence) => void;
  colors: any;
}) {
  const [title, setTitle] = useState("");
  const [notes, setNotes] = useState("");
  const [priority, setPriority] = useState<Priority>("medium");
  const [hasDueDate, setHasDueDate] = useState(false);
  const [recurrence, setRecurrence] = useState<Recurrence>("none");

  // Date fields
  const now = new Date();
  const [dueDateStr, setDueDateStr] = useState(
    `${now.getFullYear()}-${pad(now.getMonth() + 1)}-${pad(now.getDate())}`
  );
  const [dueHour, setDueHour] = useState(pad(now.getHours() + 1 > 23 ? 23 : now.getHours() + 1));
  const [dueMin, setDueMin] = useState("00");

  const handleAdd = () => {
    if (!title.trim()) return;
    let dueDate: string | undefined;
    if (hasDueDate) {
      const parts = dueDateStr.split("-");
      if (parts.length === 3) {
        const d = new Date(
          parseInt(parts[0], 10),
          parseInt(parts[1], 10) - 1,
          parseInt(parts[2], 10),
          parseInt(dueHour, 10),
          parseInt(dueMin, 10),
          0, 0
        );
        dueDate = d.toISOString();
      }
    }
    onAdd(title.trim(), notes.trim(), priority, dueDate, recurrence !== "none" ? recurrence : undefined);
    // Reset
    setTitle(""); setNotes(""); setPriority("medium"); setHasDueDate(false); setRecurrence("none");
    onClose();
  };

  return (
    <Modal visible={visible} animationType="slide" transparent onRequestClose={onClose}>
      <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === "ios" ? "padding" : "height"}>
        <View style={styles.modalOverlay}>
          <ScrollView keyboardShouldPersistTaps="handled" contentContainerStyle={{ justifyContent: "flex-end", flexGrow: 1 }}>
            <View style={[styles.modalSheet, { backgroundColor: colors.surface }]}>
              <View style={styles.modalHeader}>
                <Text style={[styles.modalTitle, { color: colors.foreground }]}>New Task</Text>
                <TouchableOpacity onPress={onClose}>
                  <IconSymbol name="xmark.circle.fill" size={24} color={colors.muted} />
                </TouchableOpacity>
              </View>

              {/* Title */}
              <Text style={[styles.fieldLabel, { color: colors.muted }]}>Title *</Text>
              <TextInput
                style={[styles.input, { backgroundColor: colors.background, color: colors.foreground, borderColor: colors.border }]}
                placeholder="Task title..."
                placeholderTextColor={colors.muted}
                value={title}
                onChangeText={setTitle}
                autoFocus
                returnKeyType="next"
              />

              {/* Notes */}
              <Text style={[styles.fieldLabel, { color: colors.muted }]}>Notes (optional)</Text>
              <TextInput
                style={[styles.input, styles.inputMulti, { backgroundColor: colors.background, color: colors.foreground, borderColor: colors.border }]}
                placeholder="Notes..."
                placeholderTextColor={colors.muted}
                value={notes}
                onChangeText={setNotes}
                multiline
                numberOfLines={3}
                returnKeyType="done"
              />

              {/* Priority */}
              <Text style={[styles.fieldLabel, { color: colors.muted }]}>Priority</Text>
              <View style={styles.priorityRow}>
                {(["high", "medium", "low"] as Priority[]).map((p) => {
                  const cfg = PRIORITY_CONFIG[p];
                  const selected = priority === p;
                  return (
                    <TouchableOpacity
                      key={p}
                      style={[styles.priorityBtn, {
                        backgroundColor: selected ? cfg.color : cfg.color + "22",
                        borderColor: cfg.color,
                        borderWidth: selected ? 2 : 1,
                      }]}
                      onPress={() => setPriority(p)}
                    >
                      <Text style={[styles.priorityBtnText, { color: cfg.color }]}>{cfg.label}</Text>
                    </TouchableOpacity>
                  );
                })}
              </View>

              {/* Due Date Toggle */}
              <View style={styles.toggleRow}>
                <Text style={[styles.fieldLabel, { color: colors.muted }]}>Due Date</Text>
                <TouchableOpacity
                  style={[styles.toggle, { backgroundColor: hasDueDate ? colors.primary : colors.border }]}
                  onPress={() => setHasDueDate(!hasDueDate)}
                >
                  <View style={[styles.toggleThumb, { transform: [{ translateX: hasDueDate ? 20 : 0 }] }]} />
                </TouchableOpacity>
              </View>

              {hasDueDate && (
                <>
                  <TextInput
                    style={[styles.input, { backgroundColor: colors.background, color: colors.foreground, borderColor: colors.border }]}
                    placeholder="YYYY-MM-DD"
                    placeholderTextColor={colors.muted}
                    value={dueDateStr}
                    onChangeText={setDueDateStr}
                  />
                  <View style={styles.timeRow}>
                    <TextInput
                      style={[styles.timeInput, { backgroundColor: colors.background, color: colors.foreground, borderColor: colors.border }]}
                      placeholder="HH"
                      placeholderTextColor={colors.muted}
                      value={dueHour}
                      onChangeText={setDueHour}
                      maxLength={2}
                    />
                    <Text style={[styles.timeSep, { color: colors.foreground }]}>:</Text>
                    <TextInput
                      style={[styles.timeInput, { backgroundColor: colors.background, color: colors.foreground, borderColor: colors.border }]}
                      placeholder="MM"
                      placeholderTextColor={colors.muted}
                      value={dueMin}
                      onChangeText={setDueMin}
                      maxLength={2}
                    />
                  </View>
                </>
              )}

              {/* Recurrence */}
              <Text style={[styles.fieldLabel, { color: colors.muted }]}>Repeat</Text>
              <View style={styles.recurrenceRow}>
                {(["none", "daily", "weekly", "monthly"] as Recurrence[]).map((r) => {
                  const selected = recurrence === r;
                  const label = r === "none" ? "Never" : r.charAt(0).toUpperCase() + r.slice(1);
                  return (
                    <TouchableOpacity
                      key={r}
                      style={[styles.recurrenceBtn, {
                        backgroundColor: selected ? colors.primary : colors.primary + "22",
                        borderColor: colors.primary,
                        borderWidth: selected ? 2 : 1,
                      }]}
                      onPress={() => setRecurrence(r)}
                    >
                      <Text style={[styles.recurrenceBtnText, { color: selected ? "#fff" : colors.primary }]}>{label}</Text>
                    </TouchableOpacity>
                  );
                })}
              </View>

              {/* Action buttons */}
              <View style={styles.modalActions}>
                <TouchableOpacity style={[styles.btn, { backgroundColor: colors.border }]} onPress={onClose}>
                  <Text style={[styles.btnText, { color: colors.foreground }]}>Cancel</Text>
                </TouchableOpacity>
                <TouchableOpacity
                  style={[styles.btn, { backgroundColor: colors.primary }]}
                  onPress={handleAdd}
                  disabled={!title.trim()}
                >
                  <Text style={[styles.btnText, { color: "#fff" }]}>Add Task</Text>
                </TouchableOpacity>
              </View>
            </View>
          </ScrollView>
        </View>
      </KeyboardAvoidingView>
    </Modal>
  );
}

// ─── Main Screen ──────────────────────────────────────────────────────────────

export default function TasksScreen() {
  const colors = useColors();
  const { isAuthenticated } = useAuth();
  const [showAddModal, setShowAddModal] = useState(false);

  // staleTime: 0 ensures AI-created tasks appear immediately without reopening the app
  const { data: tasks = [], refetch, isLoading } = trpc.tasks.list.useQuery(
    { includeCompleted: true },
    {
      enabled: isAuthenticated,
      staleTime: 0,
      gcTime: 5 * 60 * 1000, // 5 minutes garbage collection
    }
  );

  const utils = trpc.useUtils();
  const queryKey = [['tasks', 'list'], { input: { includeCompleted: true }, type: 'query' }];

  const createTask = trpc.tasks.create.useMutation({
    onMutate: async (newTask) => {
      await utils.tasks.list.cancel();
      const prev = utils.tasks.list.getData({ includeCompleted: true });
      utils.tasks.list.setData({ includeCompleted: true }, (old: any) => [
        ...(old ?? []),
        { id: Date.now(), title: newTask.title, notes: newTask.notes ?? null, priority: newTask.priority ?? "medium", completed: false, dueDate: newTask.dueDate ?? null, recurrence: null, userId: "", createdAt: new Date().toISOString() },
      ]);
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      return { prev };
    },
    onError: (_err, _vars, ctx: any) => { if (ctx?.prev) utils.tasks.list.setData({ includeCompleted: true }, ctx.prev); },
    onSettled: () => utils.tasks.list.invalidate(),
  });

  const updateTask = trpc.tasks.update.useMutation({
    onMutate: async (updated) => {
      await utils.tasks.list.cancel();
      const prev = utils.tasks.list.getData({ includeCompleted: true });
      utils.tasks.list.setData({ includeCompleted: true }, (old: any) =>
        (old ?? []).map((t: any) => t.id === updated.id ? { ...t, ...updated } : t)
      );
      return { prev };
    },
    onError: (_err, _vars, ctx: any) => { if (ctx?.prev) utils.tasks.list.setData({ includeCompleted: true }, ctx.prev); },
    onSettled: () => utils.tasks.list.invalidate(),
  });

  const deleteTask = trpc.tasks.delete.useMutation({
    onMutate: async ({ id }) => {
      await utils.tasks.list.cancel();
      const prev = utils.tasks.list.getData({ includeCompleted: true });
      utils.tasks.list.setData({ includeCompleted: true }, (old: any) =>
        (old ?? []).filter((t: any) => t.id !== id)
      );
      return { prev };
    },
    onError: (_err, _vars, ctx: any) => { if (ctx?.prev) utils.tasks.list.setData({ includeCompleted: true }, ctx.prev); },
    onSettled: () => utils.tasks.list.invalidate(),
  });

  const handleAddTask = (title: string, notes: string, priority: Priority, dueDate?: string, recurrence?: Recurrence) => {
    createTask.mutate({
      title,
      notes: notes || undefined,
      priority,
      dueDate,
    } as any);
  };

  const handleCompleteTask = (task: any) => {
    updateTask.mutate({
      id: task.id,
      completed: !task.completed,
      completedAt: !task.completed ? new Date().toISOString() : undefined,
    });
  };

  const handleDeleteTask = (taskId: number) => {
    Alert.alert("Delete Task", "Are you sure?", [
      { text: "Cancel" },
      {
        text: "Delete",
        onPress: () => deleteTask.mutate({ id: taskId }),
        style: "destructive",
      },
    ]);
  };

  const pendingTasks = tasks.filter((t) => !t.completed);
  const completedTasks = tasks.filter((t) => t.completed);

  return (
    <ScreenContainer>
      <View style={styles.header}>
        <View>
          <Text style={[styles.title, { color: colors.foreground }]}>Tasks</Text>
          <Text style={[styles.subtitle, { color: colors.muted }]}>
            {pendingTasks.length} pending, {completedTasks.length} done
          </Text>
        </View>
        <TouchableOpacity
          style={[styles.addBtn, { backgroundColor: colors.primary }]}
          onPress={() => setShowAddModal(true)}
        >
          <IconSymbol name="plus" size={20} color="#fff" />
        </TouchableOpacity>
      </View>

      {isLoading ? (
        <View style={styles.loadingContainer}>
          <Text style={[styles.loadingText, { color: colors.muted }]}>Loading tasks...</Text>
        </View>
      ) : pendingTasks.length === 0 && completedTasks.length === 0 ? (
        <View style={styles.emptyContainer}>
          <IconSymbol name="checkmark.circle.fill" size={48} color={colors.primary} />
          <Text style={[styles.emptyText, { color: colors.foreground }]}>No tasks yet</Text>
          <Text style={[styles.emptySubtext, { color: colors.muted }]}>Tap + to create one</Text>
        </View>
      ) : (
        <FlatList
          data={[...pendingTasks, ...completedTasks]}
          keyExtractor={(t) => String(t.id)}
          renderItem={({ item }) => (
            <TaskRow
              task={item}
              colors={colors}
              onComplete={() => handleCompleteTask(item)}
              onDelete={() => handleDeleteTask(item.id)}
            />
          )}
          scrollEnabled
          contentContainerStyle={styles.listContent}
          showsVerticalScrollIndicator={false}
          ListFooterComponent={
            <View style={styles.adFooter}>
              <NativeAdCard adUnitId={TASKS_AD_UNIT_ID} />
            </View>
          }
        />
      )}

      <AddTaskModal
        visible={showAddModal}
        onClose={() => setShowAddModal(false)}
        onAdd={handleAddTask}
        colors={colors}
      />
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingHorizontal: 16,
    paddingTop: 12,
    paddingBottom: 16,
  },
  title: { fontSize: 28, fontWeight: "700" },
  subtitle: { fontSize: 13, marginTop: 2 },
  addBtn: {
    width: 44,
    height: 44,
    borderRadius: 22,
    alignItems: "center",
    justifyContent: "center",
  },
  loadingContainer: { flex: 1, alignItems: "center", justifyContent: "center" },
  loadingText: { fontSize: 14 },
  emptyContainer: { flex: 1, alignItems: "center", justifyContent: "center", gap: 8 },
  emptyText: { fontSize: 18, fontWeight: "600", marginTop: 8 },
  emptySubtext: { fontSize: 14 },
  listContent: { paddingHorizontal: 16, paddingVertical: 8 },
  taskRow: {
    flexDirection: "row",
    alignItems: "center",
    borderRadius: 12,
    borderWidth: 1,
    padding: 12,
    marginBottom: 8,
    gap: 12,
  },
  checkbox: {
    width: 24,
    height: 24,
    borderRadius: 12,
    borderWidth: 2,
    alignItems: "center",
    justifyContent: "center",
  },
  taskBody: { flex: 1 },
  taskTitle: { fontSize: 15, fontWeight: "500", lineHeight: 20 },
  taskNotes: { fontSize: 12, marginTop: 2 },
  taskDue: { fontSize: 12, marginTop: 2, fontWeight: "500" },
  taskRecur: { fontSize: 11, marginTop: 2, fontWeight: "600" },
  taskMeta: { alignItems: "flex-end", gap: 8 },
  badge: { paddingHorizontal: 8, paddingVertical: 3, borderRadius: 8 },
  badgeText: { fontSize: 10, fontWeight: "700" },
  swipeAction: {
    width: 100,
    justifyContent: "center",
    alignItems: "flex-end",
    paddingRight: 12,
  },
  swipeActionBtn: {
    width: 50,
    height: 50,
    borderRadius: 10,
    alignItems: "center",
    justifyContent: "center",
  },
  // Modal
  modalOverlay: { flex: 1, backgroundColor: "rgba(0,0,0,0.5)" },
  modalSheet: { borderTopLeftRadius: 20, borderTopRightRadius: 20, padding: 20, gap: 16 },
  modalHeader: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginBottom: 8 },
  modalTitle: { fontSize: 20, fontWeight: "700" },
  fieldLabel: { fontSize: 13, fontWeight: "600", marginBottom: 6 },
  input: { borderRadius: 10, borderWidth: 1, padding: 12, fontSize: 14, marginBottom: 12 },
  inputMulti: { height: 80, textAlignVertical: "top" },
  priorityRow: { flexDirection: "row", gap: 8, marginBottom: 12 },
  priorityBtn: { flex: 1, borderRadius: 10, paddingVertical: 10, alignItems: "center", borderWidth: 1 },
  priorityBtnText: { fontSize: 13, fontWeight: "600" },
  toggleRow: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginBottom: 12 },
  toggle: { width: 50, height: 28, borderRadius: 14, padding: 2, justifyContent: "center" },
  toggleThumb: { width: 24, height: 24, borderRadius: 12, backgroundColor: "#fff" },
  timeRow: { flexDirection: "row", alignItems: "center", gap: 8, marginBottom: 12 },
  timeInput: { flex: 1, borderRadius: 10, borderWidth: 1, padding: 10, fontSize: 14, textAlign: "center" },
  timeSep: { fontSize: 18, fontWeight: "700" },
  recurrenceRow: { flexDirection: "row", gap: 8, marginBottom: 12, flexWrap: "wrap" },
  recurrenceBtn: { paddingHorizontal: 12, paddingVertical: 8, borderRadius: 20, borderWidth: 1 },
  recurrenceBtnText: { fontSize: 12, fontWeight: "600" },
  modalActions: { flexDirection: "row", gap: 12, marginTop: 8 },
  btn: { flex: 1, borderRadius: 10, paddingVertical: 12, alignItems: "center" },
  btnText: { fontSize: 14, fontWeight: "700" },
  adFooter: { paddingHorizontal: 16, paddingTop: 8, paddingBottom: 24 },
});
