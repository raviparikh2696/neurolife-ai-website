import { useState } from "react";
import {
  Alert,
  FlatList,
  KeyboardAvoidingView,
  Modal,
  Platform,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";
import * as Haptics from "expo-haptics";

import { ScreenContainer } from "@/components/screen-container";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { useColors } from "@/hooks/use-colors";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/hooks/use-auth";
import { scheduleEventReminders, cancelNotifications } from "@/lib/notifications";
import { NativeAdCard } from "@/components/native-ad-card";

// Platform-specific ad unit IDs for Calendar screen
const CALENDAR_AD_UNIT_ID = Platform.select({
  android: 'ca-app-pub-1720679341163644/3232655923',
  ios: 'ca-app-pub-1720679341163644/2434950702',
  default: '',
});

// ─── Helpers ──────────────────────────────────────────────────────────────────

const DAYS = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
const MONTHS = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];

function isSameDay(a: Date, b: Date) {
  return a.getFullYear() === b.getFullYear() && a.getMonth() === b.getMonth() && a.getDate() === b.getDate();
}

function formatTime(date: Date) {
  return date.toLocaleTimeString("en-US", { hour: "numeric", minute: "2-digit", hour12: true });
}

function getWeekDays(base: Date): Date[] {
  const start = new Date(base);
  start.setDate(base.getDate() - base.getDay()); // Sunday
  return Array.from({ length: 7 }, (_, i) => {
    const d = new Date(start);
    d.setDate(start.getDate() + i);
    return d;
  });
}

// ─── Add Event Modal ──────────────────────────────────────────────────────────

function AddEventModal({ visible, onClose, onAdd, colors, defaultDate }: {
  visible: boolean; onClose: () => void;
  onAdd: (data: any) => void;
  colors: any; defaultDate: Date;
}) {
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [location, setLocation] = useState("");
  const [startHour, setStartHour] = useState("09");
  const [startMin, setStartMin] = useState("00");
  const [endHour, setEndHour] = useState("10");
  const [endMin, setEndMin] = useState("00");

  const handleAdd = () => {
    if (!title.trim()) return;
    const startTime = new Date(defaultDate);
    startTime.setHours(parseInt(startHour, 10), parseInt(startMin, 10), 0, 0);
    const endTime = new Date(defaultDate);
    endTime.setHours(parseInt(endHour, 10), parseInt(endMin, 10), 0, 0);
    onAdd({
      title: title.trim(),
      description: description.trim() || undefined,
      location: location.trim() || undefined,
      startTime: startTime.toISOString(),
      endTime: endTime.toISOString(),
    });
    setTitle(""); setDescription(""); setLocation("");
    setStartHour("09"); setStartMin("00"); setEndHour("10"); setEndMin("00");
    onClose();
  };

  return (
    <Modal visible={visible} animationType="slide" transparent onRequestClose={onClose}>
      <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === "ios" ? "padding" : "height"}>
      <View style={styles.modalOverlay}>
        <ScrollView keyboardShouldPersistTaps="handled">
          <View style={[styles.modalSheet, { backgroundColor: colors.surface }]}>
            <View style={styles.modalHeader}>
              <Text style={[styles.modalTitle, { color: colors.foreground }]}>New Event</Text>
              <TouchableOpacity onPress={onClose}>
                <IconSymbol name="xmark.circle.fill" size={24} color={colors.muted} />
              </TouchableOpacity>
            </View>

            <Text style={[styles.fieldLabel, { color: colors.muted }]}>Title *</Text>
            <TextInput
              style={[styles.input, { backgroundColor: colors.background, color: colors.foreground, borderColor: colors.border }]}
              placeholder="Event title..."
              placeholderTextColor={colors.muted}
              value={title}
              onChangeText={setTitle}
              autoFocus
            />

            <Text style={[styles.fieldLabel, { color: colors.muted }]}>Start Time</Text>
            <View style={styles.timeRow}>
              <TextInput
                style={[styles.timeInput, { backgroundColor: colors.background, color: colors.foreground, borderColor: colors.border }]}
                value={startHour}
                onChangeText={setStartHour}
                keyboardType="number-pad"
                maxLength={2}
                placeholder="09"
                placeholderTextColor={colors.muted}
              />
              <Text style={[styles.timeSep, { color: colors.foreground }]}>:</Text>
              <TextInput
                style={[styles.timeInput, { backgroundColor: colors.background, color: colors.foreground, borderColor: colors.border }]}
                value={startMin}
                onChangeText={setStartMin}
                keyboardType="number-pad"
                maxLength={2}
                placeholder="00"
                placeholderTextColor={colors.muted}
              />
            </View>

            <Text style={[styles.fieldLabel, { color: colors.muted }]}>End Time</Text>
            <View style={styles.timeRow}>
              <TextInput
                style={[styles.timeInput, { backgroundColor: colors.background, color: colors.foreground, borderColor: colors.border }]}
                value={endHour}
                onChangeText={setEndHour}
                keyboardType="number-pad"
                maxLength={2}
                placeholder="10"
                placeholderTextColor={colors.muted}
              />
              <Text style={[styles.timeSep, { color: colors.foreground }]}>:</Text>
              <TextInput
                style={[styles.timeInput, { backgroundColor: colors.background, color: colors.foreground, borderColor: colors.border }]}
                value={endMin}
                onChangeText={setEndMin}
                keyboardType="number-pad"
                maxLength={2}
                placeholder="00"
                placeholderTextColor={colors.muted}
              />
            </View>

            <Text style={[styles.fieldLabel, { color: colors.muted }]}>Location (optional)</Text>
            <TextInput
              style={[styles.input, { backgroundColor: colors.background, color: colors.foreground, borderColor: colors.border }]}
              placeholder="Location..."
              placeholderTextColor={colors.muted}
              value={location}
              onChangeText={setLocation}
            />

            <Text style={[styles.fieldLabel, { color: colors.muted }]}>Description (optional)</Text>
            <TextInput
              style={[styles.input, styles.inputMulti, { backgroundColor: colors.background, color: colors.foreground, borderColor: colors.border }]}
              placeholder="Description..."
              placeholderTextColor={colors.muted}
              value={description}
              onChangeText={setDescription}
              multiline
            />

            <TouchableOpacity
              style={[styles.addBtn, { backgroundColor: colors.accent3, opacity: title.trim() ? 1 : 0.5 }]}
              onPress={handleAdd}
              disabled={!title.trim()}
            >
              <Text style={styles.addBtnText}>Add Event</Text>
            </TouchableOpacity>
          </View>
        </ScrollView>
      </View>
      </KeyboardAvoidingView>
    </Modal>
  );
}

// ─── Event Card ───────────────────────────────────────────────────────────────

function EventCard({ event, colors, onDelete }: { event: any; colors: any; onDelete: () => void }) {
  const start = new Date(event.startTime);
  const end = event.endTime ? new Date(event.endTime) : null;
  const duration = end ? Math.round((end.getTime() - start.getTime()) / 60000) : null;

  return (
    <View style={[styles.eventCard, { backgroundColor: colors.surface, borderColor: colors.border }]}>
      <View style={[styles.eventTimeBar, { backgroundColor: colors.accent3 }]} />
      <View style={styles.eventBody}>
        <Text style={[styles.eventTitle, { color: colors.foreground }]} numberOfLines={2}>{event.title}</Text>
        <Text style={[styles.eventTime, { color: colors.accent3 }]}>
          {formatTime(start)}{end ? ` – ${formatTime(end)}` : ""}
          {duration ? ` (${duration < 60 ? `${duration}m` : `${Math.round(duration / 60)}h`})` : ""}
        </Text>
        {event.location ? <Text style={[styles.eventMeta, { color: colors.muted }]}>📍 {event.location}</Text> : null}
        {event.description ? <Text style={[styles.eventDesc, { color: colors.muted }]} numberOfLines={2}>{event.description}</Text> : null}
      </View>
      <TouchableOpacity onPress={onDelete} hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}>
        <IconSymbol name="trash" size={16} color={colors.muted} />
      </TouchableOpacity>
    </View>
  );
}

// ─── Main Screen ──────────────────────────────────────────────────────────────

export default function CalendarScreen() {
  const colors = useColors();
  const { isAuthenticated } = useAuth();
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [weekBase, setWeekBase] = useState(new Date());
  const [showAdd, setShowAdd] = useState(false);

  const weekDays = getWeekDays(weekBase);
  const monthStart = new Date(selectedDate.getFullYear(), selectedDate.getMonth(), 1);
  const monthEnd = new Date(selectedDate.getFullYear(), selectedDate.getMonth() + 1, 0);

  const { data: events = [], refetch } = trpc.events.list.useQuery(
    { startDate: monthStart.toISOString(), endDate: monthEnd.toISOString() },
    {
      enabled: isAuthenticated,
      staleTime: 0, // Always fresh — AI-created events appear immediately
      gcTime: 5 * 60 * 1000, // 5 minutes
    }
  );

  const utils = trpc.useUtils();
  const queryInput = { startDate: monthStart.toISOString(), endDate: monthEnd.toISOString() };

  const createEvent = trpc.events.create.useMutation({
    onMutate: async (newEvt) => {
      await utils.events.list.cancel();
      const prev = utils.events.list.getData(queryInput);
      utils.events.list.setData(queryInput, (old: any) => [
        ...(old ?? []),
        { id: Date.now(), title: newEvt.title, startTime: newEvt.startTime, endTime: newEvt.endTime ?? newEvt.startTime, location: newEvt.location ?? null, description: newEvt.description ?? null, recurrence: null, userId: "", createdAt: new Date().toISOString() },
      ]);
      return { prev };
    },
    onError: (_err: any, _vars: any, ctx: any) => { if (ctx?.prev) utils.events.list.setData(queryInput, ctx.prev); },
    onSettled: () => utils.events.list.invalidate(),
  });
  const deleteEvent = trpc.events.delete.useMutation({
    onMutate: async ({ id }) => {
      await utils.events.list.cancel();
      const prev = utils.events.list.getData(queryInput);
      utils.events.list.setData(queryInput, (old: any) =>
        (old ?? []).filter((e: any) => e.id !== id)
      );
      return { prev };
    },
    onError: (_err: any, _vars: any, ctx: any) => { if (ctx?.prev) utils.events.list.setData(queryInput, ctx.prev); },
    onSettled: () => utils.events.list.invalidate(),
  });

  const dayEvents = events.filter((e) => isSameDay(new Date(e.startTime), selectedDate))
    .sort((a, b) => new Date(a.startTime).getTime() - new Date(b.startTime).getTime());

  const handleAdd = async (data: any) => {
    await createEvent.mutateAsync(data);
    // Schedule push notifications (1hr, 30min, 10min before)
    if (Platform.OS !== "web") {
      try {
        await scheduleEventReminders({
          title: `📅 ${data.title}`,
          body: data.location ? `At ${data.location}` : "Upcoming event",
          date: new Date(data.startTime),
          data: { type: "event" },
        });
      } catch {}
    }
    if (Platform.OS !== "web") Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
  };

  const handleDelete = (event: any) => {
    Alert.alert("Delete Event", "Remove this event?", [
      { text: "Cancel", style: "cancel" },
      {
        text: "Delete",
        style: "destructive",
        onPress: async () => {
          if (event.notificationIds) {
            await cancelNotifications(event.notificationIds.split(","));
          }
          deleteEvent.mutate({ id: event.id });
        },
      },
    ]);
  };

  const prevWeek = () => {
    const d = new Date(weekBase);
    d.setDate(d.getDate() - 7);
    setWeekBase(d);
  };

  const nextWeek = () => {
    const d = new Date(weekBase);
    d.setDate(d.getDate() + 7);
    setWeekBase(d);
  };

  // Dots for days that have events
  const eventDays = new Set(events.map((e) => {
    const d = new Date(e.startTime);
    return `${d.getFullYear()}-${d.getMonth()}-${d.getDate()}`;
  }));

  return (
    <ScreenContainer containerClassName="bg-background">
      {/* Header */}
      <View style={[styles.header, { borderBottomColor: colors.border }]}>
        <Text style={[styles.screenTitle, { color: colors.foreground }]}>
          {MONTHS[selectedDate.getMonth()]} {selectedDate.getFullYear()}
        </Text>
        <TouchableOpacity
          style={[styles.fabSmall, { backgroundColor: colors.accent3 }]}
          onPress={() => setShowAdd(true)}
        >
          <IconSymbol name="plus" size={22} color="#fff" />
        </TouchableOpacity>
      </View>

      {/* Week Strip */}
      <View style={[styles.weekStrip, { backgroundColor: colors.surface, borderBottomColor: colors.border }]}>
        <TouchableOpacity onPress={prevWeek} style={styles.weekArrow}>
          <IconSymbol name="chevron.left" size={20} color={colors.muted} />
        </TouchableOpacity>
        {weekDays.map((day) => {
          const isSelected = isSameDay(day, selectedDate);
          const isToday = isSameDay(day, new Date());
          const key = `${day.getFullYear()}-${day.getMonth()}-${day.getDate()}`;
          const hasEvents = eventDays.has(key);
          return (
            <TouchableOpacity
              key={key}
              style={[styles.dayBtn, isSelected && { backgroundColor: colors.accent3 }]}
              onPress={() => {
                setSelectedDate(day);
                if (Platform.OS !== "web") Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
              }}
            >
              <Text style={[styles.dayName, { color: isSelected ? "#fff" : colors.muted }]}>
                {DAYS[day.getDay()]}
              </Text>
              <Text style={[styles.dayNum, { color: isSelected ? "#fff" : isToday ? colors.accent3 : colors.foreground }]}>
                {day.getDate()}
              </Text>
              {hasEvents && (
                <View style={[styles.eventDot, { backgroundColor: isSelected ? "#fff" : colors.accent3 }]} />
              )}
            </TouchableOpacity>
          );
        })}
        <TouchableOpacity onPress={nextWeek} style={styles.weekArrow}>
          <IconSymbol name="chevron.right" size={20} color={colors.muted} />
        </TouchableOpacity>
      </View>

      {/* Day Label */}
      <View style={styles.dayLabel}>
        <Text style={[styles.dayLabelText, { color: colors.foreground }]}>
          {isSameDay(selectedDate, new Date())
            ? "Today"
            : selectedDate.toLocaleDateString("en-US", { weekday: "long", month: "long", day: "numeric" })}
        </Text>
        <Text style={[styles.eventCount, { color: colors.muted }]}>
          {dayEvents.length} event{dayEvents.length !== 1 ? "s" : ""}
        </Text>
      </View>

      {/* Events */}
      {!isAuthenticated ? (
        <View style={styles.emptyCenter}>
          <Text style={[styles.emptyTitle, { color: colors.foreground }]}>Sign in to see events</Text>
        </View>
      ) : (
        <FlatList
          data={dayEvents}
          keyExtractor={(item) => String(item.id)}
          renderItem={({ item }) => (
            <EventCard event={item} colors={colors} onDelete={() => handleDelete(item)} />
          )}
          contentContainerStyle={styles.listContent}
          ListEmptyComponent={
            <View style={styles.emptyCenter}>
              <IconSymbol name="calendar" size={48} color={colors.muted} />
              <Text style={[styles.emptyTitle, { color: colors.foreground }]}>No events</Text>
              <Text style={[styles.emptySubtitle, { color: colors.muted }]}>Tap + to add an event</Text>
            </View>
          }
          showsVerticalScrollIndicator={false}
          ListFooterComponent={
            <View style={styles.adFooter}>
              <NativeAdCard adUnitId={CALENDAR_AD_UNIT_ID} />
            </View>
          }
        />
      )}

      <AddEventModal
        visible={showAdd}
        onClose={() => setShowAdd(false)}
        onAdd={handleAdd}
        colors={colors}
        defaultDate={selectedDate}
      />
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  header: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", paddingHorizontal: 16, paddingVertical: 12, borderBottomWidth: 0.5 },
  screenTitle: { fontSize: 24, fontWeight: "700" },
  fabSmall: { width: 40, height: 40, borderRadius: 20, alignItems: "center", justifyContent: "center" },
  weekStrip: { flexDirection: "row", alignItems: "center", paddingVertical: 8, borderBottomWidth: 0.5 },
  weekArrow: { paddingHorizontal: 8, paddingVertical: 4 },
  dayBtn: { flex: 1, alignItems: "center", paddingVertical: 8, borderRadius: 12, marginHorizontal: 2 },
  dayName: { fontSize: 10, fontWeight: "600", textTransform: "uppercase" },
  dayNum: { fontSize: 18, fontWeight: "700", marginTop: 2 },
  eventDot: { width: 5, height: 5, borderRadius: 3, marginTop: 3 },
  dayLabel: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", paddingHorizontal: 16, paddingVertical: 12 },
  dayLabelText: { fontSize: 17, fontWeight: "600" },
  eventCount: { fontSize: 13 },
  listContent: { padding: 16, paddingBottom: 100, gap: 10 },
  eventCard: { flexDirection: "row", borderRadius: 14, borderWidth: 1, overflow: "hidden" },
  eventTimeBar: { width: 4 },
  eventBody: { flex: 1, padding: 12 },
  eventTitle: { fontSize: 16, fontWeight: "600", marginBottom: 4 },
  eventTime: { fontSize: 13, fontWeight: "500" },
  eventMeta: { fontSize: 12, marginTop: 4 },
  eventDesc: { fontSize: 13, marginTop: 4, lineHeight: 18 },
  emptyCenter: { flex: 1, alignItems: "center", justifyContent: "center", padding: 40, gap: 8 },
  emptyTitle: { fontSize: 18, fontWeight: "600" },
  emptySubtitle: { fontSize: 14, textAlign: "center" },
  // Modal
  modalOverlay: { flex: 1, backgroundColor: "rgba(0,0,0,0.5)", justifyContent: "flex-end" },
  modalSheet: { borderTopLeftRadius: 24, borderTopRightRadius: 24, padding: 24, paddingBottom: 40 },
  modalHeader: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginBottom: 16 },
  modalTitle: { fontSize: 20, fontWeight: "700" },
  fieldLabel: { fontSize: 13, fontWeight: "600", marginBottom: 6, marginTop: 8 },
  input: { borderRadius: 12, borderWidth: 1, padding: 14, fontSize: 15, marginBottom: 4 },
  inputMulti: { minHeight: 80, textAlignVertical: "top" },
  timeRow: { flexDirection: "row", alignItems: "center", gap: 8, marginBottom: 4 },
  timeInput: { width: 60, borderRadius: 12, borderWidth: 1, padding: 12, fontSize: 18, textAlign: "center" },
  timeSep: { fontSize: 22, fontWeight: "700" },
  addBtn: { borderRadius: 14, padding: 16, alignItems: "center", marginTop: 16 },
  addBtnText: { color: "#fff", fontSize: 16, fontWeight: "700" },
  adFooter: { paddingTop: 4, paddingBottom: 24 },
});
