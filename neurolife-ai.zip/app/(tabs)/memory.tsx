import { useState, useRef, useEffect } from "react";
import {
  ActivityIndicator,
  Alert,
  FlatList,
  KeyboardAvoidingView,
  Modal,
  Platform,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";
import * as Haptics from "expo-haptics";
import {
  useAudioRecorder,
  requestRecordingPermissionsAsync,
  setAudioModeAsync,
  RecordingPresets,
} from "expo-audio";
import * as FileSystem from "expo-file-system/legacy";
import { useRouter } from "expo-router";

import { ScreenContainer } from "@/components/screen-container";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { useColors } from "@/hooks/use-colors";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/hooks/use-auth";
import { NativeAdCard } from "@/components/native-ad-card";

// Platform-specific ad unit IDs for Memory/Notes screen
const NOTES_AD_UNIT_ID = Platform.select({
  android: 'ca-app-pub-1720679341163644/5284104196',
  ios: 'ca-app-pub-1720679341163644/3807742122',
  default: '',
});

// ─── Category Config ──────────────────────────────────────────────────────────

const NOTE_CATEGORIES = {
  all:     { label: "All",     icon: "📋", color: "#6C63FF" },
  note:    { label: "Notes",   icon: "📝", color: "#6C63FF" },
  voice:   { label: "Voice",   icon: "🎙️", color: "#F87171" },
  idea:    { label: "Ideas",   icon: "💡", color: "#FBBF24" },
  meeting: { label: "Meeting", icon: "👥", color: "#4ECDC4" },
  general: { label: "General", icon: "📌", color: "#9CA3AF" },
} as const;

type NoteCategory = keyof typeof NOTE_CATEGORIES;
type NoteType = Exclude<NoteCategory, "all">;

// ─── Note Card ────────────────────────────────────────────────────────────────

function NoteCard({ note, colors, onPress, onDelete }: {
  note: any; colors: any;
  onPress: () => void; onDelete: () => void;
}) {
  const cfg = NOTE_CATEGORIES[note.category as NoteCategory] ?? NOTE_CATEGORIES.note;
  const tags: string[] = note.tags ? JSON.parse(note.tags) : [];

  // Try to parse smart-notes JSON content for preview
  let previewContent = note.content ?? "";
  let isSmartNote = false;
  try {
    const parsed = JSON.parse(note.content ?? "");
    if (parsed.summary || parsed.keyPoints) {
      previewContent = parsed.summary ?? parsed.keyPoints?.[0] ?? "";
      isSmartNote = true;
    }
  } catch { /* plain text */ }

  return (
    <TouchableOpacity
      onPress={onPress}
      style={[styles.noteCard, { backgroundColor: colors.surface, borderColor: colors.border }]}
      activeOpacity={0.75}
    >
      <View style={styles.noteCardHeader}>
        <View style={[styles.categoryBadge, { backgroundColor: cfg.color + "22" }]}>
          <Text style={{ fontSize: 12 }}>{cfg.icon}</Text>
          <Text style={[styles.categoryBadgeText, { color: cfg.color }]}>{cfg.label}</Text>
          {isSmartNote && (
            <View style={[styles.smartBadge, { backgroundColor: colors.primary }]}>
              <Text style={styles.smartBadgeText}>AI</Text>
            </View>
          )}
        </View>
        <View style={{ flexDirection: "row", alignItems: "center", gap: 8 }}>
          <Text style={[styles.noteDate, { color: colors.muted }]}>
            {new Date(note.createdAt).toLocaleDateString("en-US", { month: "short", day: "numeric" })}
          </Text>
          <TouchableOpacity onPress={onDelete} hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}>
            <IconSymbol name="trash" size={15} color={colors.muted} />
          </TouchableOpacity>
        </View>
      </View>

      <Text style={[styles.noteTitle, { color: colors.foreground }]} numberOfLines={2}>{note.title}</Text>

      {previewContent ? (
        <Text style={[styles.noteContent, { color: colors.muted }]} numberOfLines={2}>{previewContent}</Text>
      ) : null}

      {note.transcription ? (
        <View style={[styles.transcriptionBox, { backgroundColor: colors.background, borderColor: colors.border }]}>
          <IconSymbol name="waveform" size={14} color={colors.primary} />
          <Text style={[styles.transcriptionText, { color: colors.muted }]} numberOfLines={1}>{note.transcription}</Text>
        </View>
      ) : null}

      {tags.length > 0 ? (
        <View style={styles.tagsRow}>
          {tags.slice(0, 4).map((tag) => (
            <View key={tag} style={[styles.tag, { backgroundColor: colors.primary + "22" }]}>
              <Text style={[styles.tagText, { color: colors.primary }]}>#{tag}</Text>
            </View>
          ))}
        </View>
      ) : null}

      {/* Tap hint */}
      <View style={styles.tapHint}>
        <IconSymbol name="chevron.right" size={12} color={colors.muted} />
      </View>
    </TouchableOpacity>
  );
}

// ─── Add Note Modal ───────────────────────────────────────────────────────────

function AddNoteModal({ visible, onClose, onAdd, colors, initialCategory }: {
  visible: boolean; onClose: () => void;
  onAdd: (data: any) => void;
  colors: any;
  initialCategory?: NoteType;
}) {
  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");
  const [category, setCategory] = useState<NoteType>(initialCategory ?? "note");
  const [tags, setTags] = useState("");
  // Meeting-specific
  const [attendees, setAttendees] = useState("");
  const [actionItems, setActionItems] = useState("");

  useEffect(() => {
    if (visible) setCategory(initialCategory ?? "note");
  }, [visible, initialCategory]);

  const handleAdd = () => {
    if (!title.trim()) return;
    const tagList = tags.split(",").map((t) => t.trim()).filter(Boolean);

    let finalContent = content.trim() || undefined;

    // For meeting notes, build structured content
    if (category === "meeting" && (attendees.trim() || actionItems.trim())) {
      const attendeeList = attendees.split(",").map((a) => a.trim()).filter(Boolean);
      const actionList = actionItems.split("\n").map((a) => a.trim()).filter(Boolean);
      finalContent = JSON.stringify({
        summary: content.trim() || undefined,
        keyPoints: actionList.length ? actionList : undefined,
        attendees: attendeeList.length ? attendeeList : undefined,
        actionItems: actionList.length ? actionList : undefined,
      });
    }

    // For idea notes, build structured content
    if (category === "idea" && content.trim()) {
      const points = content.split("\n").map((p) => p.trim()).filter(Boolean);
      if (points.length > 1) {
        finalContent = JSON.stringify({
          summary: points[0],
          keyPoints: points.slice(1),
        });
      }
    }

    onAdd({ title: title.trim(), content: finalContent, category, tags: tagList.length ? tagList : undefined });
    setTitle(""); setContent(""); setCategory(initialCategory ?? "note"); setTags(""); setAttendees(""); setActionItems("");
    onClose();
  };

  const noteCategories = (Object.entries(NOTE_CATEGORIES) as [NoteCategory, typeof NOTE_CATEGORIES[NoteCategory]][])
    .filter(([k]) => k !== "all") as [NoteType, typeof NOTE_CATEGORIES[NoteType]][];

  const cfg = NOTE_CATEGORIES[category];

  return (
    <Modal visible={visible} animationType="slide" transparent onRequestClose={onClose}>
      <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === "ios" ? "padding" : "height"}>
        <View style={styles.modalOverlay}>
          <ScrollView keyboardShouldPersistTaps="handled" bounces={false}>
            <View style={[styles.modalSheet, { backgroundColor: colors.surface }]}>
              <View style={styles.modalHeader}>
                <View style={{ flexDirection: "row", alignItems: "center", gap: 8 }}>
                  <Text style={{ fontSize: 20 }}>{cfg.icon}</Text>
                  <Text style={[styles.modalTitle, { color: colors.foreground }]}>
                    New {cfg.label}
                  </Text>
                </View>
                <TouchableOpacity onPress={onClose} hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}>
                  <IconSymbol name="xmark.circle.fill" size={26} color={colors.muted} />
                </TouchableOpacity>
              </View>

              {/* Category selector */}
              <Text style={[styles.fieldLabel, { color: colors.muted }]}>Type</Text>
              <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginBottom: 16 }}>
                <View style={{ flexDirection: "row", gap: 8 }}>
                  {noteCategories.map(([key, c]) => (
                    <TouchableOpacity
                      key={key}
                      style={[styles.catChip, {
                        backgroundColor: category === key ? c.color : c.color + "22",
                        borderColor: c.color,
                      }]}
                      onPress={() => setCategory(key)}
                    >
                      <Text style={{ fontSize: 14 }}>{c.icon}</Text>
                      <Text style={[styles.catChipText, { color: category === key ? "#fff" : c.color }]}>{c.label}</Text>
                    </TouchableOpacity>
                  ))}
                </View>
              </ScrollView>

              <TextInput
                style={[styles.input, { backgroundColor: colors.background, color: colors.foreground, borderColor: colors.border }]}
                placeholder="Title..."
                placeholderTextColor={colors.muted}
                value={title}
                onChangeText={setTitle}
                autoFocus
              />

              {/* Meeting-specific fields */}
              {category === "meeting" ? (
                <>
                  <TextInput
                    style={[styles.input, { backgroundColor: colors.background, color: colors.foreground, borderColor: colors.border }]}
                    placeholder="Attendees (comma-separated)..."
                    placeholderTextColor={colors.muted}
                    value={attendees}
                    onChangeText={setAttendees}
                  />
                  <TextInput
                    style={[styles.input, styles.inputMulti, { backgroundColor: colors.background, color: colors.foreground, borderColor: colors.border }]}
                    placeholder="Meeting notes / summary..."
                    placeholderTextColor={colors.muted}
                    value={content}
                    onChangeText={setContent}
                    multiline
                    numberOfLines={4}
                  />
                  <TextInput
                    style={[styles.input, styles.inputMulti, { backgroundColor: colors.background, color: colors.foreground, borderColor: colors.border }]}
                    placeholder={"Action items (one per line)...\n• Follow up with team\n• Send report by Friday"}
                    placeholderTextColor={colors.muted}
                    value={actionItems}
                    onChangeText={setActionItems}
                    multiline
                    numberOfLines={4}
                  />
                </>
              ) : category === "idea" ? (
                <>
                  <TextInput
                    style={[styles.input, styles.inputMulti, { backgroundColor: colors.background, color: colors.foreground, borderColor: colors.border }]}
                    placeholder={"Describe your idea...\nFirst line = summary\nNext lines = key aspects"}
                    placeholderTextColor={colors.muted}
                    value={content}
                    onChangeText={setContent}
                    multiline
                    numberOfLines={6}
                  />
                </>
              ) : (
                <TextInput
                  style={[styles.input, styles.inputMulti, { backgroundColor: colors.background, color: colors.foreground, borderColor: colors.border }]}
                  placeholder="Content..."
                  placeholderTextColor={colors.muted}
                  value={content}
                  onChangeText={setContent}
                  multiline
                  numberOfLines={5}
                />
              )}

              <TextInput
                style={[styles.input, { backgroundColor: colors.background, color: colors.foreground, borderColor: colors.border }]}
                placeholder="Tags (comma-separated)..."
                placeholderTextColor={colors.muted}
                value={tags}
                onChangeText={setTags}
                returnKeyType="done"
              />

              <TouchableOpacity
                style={[styles.addBtn, { backgroundColor: cfg.color, opacity: title.trim() ? 1 : 0.5 }]}
                onPress={handleAdd}
                disabled={!title.trim()}
              >
                <Text style={styles.addBtnText}>Save {cfg.label}</Text>
              </TouchableOpacity>
            </View>
          </ScrollView>
        </View>
      </KeyboardAvoidingView>
    </Modal>
  );
}

// ─── Smart Notes Modal (Audio → AI Key Points) ────────────────────────────────

function SmartNotesModal({ visible, onClose, onSave, colors }: {
  visible: boolean; onClose: () => void;
  onSave: (note: any) => void;
  colors: any;
}) {
  const recorder = useAudioRecorder(RecordingPresets.HIGH_QUALITY);
  const [step, setStep] = useState<"record" | "processing" | "preview">("record");
  const [isRecording, setIsRecording] = useState(false);
  const [duration, setDuration] = useState(0);
  const [noteType, setNoteType] = useState<"note" | "meeting" | "idea">("note");
  const [result, setResult] = useState<any>(null);
  const [editTitle, setEditTitle] = useState("");
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const uploadVoice = trpc.voice.upload.useMutation();
  const audioToKeyPoints = trpc.ai.audioToKeyPoints.useMutation();

  useEffect(() => {
    if (!visible) {
      setStep("record");
      setIsRecording(false);
      setDuration(0);
      setResult(null);
      setEditTitle("");
      if (timerRef.current) clearInterval(timerRef.current);
    }
  }, [visible]);

  useEffect(() => {
    return () => { if (timerRef.current) clearInterval(timerRef.current); };
  }, []);

  const startRecording = async () => {
    if ((Platform.OS as string) === "web") {
      Alert.alert("Not supported", "Voice recording is not available on web.");
      return;
    }
    const { granted } = await requestRecordingPermissionsAsync();
    if (!granted) {
      Alert.alert("Permission required", "Please allow microphone access.");
      return;
    }
    await setAudioModeAsync({ playsInSilentMode: true, allowsRecording: true });
    await recorder.prepareToRecordAsync();
    recorder.record();
    setIsRecording(true);
    setDuration(0);
    timerRef.current = setInterval(() => setDuration((d) => d + 1), 1000);
    if (Platform.OS !== "web") Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Heavy);
  };

  const stopAndProcess = async () => {
    if (timerRef.current) clearInterval(timerRef.current);
    await recorder.stop();
    setIsRecording(false);
    const uri = recorder.uri;
    if (!uri) { Alert.alert("Error", "No audio recorded."); return; }

    setStep("processing");
    if (Platform.OS !== "web") Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);

    try {
      const base64 = await FileSystem.readAsStringAsync(uri, { encoding: FileSystem.EncodingType.Base64 });
      const mimeType = uri.endsWith(".m4a") ? "audio/m4a" : "audio/m4a";
      const { url: audioUrl } = await uploadVoice.mutateAsync({ base64, mimeType });
      const res = await audioToKeyPoints.mutateAsync({ audioUrl, noteType });
      setResult({ ...res, audioUrl });
      setEditTitle(res.title ?? "Smart Note");
      setStep("preview");
    } catch (e: any) {
      Alert.alert("Processing failed", e?.message ?? "Could not process audio.");
      setStep("record");
    }
  };

  const handleSave = () => {
    if (!result) return;
    const { title: _t, transcription, audioUrl, ...rest } = result;
    onSave({
      title: editTitle.trim() || result.title,
      content: JSON.stringify(rest),
      category: noteType === "meeting" ? "meeting" : noteType === "idea" ? "idea" : "note",
      audioUrl,
      transcription,
      tags: result.tags,
    });
    onClose();
  };

  const formatDuration = (s: number) => `${Math.floor(s / 60).toString().padStart(2, "0")}:${(s % 60).toString().padStart(2, "0")}`;

  const noteTypeConfig = {
    note:    { label: "General Note", icon: "📝", color: "#6C63FF" },
    meeting: { label: "Meeting",      icon: "👥", color: "#4ECDC4" },
    idea:    { label: "Idea",         icon: "💡", color: "#FBBF24" },
  };

  return (
    <Modal visible={visible} animationType="slide" transparent onRequestClose={onClose}>
      <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === "ios" ? "padding" : "height"}>
        <View style={styles.modalOverlay}>
          <ScrollView keyboardShouldPersistTaps="handled" bounces={false}>
            <View style={[styles.modalSheet, { backgroundColor: colors.surface }]}>
              {/* Header */}
              <View style={styles.modalHeader}>
                <View style={{ flexDirection: "row", alignItems: "center", gap: 8 }}>
                  <Text style={{ fontSize: 22 }}>✨</Text>
                  <Text style={[styles.modalTitle, { color: colors.foreground }]}>Smart Notes</Text>
                </View>
                <TouchableOpacity onPress={onClose} hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}>
                  <IconSymbol name="xmark.circle.fill" size={26} color={colors.muted} />
                </TouchableOpacity>
              </View>

              {step === "record" && (
                <>
                  <Text style={[styles.smartDesc, { color: colors.muted }]}>
                    Record your voice and AI will extract key points, summaries, and action items automatically.
                  </Text>

                  {/* Note type selector */}
                  <Text style={[styles.fieldLabel, { color: colors.muted }]}>Note Type</Text>
                  <View style={{ flexDirection: "row", gap: 8, marginBottom: 20 }}>
                    {(Object.entries(noteTypeConfig) as [typeof noteType, typeof noteTypeConfig[typeof noteType]][]).map(([key, c]) => (
                      <TouchableOpacity
                        key={key}
                        style={[styles.typeChip, {
                          backgroundColor: noteType === key ? c.color : c.color + "22",
                          borderColor: c.color,
                          flex: 1,
                        }]}
                        onPress={() => setNoteType(key)}
                      >
                        <Text style={{ fontSize: 18 }}>{c.icon}</Text>
                        <Text style={[styles.typeChipText, { color: noteType === key ? "#fff" : c.color }]}>{c.label}</Text>
                      </TouchableOpacity>
                    ))}
                  </View>

                  {/* Recording area */}
                  <View style={[styles.recordArea, { backgroundColor: colors.background, borderColor: isRecording ? colors.error : colors.border }]}>
                    <View style={[styles.recordCircle, { backgroundColor: isRecording ? colors.error + "20" : colors.primary + "20" }]}>
                      <IconSymbol name={isRecording ? "waveform" : "mic.fill"} size={36} color={isRecording ? colors.error : colors.primary} />
                    </View>
                    <Text style={[styles.recordStatus, { color: isRecording ? colors.error : colors.foreground }]}>
                      {isRecording ? `Recording... ${formatDuration(duration)}` : "Tap to start recording"}
                    </Text>
                    {isRecording && (
                      <Text style={[styles.recordHint, { color: colors.muted }]}>Speak clearly. Tap Stop when done.</Text>
                    )}
                  </View>

                  <TouchableOpacity
                    style={[styles.recordBtn, { backgroundColor: isRecording ? colors.error : colors.primary }]}
                    onPress={isRecording ? stopAndProcess : startRecording}
                  >
                    <IconSymbol name={isRecording ? "stop.fill" : "mic.fill"} size={20} color="#fff" />
                    <Text style={styles.recordBtnText}>{isRecording ? "Stop & Process" : "Start Recording"}</Text>
                  </TouchableOpacity>
                </>
              )}

              {step === "processing" && (
                <View style={styles.processingArea}>
                  <ActivityIndicator size="large" color={colors.primary} />
                  <Text style={[styles.processingTitle, { color: colors.foreground }]}>Processing Audio...</Text>
                  <Text style={[styles.processingDesc, { color: colors.muted }]}>
                    Transcribing and extracting key points with AI
                  </Text>
                </View>
              )}

              {step === "preview" && result && (
                <>
                  <View style={[styles.previewBanner, { backgroundColor: colors.success + "18", borderColor: colors.success + "40" }]}>
                    <IconSymbol name="checkmark.circle.fill" size={18} color={colors.success} />
                    <Text style={[styles.previewBannerText, { color: colors.success }]}>AI processing complete!</Text>
                  </View>

                  <Text style={[styles.fieldLabel, { color: colors.muted }]}>Title (editable)</Text>
                  <TextInput
                    style={[styles.input, { backgroundColor: colors.background, color: colors.foreground, borderColor: colors.border, marginBottom: 16 }]}
                    value={editTitle}
                    onChangeText={setEditTitle}
                    placeholder="Note title..."
                    placeholderTextColor={colors.muted}
                  />

                  {result.summary ? (
                    <View style={[styles.previewSection, { backgroundColor: colors.primary + "12", borderColor: colors.primary + "30" }]}>
                      <Text style={[styles.previewSectionLabel, { color: colors.primary }]}>Summary</Text>
                      <Text style={[styles.previewSectionText, { color: colors.foreground }]}>{result.summary}</Text>
                    </View>
                  ) : null}

                  {result.keyPoints?.length > 0 ? (
                    <View style={[styles.previewSection, { backgroundColor: colors.surface, borderColor: colors.border }]}>
                      <Text style={[styles.previewSectionLabel, { color: colors.muted }]}>Key Points</Text>
                      {result.keyPoints.map((pt: string, i: number) => (
                        <View key={i} style={styles.keyPointRow}>
                          <View style={[styles.keyPointDot, { backgroundColor: colors.primary }]} />
                          <Text style={[styles.keyPointText, { color: colors.foreground }]}>{pt}</Text>
                        </View>
                      ))}
                    </View>
                  ) : null}

                  {result.actionItems?.length > 0 ? (
                    <View style={[styles.previewSection, { backgroundColor: "#4ECDC4" + "12", borderColor: "#4ECDC4" + "30" }]}>
                      <Text style={[styles.previewSectionLabel, { color: "#4ECDC4" }]}>Action Items</Text>
                      {result.actionItems.map((item: string, i: number) => (
                        <View key={i} style={styles.keyPointRow}>
                          <View style={[styles.keyPointDot, { backgroundColor: "#4ECDC4" }]} />
                          <Text style={[styles.keyPointText, { color: colors.foreground }]}>{item}</Text>
                        </View>
                      ))}
                    </View>
                  ) : null}

                  {result.transcription ? (
                    <View style={[styles.previewSection, { backgroundColor: colors.background, borderColor: colors.border }]}>
                      <Text style={[styles.previewSectionLabel, { color: colors.muted }]}>Transcript</Text>
                      <Text style={[styles.transcriptText, { color: colors.muted }]} numberOfLines={4}>{result.transcription}</Text>
                    </View>
                  ) : null}

                  <View style={{ flexDirection: "row", gap: 10, marginTop: 8 }}>
                    <TouchableOpacity
                      style={[styles.secondaryBtn, { borderColor: colors.border, flex: 1 }]}
                      onPress={() => setStep("record")}
                    >
                      <Text style={[styles.secondaryBtnText, { color: colors.muted }]}>Re-record</Text>
                    </TouchableOpacity>
                    <TouchableOpacity
                      style={[styles.addBtn, { backgroundColor: colors.primary, flex: 2 }]}
                      onPress={handleSave}
                    >
                      <Text style={styles.addBtnText}>Save Smart Note</Text>
                    </TouchableOpacity>
                  </View>
                </>
              )}
            </View>
          </ScrollView>
        </View>
      </KeyboardAvoidingView>
    </Modal>
  );
}

// ─── Voice Note Recorder (inline) ────────────────────────────────────────────

function VoiceRecorder({ colors, onSave }: { colors: any; onSave: (uri: string, duration: number) => void }) {
  const recorder = useAudioRecorder(RecordingPresets.HIGH_QUALITY);
  const [isRecording, setIsRecording] = useState(false);
  const [duration, setDuration] = useState(0);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const startRecording = async () => {
    if ((Platform.OS as string) === "web") {
      Alert.alert("Not supported", "Voice recording is not available on web.");
      return;
    }
    const { granted } = await requestRecordingPermissionsAsync();
    if (!granted) {
      Alert.alert("Permission required", "Please allow microphone access.");
      return;
    }
    await setAudioModeAsync({ playsInSilentMode: true, allowsRecording: true });
    await recorder.prepareToRecordAsync();
    recorder.record();
    setIsRecording(true);
    setDuration(0);
    timerRef.current = setInterval(() => setDuration((d) => d + 1), 1000);
    if (Platform.OS !== "web") Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Heavy);
  };

  const stopRecording = async () => {
    if (timerRef.current) clearInterval(timerRef.current);
    await recorder.stop();
    setIsRecording(false);
    const uri = recorder.uri;
    if (uri) onSave(uri, duration);
    if (Platform.OS !== "web") Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
  };

  useEffect(() => {
    return () => { if (timerRef.current) clearInterval(timerRef.current); };
  }, []);

  const formatDuration = (s: number) => `${Math.floor(s / 60).toString().padStart(2, "0")}:${(s % 60).toString().padStart(2, "0")}`;

  return (
    <View style={[styles.voiceRecorder, { backgroundColor: colors.surface, borderColor: isRecording ? colors.error : colors.border }]}>
      <View style={styles.voiceLeft}>
        <View style={[styles.voiceIconWrap, { backgroundColor: isRecording ? colors.error + "20" : colors.primary + "20" }]}>
          <IconSymbol name={isRecording ? "waveform" : "mic.fill"} size={18} color={isRecording ? colors.error : colors.primary} />
        </View>
        <View>
          <Text style={[styles.voiceLabel, { color: isRecording ? colors.error : colors.foreground }]}>
            {isRecording ? "Recording..." : "Quick Voice Note"}
          </Text>
          <Text style={[styles.voiceSub, { color: colors.muted }]}>
            {isRecording ? formatDuration(duration) : "Tap to record, auto-transcribed"}
          </Text>
        </View>
      </View>
      <TouchableOpacity
        style={[styles.voiceBtn, { backgroundColor: isRecording ? colors.error : colors.primary }]}
        onPress={isRecording ? stopRecording : startRecording}
      >
        <IconSymbol name={isRecording ? "stop.fill" : "mic.fill"} size={16} color="#fff" />
      </TouchableOpacity>
    </View>
  );
}

// ─── Main Screen ──────────────────────────────────────────────────────────────

export default function MemoryScreen() {
  const colors = useColors();
  const router = useRouter();
  const { isAuthenticated } = useAuth();
  const [showAdd, setShowAdd] = useState(false);
  const [showSmartNotes, setShowSmartNotes] = useState(false);
  const [addCategory, setAddCategory] = useState<NoteType>("note");
  const [category, setCategory] = useState<NoteCategory>("all");
  const [search, setSearch] = useState("");

  const { data: notes = [], refetch } = trpc.notes.list.useQuery(
    { category: category === "all" ? undefined : category, search: search || undefined },
    {
      enabled: isAuthenticated,
      staleTime: 0,
      gcTime: 5 * 60 * 1000,
    }
  );

  const utils = trpc.useUtils();
  const notesQueryInput = { category: category === "all" ? undefined : category, search: search || undefined };

  const createNote = trpc.notes.create.useMutation({
    onMutate: async (newNote) => {
      await utils.notes.list.cancel();
      const prev = utils.notes.list.getData(notesQueryInput as any);
      utils.notes.list.setData(notesQueryInput as any, (old: any) => [
        { id: Date.now(), title: newNote.title, content: newNote.content ?? null, category: newNote.category ?? "general", tags: newNote.tags ?? null, audioUrl: newNote.audioUrl ?? null, transcription: newNote.transcription ?? null, pinned: false, userId: "", createdAt: new Date().toISOString() },
        ...(old ?? []),
      ]);
      return { prev };
    },
    onError: (_err: any, _vars: any, ctx: any) => { if (ctx?.prev) utils.notes.list.setData(notesQueryInput as any, ctx.prev); },
    onSettled: () => utils.notes.list.invalidate(),
  });
  const deleteNote = trpc.notes.delete.useMutation({
    onMutate: async ({ id }) => {
      await utils.notes.list.cancel();
      const prev = utils.notes.list.getData(notesQueryInput as any);
      utils.notes.list.setData(notesQueryInput as any, (old: any) =>
        (old ?? []).filter((n: any) => n.id !== id)
      );
      return { prev };
    },
    onError: (_err: any, _vars: any, ctx: any) => { if (ctx?.prev) utils.notes.list.setData(notesQueryInput as any, ctx.prev); },
    onSettled: () => utils.notes.list.invalidate(),
  });
  const uploadVoice = trpc.voice.upload.useMutation();
  const transcribe = trpc.voice.transcribe.useMutation();

  const handleAdd = (data: any) => {
    createNote.mutate(data);
    if (Platform.OS !== "web") Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
  };

  const handleSmartNoteSave = async (data: any) => {
    await createNote.mutateAsync(data);
    refetch();
    if (Platform.OS !== "web") Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
  };

  const handleVoiceSave = async (uri: string, _duration: number) => {
    const timeLabel = new Date().toLocaleTimeString("en-US", { hour: "numeric", minute: "2-digit" });
    try {
      const base64 = await FileSystem.readAsStringAsync(uri, { encoding: FileSystem.EncodingType.Base64 });
      const mimeType = uri.endsWith(".m4a") ? "audio/m4a" : "audio/m4a";
      const { url: audioUrl } = await uploadVoice.mutateAsync({ base64, mimeType });

      await createNote.mutateAsync({
        title: `Voice Note – ${timeLabel}`,
        category: "voice",
        audioUrl,
      });

      try {
        const result = await transcribe.mutateAsync({ audioUrl });
        if (result.text) {
          await createNote.mutateAsync({
            title: `Voice Note – ${timeLabel}`,
            category: "voice",
            audioUrl,
            transcription: result.text,
          });
          refetch();
        }
      } catch { /* silent */ }
    } catch (e: any) {
      Alert.alert("Upload failed", e?.message ?? "Could not save voice note.");
    }
  };

  const handleDelete = (id: number) => {
    Alert.alert("Delete Note", "Remove this note?", [
      { text: "Cancel", style: "cancel" },
      { text: "Delete", style: "destructive", onPress: () => deleteNote.mutate({ id }) },
    ]);
  };

  const openNote = (id: number) => {
    router.push((`/note-detail?id=${id}`) as any);
  };

  const openAddWithCategory = (cat: NoteType) => {
    setAddCategory(cat);
    setShowAdd(true);
  };

  return (
    <ScreenContainer containerClassName="bg-background">
      {/* Header */}
      <View style={[styles.header, { borderBottomColor: colors.border }]}>
        <View>
          <Text style={[styles.screenTitle, { color: colors.foreground }]}>Memory</Text>
          <Text style={[styles.screenSubtitle, { color: colors.muted }]}>{notes.length} notes</Text>
        </View>
        <TouchableOpacity
          style={[styles.fabSmall, { backgroundColor: colors.primary }]}
          onPress={() => openAddWithCategory("note")}
        >
          <IconSymbol name="plus" size={22} color="#fff" />
        </TouchableOpacity>
      </View>

      {/* Search */}
      <View style={[styles.searchContainer, { backgroundColor: colors.surface, borderBottomColor: colors.border }]}>
        <IconSymbol name="magnifyingglass" size={18} color={colors.muted} />
        <TextInput
          style={[styles.searchInput, { color: colors.foreground }]}
          placeholder="Search notes..."
          placeholderTextColor={colors.muted}
          value={search}
          onChangeText={setSearch}
        />
        {search ? (
          <TouchableOpacity onPress={() => setSearch("")}>
            <IconSymbol name="xmark.circle.fill" size={18} color={colors.muted} />
          </TouchableOpacity>
        ) : null}
      </View>

      {/* Category Filter */}
      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        style={styles.filterScroll}
        contentContainerStyle={styles.filterContent}
      >
        {(Object.entries(NOTE_CATEGORIES) as [NoteCategory, typeof NOTE_CATEGORIES[NoteCategory]][]).map(([key, cfg]) => {
          const isActive = category === key;
          return (
            <TouchableOpacity
              key={key}
              style={[styles.filterChip, {
                backgroundColor: isActive ? cfg.color : cfg.color + "22",
                borderColor: cfg.color,
              }]}
              onPress={() => setCategory(key)}
            >
              <Text style={{ fontSize: 14 }}>{cfg.icon}</Text>
              <Text style={[styles.filterChipText, { color: isActive ? "#fff" : cfg.color }]}>{cfg.label}</Text>
            </TouchableOpacity>
          );
        })}
      </ScrollView>

      {/* Quick Action Buttons */}
      {isAuthenticated && (
        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          style={{ maxHeight: 56 }}
          contentContainerStyle={{ paddingHorizontal: 16, paddingVertical: 8, gap: 8, flexDirection: "row" }}
        >
          <TouchableOpacity
            style={[styles.quickBtn, { backgroundColor: "#FBBF24" + "22", borderColor: "#FBBF24" }]}
            onPress={() => openAddWithCategory("idea")}
          >
            <Text style={{ fontSize: 14 }}>💡</Text>
            <Text style={[styles.quickBtnText, { color: "#FBBF24" }]}>New Idea</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={[styles.quickBtn, { backgroundColor: "#4ECDC4" + "22", borderColor: "#4ECDC4" }]}
            onPress={() => openAddWithCategory("meeting")}
          >
            <Text style={{ fontSize: 14 }}>👥</Text>
            <Text style={[styles.quickBtnText, { color: "#4ECDC4" }]}>Meeting Notes</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={[styles.quickBtn, { backgroundColor: colors.primary + "22", borderColor: colors.primary }]}
            onPress={() => setShowSmartNotes(true)}
          >
            <Text style={{ fontSize: 14 }}>✨</Text>
            <Text style={[styles.quickBtnText, { color: colors.primary }]}>Smart Notes</Text>
          </TouchableOpacity>
        </ScrollView>
      )}

      {/* Voice Recorder */}
      {isAuthenticated && (
        <View style={{ paddingHorizontal: 16, paddingBottom: 8 }}>
          <VoiceRecorder colors={colors} onSave={handleVoiceSave} />
        </View>
      )}

      {/* Notes List */}
      {!isAuthenticated ? (
        <View style={styles.emptyCenter}>
          <Text style={[styles.emptyTitle, { color: colors.foreground }]}>Sign in to access Memory</Text>
        </View>
      ) : (
        <FlatList
          data={notes}
          keyExtractor={(item) => String(item.id)}
          renderItem={({ item }) => (
            <NoteCard
              note={item}
              colors={colors}
              onPress={() => openNote(item.id)}
              onDelete={() => handleDelete(item.id)}
            />
          )}
          contentContainerStyle={styles.listContent}
          ListEmptyComponent={
            <View style={styles.emptyCenter}>
              <Text style={{ fontSize: 48 }}>🧠</Text>
              <Text style={[styles.emptyTitle, { color: colors.foreground }]}>No notes yet</Text>
              <Text style={[styles.emptySubtitle, { color: colors.muted }]}>
                Tap + to write a note, record a voice note, or try Smart Notes to convert audio to key points
              </Text>
            </View>
          }
          showsVerticalScrollIndicator={false}
          ListFooterComponent={
            <View style={styles.adFooter}>
              <NativeAdCard adUnitId={NOTES_AD_UNIT_ID} />
            </View>
          }
        />
      )}
      <AddNoteModal
        visible={showAdd}
        onClose={() => setShowAdd(false)}
        onAdd={handleAdd}
        colors={colors}
        initialCategory={addCategory}
      />

      <SmartNotesModal
        visible={showSmartNotes}
        onClose={() => setShowSmartNotes(false)}
        onSave={handleSmartNoteSave}
        colors={colors}
      />
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  header: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", paddingHorizontal: 16, paddingVertical: 12, borderBottomWidth: 0.5 },
  screenTitle: { fontSize: 28, fontWeight: "700" },
  screenSubtitle: { fontSize: 13, marginTop: 2 },
  fabSmall: { width: 40, height: 40, borderRadius: 20, alignItems: "center", justifyContent: "center" },
  searchContainer: { flexDirection: "row", alignItems: "center", paddingHorizontal: 16, paddingVertical: 10, gap: 8, borderBottomWidth: 0.5 },
  searchInput: { flex: 1, fontSize: 15 },
  filterScroll: { maxHeight: 52 },
  filterContent: { paddingHorizontal: 16, paddingVertical: 8, gap: 8, flexDirection: "row" },
  filterChip: { flexDirection: "row", alignItems: "center", paddingHorizontal: 12, paddingVertical: 6, borderRadius: 20, borderWidth: 1, gap: 4 },
  filterChipText: { fontSize: 13, fontWeight: "600" },
  quickBtn: { flexDirection: "row", alignItems: "center", paddingHorizontal: 12, paddingVertical: 6, borderRadius: 16, borderWidth: 1, gap: 5 },
  quickBtnText: { fontSize: 13, fontWeight: "600" },
  voiceRecorder: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", borderRadius: 14, borderWidth: 1, padding: 12 },
  voiceLeft: { flexDirection: "row", alignItems: "center", gap: 10, flex: 1 },
  voiceIconWrap: { width: 36, height: 36, borderRadius: 18, alignItems: "center", justifyContent: "center" },
  voiceLabel: { fontSize: 14, fontWeight: "600" },
  voiceSub: { fontSize: 12, marginTop: 1 },
  voiceBtn: { width: 36, height: 36, borderRadius: 18, alignItems: "center", justifyContent: "center" },
  listContent: { padding: 16, paddingBottom: 100, gap: 12 },
  noteCard: { borderRadius: 16, borderWidth: 1, padding: 14 },
  noteCardHeader: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginBottom: 8 },
  categoryBadge: { flexDirection: "row", alignItems: "center", paddingHorizontal: 8, paddingVertical: 3, borderRadius: 10, gap: 4 },
  categoryBadgeText: { fontSize: 11, fontWeight: "600" },
  smartBadge: { paddingHorizontal: 5, paddingVertical: 1, borderRadius: 6 },
  smartBadgeText: { fontSize: 9, fontWeight: "800", color: "#fff" },
  noteDate: { fontSize: 12 },
  noteTitle: { fontSize: 16, fontWeight: "600", marginBottom: 4, lineHeight: 22 },
  noteContent: { fontSize: 14, lineHeight: 20, marginBottom: 8 },
  transcriptionBox: { flexDirection: "row", alignItems: "flex-start", borderRadius: 10, borderWidth: 1, padding: 10, gap: 6, marginBottom: 8 },
  transcriptionText: { flex: 1, fontSize: 13, lineHeight: 18 },
  tagsRow: { flexDirection: "row", flexWrap: "wrap", gap: 6 },
  tag: { paddingHorizontal: 8, paddingVertical: 3, borderRadius: 8 },
  tagText: { fontSize: 11, fontWeight: "600" },
  tapHint: { position: "absolute", right: 14, bottom: 14 },
  emptyCenter: { flex: 1, alignItems: "center", justifyContent: "center", padding: 40, gap: 8 },
  emptyTitle: { fontSize: 18, fontWeight: "600" },
  emptySubtitle: { fontSize: 14, textAlign: "center" },
  // Modal
  modalOverlay: { flex: 1, backgroundColor: "rgba(0,0,0,0.5)", justifyContent: "flex-end" },
  modalSheet: { borderTopLeftRadius: 24, borderTopRightRadius: 24, padding: 24, paddingBottom: 40 },
  modalHeader: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginBottom: 16 },
  modalTitle: { fontSize: 20, fontWeight: "700" },
  fieldLabel: { fontSize: 13, fontWeight: "600", marginBottom: 8 },
  input: { borderRadius: 12, borderWidth: 1, padding: 14, fontSize: 15, marginBottom: 12 },
  inputMulti: { minHeight: 100, textAlignVertical: "top" },
  catChip: { flexDirection: "row", alignItems: "center", paddingHorizontal: 12, paddingVertical: 7, borderRadius: 14, borderWidth: 1, gap: 5 },
  catChipText: { fontSize: 13, fontWeight: "600" },
  addBtn: { borderRadius: 14, padding: 16, alignItems: "center" },
  addBtnText: { color: "#fff", fontSize: 16, fontWeight: "700" },
  secondaryBtn: { borderRadius: 14, padding: 16, alignItems: "center", borderWidth: 1 },
  secondaryBtnText: { fontSize: 16, fontWeight: "600" },
  // Smart Notes
  smartDesc: { fontSize: 14, lineHeight: 20, marginBottom: 16 },
  typeChip: { flexDirection: "column", alignItems: "center", paddingVertical: 10, borderRadius: 14, borderWidth: 1, gap: 4 },
  typeChipText: { fontSize: 12, fontWeight: "600", textAlign: "center" },
  recordArea: { borderRadius: 16, borderWidth: 1.5, borderStyle: "dashed", padding: 28, alignItems: "center", gap: 12, marginBottom: 16 },
  recordCircle: { width: 80, height: 80, borderRadius: 40, alignItems: "center", justifyContent: "center" },
  recordStatus: { fontSize: 16, fontWeight: "600" },
  recordHint: { fontSize: 13, textAlign: "center" },
  recordBtn: { borderRadius: 14, padding: 16, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 8 },
  recordBtnText: { color: "#fff", fontSize: 16, fontWeight: "700" },
  processingArea: { alignItems: "center", gap: 12, paddingVertical: 40 },
  processingTitle: { fontSize: 18, fontWeight: "700" },
  processingDesc: { fontSize: 14, textAlign: "center" },
  previewBanner: { flexDirection: "row", alignItems: "center", gap: 8, borderRadius: 12, borderWidth: 1, padding: 12, marginBottom: 16 },
  previewBannerText: { fontSize: 14, fontWeight: "600" },
  previewSection: { borderRadius: 12, borderWidth: 1, padding: 14, marginBottom: 12, gap: 8 },
  previewSectionLabel: { fontSize: 12, fontWeight: "700", textTransform: "uppercase", letterSpacing: 0.5 },
  previewSectionText: { fontSize: 15, lineHeight: 22 },
  keyPointRow: { flexDirection: "row", alignItems: "flex-start", gap: 8 },
  keyPointDot: { width: 7, height: 7, borderRadius: 4, marginTop: 7 },
  keyPointText: { flex: 1, fontSize: 14, lineHeight: 21 },
  transcriptText: { fontSize: 13, lineHeight: 19 },
  adFooter: { paddingTop: 4, paddingBottom: 24 },
});
