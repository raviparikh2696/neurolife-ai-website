import { useState, useMemo, useCallback, useRef } from "react";
import {
  Animated,
  FlatList,
  KeyboardAvoidingView,
  Modal,
  Platform,
  ScrollView,
  SectionList,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
  Alert,
  RefreshControl,
} from "react-native";
import * as Haptics from "expo-haptics";

import { ScreenContainer } from "@/components/screen-container";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { useColors } from "@/hooks/use-colors";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/hooks/use-auth";
import {
  GROCERY_CATEGORIES,
  CATEGORY_ORDER,
  POPULAR_ITEMS,
  detectGrocery,
  getSuggestions,
  type GroceryCategory,
  type GroceryEntry,
} from "@/lib/grocery-engine";
import { NativeAdCard } from "@/components/native-ad-card";

// Platform-specific ad unit IDs for Groceries screen
const GROCERIES_AD_UNIT_ID = Platform.select({
  android: 'ca-app-pub-1720679341163644/2251384772',
  ios: 'ca-app-pub-1720679341163644/2251384772',
  default: '',
});

// ─── Swipeable Row ───────────────────────────────────────────────────────────

function SwipeableRow({
  children,
  onDelete,
  colors,
}: {
  children: React.ReactNode;
  onDelete: () => void;
  colors: any;
}) {
  const pan = useRef(new Animated.Value(0)).current;
  const lastDx = useRef(0);

  const onTouchStart = useRef({ x: 0, y: 0, time: 0 });
  const isTracking = useRef(false);

  const handleTouchStart = (e: any) => {
    onTouchStart.current = {
      x: e.nativeEvent.pageX,
      y: e.nativeEvent.pageY,
      time: Date.now(),
    };
    isTracking.current = false;
  };

  const handleTouchMove = (e: any) => {
    const dx = e.nativeEvent.pageX - onTouchStart.current.x;
    const dy = e.nativeEvent.pageY - onTouchStart.current.y;

    if (!isTracking.current) {
      if (Math.abs(dx) > 10 && Math.abs(dx) > Math.abs(dy)) {
        isTracking.current = true;
      } else {
        return;
      }
    }

    if (dx < 0) {
      lastDx.current = dx;
      pan.setValue(Math.max(dx, -100));
    }
  };

  const handleTouchEnd = () => {
    if (!isTracking.current) return;
    if (lastDx.current < -60) {
      // Show delete zone
      Animated.spring(pan, {
        toValue: -80,
        useNativeDriver: false,
        friction: 8,
      }).start();
    } else {
      // Snap back
      Animated.spring(pan, {
        toValue: 0,
        useNativeDriver: false,
        friction: 8,
      }).start();
    }
    lastDx.current = 0;
  };

  const snapBack = () => {
    Animated.spring(pan, {
      toValue: 0,
      useNativeDriver: false,
      friction: 8,
    }).start();
  };

  return (
    <View style={{ overflow: "hidden" }}>
      {/* Delete background */}
      <View
        style={[
          styles.deleteBackground,
          { backgroundColor: colors.error },
        ]}
      >
        <TouchableOpacity
          style={styles.deleteAction}
          onPress={() => {
            snapBack();
            onDelete();
          }}
        >
          <IconSymbol name="trash" size={20} color="#fff" />
          <Text style={styles.deleteText}>Delete</Text>
        </TouchableOpacity>
      </View>

      {/* Content */}
      <Animated.View
        style={{ transform: [{ translateX: pan }] }}
        onTouchStart={handleTouchStart}
        onTouchMove={handleTouchMove}
        onTouchEnd={handleTouchEnd}
      >
        {children}
      </Animated.View>
    </View>
  );
}

// ─── Suggestion Row ──────────────────────────────────────────────────────────

function SuggestionRow({
  suggestions,
  onSelect,
  colors,
}: {
  suggestions: GroceryEntry[];
  onSelect: (entry: GroceryEntry) => void;
  colors: any;
}) {
  if (suggestions.length === 0) return null;
  return (
    <View style={[styles.suggestionsDropdown, { backgroundColor: colors.surface, borderColor: colors.border }]}>
      {suggestions.map((entry, idx) => (
        <TouchableOpacity
          key={`${entry.name}-${idx}`}
          style={[
            styles.suggestionItem,
            idx < suggestions.length - 1 && { borderBottomWidth: 0.5, borderBottomColor: colors.border },
          ]}
          onPress={() => onSelect(entry)}
        >
          <Text style={{ fontSize: 20 }}>{entry.emoji}</Text>
          <View style={{ flex: 1 }}>
            <Text style={[styles.suggestionName, { color: colors.foreground }]}>{entry.name}</Text>
            <Text style={[styles.suggestionCategory, { color: colors.muted }]}>
              {GROCERY_CATEGORIES[entry.category].icon} {GROCERY_CATEGORIES[entry.category].label}
            </Text>
          </View>
          <IconSymbol name="plus" size={18} color={colors.primary} />
        </TouchableOpacity>
      ))}
    </View>
  );
}

// ─── Grocery Item Row ────────────────────────────────────────────────────────

function GroceryRow({
  item,
  colors,
  onToggle,
  onDelete,
}: {
  item: any;
  colors: any;
  onToggle: () => void;
  onDelete: () => void;
}) {
  const match = detectGrocery(item.name);
  const emoji = match.emoji;
  const cat = GROCERY_CATEGORIES[(item.category as GroceryCategory)] ?? GROCERY_CATEGORIES.other;

  return (
    <SwipeableRow onDelete={onDelete} colors={colors}>
      <View style={[styles.itemRow, { backgroundColor: colors.surface, borderBottomColor: colors.border }]}>
        <TouchableOpacity
          onPress={onToggle}
          style={[
            styles.itemCheck,
            {
              borderColor: item.purchased ? colors.success : cat.color,
              backgroundColor: item.purchased ? colors.success : "transparent",
            },
          ]}
          hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}
        >
          {item.purchased && <IconSymbol name="checkmark" size={12} color="#fff" />}
        </TouchableOpacity>
        <Text style={{ fontSize: 22 }}>{emoji}</Text>
        <View style={{ flex: 1 }}>
          <Text
            style={[
              styles.itemName,
              {
                color: item.purchased ? colors.muted : colors.foreground,
                textDecorationLine: item.purchased ? "line-through" : "none",
              },
            ]}
          >
            {item.name}
          </Text>
          {item.quantity ? (
            <Text style={[styles.itemQty, { color: colors.muted }]}>{item.quantity}</Text>
          ) : null}
        </View>
      </View>
    </SwipeableRow>
  );
}

// ─── Recall Modal ────────────────────────────────────────────────────────────

function RecallModal({
  visible,
  onClose,
  colors,
}: {
  visible: boolean;
  onClose: () => void;
  colors: any;
}) {
  const { isAuthenticated } = useAuth();
  const { data: deletedItems = [], refetch: refetchDeleted } = trpc.groceries.listDeleted.useQuery(
    undefined,
    { enabled: isAuthenticated && visible, staleTime: 10000 }
  );
  const utils = trpc.useUtils();
  const restoreItem = trpc.groceries.restore.useMutation({
    onSuccess: () => {
      refetchDeleted();
      utils.groceries.list.invalidate();
      if (Platform.OS !== "web") Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    },
  });

  return (
    <Modal visible={visible} animationType="slide" transparent onRequestClose={onClose}>
      <View style={styles.modalOverlay}>
        <View style={[styles.modalSheet, { backgroundColor: colors.surface, maxHeight: "70%" }]}>
          <View style={styles.modalHeader}>
            <View>
              <Text style={[styles.modalTitle, { color: colors.foreground }]}>Recall Items</Text>
              <Text style={[styles.modalSubtitle, { color: colors.muted }]}>Restore recently removed items</Text>
            </View>
            <TouchableOpacity onPress={onClose}>
              <IconSymbol name="xmark.circle.fill" size={24} color={colors.muted} />
            </TouchableOpacity>
          </View>

          {deletedItems.length === 0 ? (
            <View style={{ alignItems: "center", padding: 32, gap: 8 }}>
              <Text style={{ fontSize: 40 }}>🗑️</Text>
              <Text style={[styles.emptyTitle, { color: colors.foreground }]}>No removed items</Text>
              <Text style={{ fontSize: 13, color: colors.muted, textAlign: "center" }}>
                Items you remove will appear here so you can bring them back.
              </Text>
            </View>
          ) : (
            <FlatList
              data={deletedItems}
              keyExtractor={(item) => String(item.id)}
              showsVerticalScrollIndicator={false}
              renderItem={({ item }) => {
                const match = detectGrocery(item.name);
                const deletedAgo = item.deletedAt
                  ? Math.round((Date.now() - new Date(item.deletedAt).getTime()) / 60000)
                  : null;
                return (
                  <View style={[styles.recallRow, { borderBottomColor: colors.border }]}>
                    <Text style={{ fontSize: 22 }}>{match.emoji}</Text>
                    <View style={{ flex: 1 }}>
                      <Text style={[styles.recallName, { color: colors.foreground }]}>{item.name}</Text>
                      <Text style={[styles.recallMeta, { color: colors.muted }]}>
                        {GROCERY_CATEGORIES[match.category]?.label ?? "Other"}
                        {item.quantity ? ` · ${item.quantity}` : ""}
                        {deletedAgo !== null
                          ? ` · ${deletedAgo < 60 ? `${deletedAgo}m` : `${Math.round(deletedAgo / 60)}h`} ago`
                          : ""}
                      </Text>
                    </View>
                    <TouchableOpacity
                      style={[styles.restoreBtn, { backgroundColor: colors.success + "20", borderColor: colors.success }]}
                      onPress={() => restoreItem.mutate({ id: item.id })}
                      disabled={restoreItem.isPending}
                    >
                      <IconSymbol name="arrow.uturn.backward" size={14} color={colors.success} />
                      <Text style={[styles.restoreBtnText, { color: colors.success }]}>Restore</Text>
                    </TouchableOpacity>
                  </View>
                );
              }}
              contentContainerStyle={{ paddingBottom: 20 }}
            />
          )}
        </View>
      </View>
    </Modal>
  );
}

// ─── Main Screen ─────────────────────────────────────────────────────────────

export default function GroceriesScreen() {
  const colors = useColors();
  const { isAuthenticated } = useAuth();
  const [showRecall, setShowRecall] = useState(false);
  const [showPurchased, setShowPurchased] = useState(false);
  const [inputText, setInputText] = useState("");
  const [refreshing, setRefreshing] = useState(false);
  const inputRef = useRef<TextInput>(null);

  // ── Data Queries ──
  const utils = trpc.useUtils();
  const { data: items = [], refetch } = trpc.groceries.list.useQuery(undefined, {
    enabled: isAuthenticated,
    staleTime: 0,
    gcTime: 5 * 60 * 1000,
  });

  const createItem = trpc.groceries.create.useMutation({
    onMutate: async (newItem) => {
      await utils.groceries.list.cancel();
      const prev = utils.groceries.list.getData();
      const match = detectGrocery(newItem.name);
      utils.groceries.list.setData(undefined, (old: any) => [
        ...(old ?? []),
        { id: Date.now(), name: newItem.name, category: newItem.category ?? match.category, quantity: null, purchased: false, deletedAt: null, userId: "", createdAt: new Date().toISOString() },
      ]);
      return { prev };
    },
    onError: (_err, _vars, ctx: any) => { if (ctx?.prev) utils.groceries.list.setData(undefined, ctx.prev); },
    onSettled: () => utils.groceries.list.invalidate(),
  });
  const updateItem = trpc.groceries.update.useMutation({
    onMutate: async (updated) => {
      await utils.groceries.list.cancel();
      const prev = utils.groceries.list.getData();
      utils.groceries.list.setData(undefined, (old: any) =>
        (old ?? []).map((i: any) => i.id === updated.id ? { ...i, ...updated } : i)
      );
      return { prev };
    },
    onError: (_err, _vars, ctx: any) => { if (ctx?.prev) utils.groceries.list.setData(undefined, ctx.prev); },
    onSettled: () => utils.groceries.list.invalidate(),
  });
  const deleteItem = trpc.groceries.delete.useMutation({
    onMutate: async ({ id }) => {
      await utils.groceries.list.cancel();
      const prev = utils.groceries.list.getData();
      utils.groceries.list.setData(undefined, (old: any) =>
        (old ?? []).filter((i: any) => i.id !== id)
      );
      return { prev };
    },
    onError: (_err, _vars, ctx: any) => { if (ctx?.prev) utils.groceries.list.setData(undefined, ctx.prev); },
    onSettled: () => utils.groceries.list.invalidate(),
  });
  const clearPurchased = trpc.groceries.clearPurchased.useMutation({
    onMutate: async () => {
      await utils.groceries.list.cancel();
      const prev = utils.groceries.list.getData();
      utils.groceries.list.setData(undefined, (old: any) =>
        (old ?? []).filter((i: any) => !i.purchased)
      );
      return { prev };
    },
    onError: (_err, _vars, ctx: any) => { if (ctx?.prev) utils.groceries.list.setData(undefined, ctx.prev); },
    onSettled: () => utils.groceries.list.invalidate(),
  });

  // ── Handlers ──
  const handleAddItem = useCallback(
    (name: string, category?: GroceryCategory) => {
      const match = detectGrocery(name);
      createItem.mutate({
        name: name.trim(),
        category: category ?? match.category,
      });
      setInputText("");
      if (Platform.OS !== "web") Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    },
    [createItem]
  );

  const handleAddFromSuggestion = useCallback(
    (entry: GroceryEntry) => {
      createItem.mutate({ name: entry.name, category: entry.category });
      setInputText("");
      inputRef.current?.blur();
      if (Platform.OS !== "web") Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    },
    [createItem]
  );

  const handleAddFromInput = useCallback(() => {
    if (!inputText.trim()) return;
    handleAddItem(inputText.trim());
  }, [inputText, handleAddItem]);

  const handleToggle = useCallback(
    (item: any) => {
      updateItem.mutate({ id: item.id, purchased: !item.purchased });
      if (Platform.OS !== "web") Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    },
    [updateItem]
  );

  const handleDelete = useCallback(
    (id: number) => {
      deleteItem.mutate({ id });
      if (Platform.OS !== "web") Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    },
    [deleteItem]
  );

  const handleClearPurchased = () => {
    Alert.alert("Clear Purchased", "Remove all checked items?", [
      { text: "Cancel", style: "cancel" },
      { text: "Clear", style: "destructive", onPress: () => clearPurchased.mutate() },
    ]);
  };

  const handleRefresh = useCallback(async () => {
    setRefreshing(true);
    await refetch();
    setRefreshing(false);
  }, [refetch]);

  // ── Suggestions ──
  const existingNames = useMemo(() => items.map((i) => i.name), [items]);
  const suggestions = useMemo(
    () => getSuggestions(inputText, existingNames, 5),
    [inputText, existingNames]
  );

  // ── Quick Add (popular items not already in list) ──
  const quickAdds = useMemo(
    () =>
      POPULAR_ITEMS.filter(
        (p) => !items.some((i) => i.name.toLowerCase() === p.name.toLowerCase())
      ).slice(0, 8),
    [items]
  );

  // ── Filter and Group ──
  const filtered = useMemo(() => {
    return items.filter((item) => {
      if (!showPurchased && item.purchased) return false;
      if (inputText && !suggestions.length) {
        // If user is typing but no suggestions, also filter the list
        return item.name.toLowerCase().includes(inputText.toLowerCase());
      }
      return true;
    });
  }, [items, showPurchased, inputText, suggestions.length]);

  const sections = useMemo(() => {
    const grouped: Record<string, any[]> = {};
    for (const item of filtered) {
      // Re-detect category using the engine for correct grouping
      const match = detectGrocery(item.name);
      const cat = item.category || match.category;
      if (!grouped[cat]) grouped[cat] = [];
      grouped[cat].push(item);
    }
    // Sort by CATEGORY_ORDER
    return CATEGORY_ORDER.filter((cat) => grouped[cat]?.length)
      .map((cat) => ({
        title: cat,
        data: grouped[cat],
      }));
  }, [filtered]);

  const pendingCount = items.filter((i) => !i.purchased).length;
  const purchasedCount = items.filter((i) => i.purchased).length;
  const totalCount = items.length;

  return (
    <ScreenContainer containerClassName="bg-background">
      {/* Header */}
      <View style={[styles.header, { borderBottomColor: colors.border }]}>
        <View>
          <Text style={[styles.screenTitle, { color: colors.foreground }]}>Groceries</Text>
          <Text style={[styles.screenSubtitle, { color: colors.muted }]}>
            {pendingCount} to buy · {purchasedCount} done
          </Text>
        </View>
        <View style={{ flexDirection: "row", gap: 8 }}>
          <TouchableOpacity
            style={[styles.headerBtn, { backgroundColor: colors.warning + "18", borderColor: colors.warning + "44" }]}
            onPress={() => setShowRecall(true)}
          >
            <IconSymbol name="arrow.uturn.backward" size={16} color={colors.warning} />
          </TouchableOpacity>
          {purchasedCount > 0 && (
            <TouchableOpacity
              style={[styles.headerBtn, { backgroundColor: colors.error + "18", borderColor: colors.error + "44" }]}
              onPress={handleClearPurchased}
            >
              <IconSymbol name="trash" size={16} color={colors.error} />
            </TouchableOpacity>
          )}
        </View>
      </View>

      {/* Add Item Input + Suggestions */}
      <View style={{ zIndex: 10 }}>
        <View style={[styles.addBar, { backgroundColor: colors.surface, borderBottomColor: colors.border }]}>
          <View style={[styles.addInputContainer, { backgroundColor: colors.background, borderColor: colors.border }]}>
            <IconSymbol name="magnifyingglass" size={18} color={colors.muted} />
            <TextInput
              ref={inputRef}
              style={[styles.addInput, { color: colors.foreground }]}
              placeholder="Add grocery item..."
              placeholderTextColor={colors.muted}
              value={inputText}
              onChangeText={setInputText}
              returnKeyType="done"
              onSubmitEditing={handleAddFromInput}
              autoCorrect={false}
            />
            {inputText ? (
              <TouchableOpacity onPress={() => setInputText("")} hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}>
                <IconSymbol name="xmark.circle.fill" size={18} color={colors.muted} />
              </TouchableOpacity>
            ) : null}
          </View>
          <TouchableOpacity
            style={[styles.addButton, { backgroundColor: colors.primary, opacity: inputText.trim() ? 1 : 0.4 }]}
            onPress={handleAddFromInput}
            disabled={!inputText.trim()}
          >
            <IconSymbol name="plus" size={22} color="#fff" />
          </TouchableOpacity>
        </View>

        {/* Smart Suggestions Dropdown */}
        {inputText.length > 0 && suggestions.length > 0 && (
          <SuggestionRow suggestions={suggestions} onSelect={handleAddFromSuggestion} colors={colors} />
        )}
      </View>

      {/* Quick Add Chips */}
      {!inputText && quickAdds.length > 0 && (
        <View style={[styles.quickAddContainer, { borderBottomColor: colors.border }]}>
          <Text style={[styles.quickAddLabel, { color: colors.muted }]}>Quick add</Text>
          <ScrollView horizontal showsHorizontalScrollIndicator={false}>
            <View style={{ flexDirection: "row", gap: 6, paddingRight: 16 }}>
              {quickAdds.map((entry) => (
                <TouchableOpacity
                  key={entry.name}
                  style={[styles.quickChip, { backgroundColor: colors.background, borderColor: colors.border }]}
                  onPress={() => handleAddFromSuggestion(entry)}
                >
                  <Text style={{ fontSize: 16 }}>{entry.emoji}</Text>
                  <Text style={[styles.quickChipText, { color: colors.foreground }]}>{entry.name}</Text>
                </TouchableOpacity>
              ))}
            </View>
          </ScrollView>
        </View>
      )}

      {/* Toggle Purchased */}
      {totalCount > 0 && (
        <TouchableOpacity
          style={[styles.toggleRow, { borderBottomColor: colors.border }]}
          onPress={() => setShowPurchased(!showPurchased)}
        >
          <View
            style={[
              styles.miniCheck,
              {
                borderColor: showPurchased ? colors.primary : colors.muted,
                backgroundColor: showPurchased ? colors.primary : "transparent",
              },
            ]}
          >
            {showPurchased && <IconSymbol name="checkmark" size={10} color="#fff" />}
          </View>
          <Text style={[styles.toggleText, { color: colors.muted }]}>
            {showPurchased ? "Hide" : "Show"} purchased ({purchasedCount})
          </Text>
        </TouchableOpacity>
      )}

      {/* Grocery List */}
      {!isAuthenticated ? (
        <View style={styles.emptyCenter}>
          <Text style={[styles.emptyTitle, { color: colors.foreground }]}>Sign in to manage groceries</Text>
        </View>
      ) : totalCount === 0 ? (
        <View style={styles.emptyCenter}>
          <Text style={{ fontSize: 56 }}>🛒</Text>
          <Text style={[styles.emptyTitle, { color: colors.foreground }]}>Your list is empty</Text>
          <Text style={[styles.emptySubtitle, { color: colors.muted }]}>
            Type an item above or tap a quick add chip
          </Text>
        </View>
      ) : (
        <SectionList
          sections={sections}
          keyExtractor={(item) => String(item.id)}
          stickySectionHeadersEnabled
          showsVerticalScrollIndicator={false}
          refreshControl={
            <RefreshControl refreshing={refreshing} onRefresh={handleRefresh} tintColor={colors.primary} />
          }
          renderSectionHeader={({ section }) => {
            const cat = GROCERY_CATEGORIES[section.title as GroceryCategory] ?? GROCERY_CATEGORIES.other;
            return (
              <View style={[styles.sectionHeader, { backgroundColor: colors.background }]}>
                <View style={[styles.sectionBadge, { backgroundColor: cat.color + "18" }]}>
                  <Text style={{ fontSize: 16 }}>{cat.icon}</Text>
                  <Text style={[styles.sectionLabel, { color: cat.color }]}>{cat.label}</Text>
                </View>
                <View style={[styles.sectionCountBadge, { backgroundColor: cat.color + "22" }]}>
                  <Text style={[styles.sectionCountText, { color: cat.color }]}>{section.data.length}</Text>
                </View>
              </View>
            );
          }}
          renderItem={({ item }) => (
            <GroceryRow
              item={item}
              colors={colors}
              onToggle={() => handleToggle(item)}
              onDelete={() => handleDelete(item.id)}
            />
          )}
          ListFooterComponent={<View style={styles.adFooter}><NativeAdCard adUnitId={GROCERIES_AD_UNIT_ID} /></View>}
          contentContainerStyle={styles.listContent}
        />
      )}

      <RecallModal visible={showRecall} onClose={() => setShowRecall(false)} colors={colors} />
    </ScreenContainer>
  );
}

// ─── Styles ──────────────────────────────────────────────────────────────────

const styles = StyleSheet.create({
  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderBottomWidth: 0.5,
  },
  screenTitle: { fontSize: 28, fontWeight: "700" },
  screenSubtitle: { fontSize: 13, marginTop: 2 },
  headerBtn: {
    width: 36,
    height: 36,
    borderRadius: 18,
    alignItems: "center",
    justifyContent: "center",
    borderWidth: 1,
  },

  // Add bar
  addBar: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 12,
    paddingVertical: 10,
    gap: 8,
    borderBottomWidth: 0.5,
  },
  addInputContainer: {
    flex: 1,
    flexDirection: "row",
    alignItems: "center",
    borderRadius: 12,
    borderWidth: 1,
    paddingHorizontal: 12,
    height: 44,
    gap: 8,
  },
  addInput: { flex: 1, fontSize: 15 },
  addButton: {
    width: 44,
    height: 44,
    borderRadius: 12,
    alignItems: "center",
    justifyContent: "center",
  },

  // Suggestions dropdown
  suggestionsDropdown: {
    position: "absolute",
    top: 64,
    left: 12,
    right: 64,
    borderRadius: 12,
    borderWidth: 1,
    overflow: "hidden",
    elevation: 8,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.15,
    shadowRadius: 12,
  },
  suggestionItem: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 14,
    paddingVertical: 12,
    gap: 12,
  },
  suggestionName: { fontSize: 15, fontWeight: "500" },
  suggestionCategory: { fontSize: 12, marginTop: 1 },

  // Quick add
  quickAddContainer: {
    paddingHorizontal: 16,
    paddingVertical: 10,
    borderBottomWidth: 0.5,
  },
  quickAddLabel: { fontSize: 12, fontWeight: "600", marginBottom: 8 },
  quickChip: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 10,
    paddingVertical: 7,
    borderRadius: 20,
    borderWidth: 1,
    gap: 5,
  },
  quickChipText: { fontSize: 13, fontWeight: "500" },

  // Toggle
  toggleRow: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 16,
    paddingVertical: 10,
    gap: 8,
    borderBottomWidth: 0.5,
  },
  toggleText: { fontSize: 13 },
  miniCheck: {
    width: 18,
    height: 18,
    borderRadius: 4,
    borderWidth: 1.5,
    alignItems: "center",
    justifyContent: "center",
  },

  // Section header
  sectionHeader: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 16,
    paddingVertical: 10,
  },
  sectionBadge: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 8,
    gap: 6,
  },
  sectionLabel: { fontSize: 14, fontWeight: "700" },
  sectionCountBadge: {
    paddingHorizontal: 8,
    paddingVertical: 2,
    borderRadius: 10,
  },
  sectionCountText: { fontSize: 12, fontWeight: "700" },

  // Item row
  itemRow: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 16,
    paddingVertical: 14,
    borderBottomWidth: 0.5,
    gap: 12,
  },
  itemCheck: {
    width: 24,
    height: 24,
    borderRadius: 12,
    borderWidth: 2,
    alignItems: "center",
    justifyContent: "center",
  },
  itemName: { fontSize: 16, fontWeight: "500" },
  itemQty: { fontSize: 12, marginTop: 2 },

  // Swipe delete
  deleteBackground: {
    position: "absolute",
    right: 0,
    top: 0,
    bottom: 0,
    width: 100,
    justifyContent: "center",
    alignItems: "center",
  },
  deleteAction: {
    alignItems: "center",
    justifyContent: "center",
    gap: 2,
  },
  deleteText: { color: "#fff", fontSize: 11, fontWeight: "600" },

  // List
  listContent: { paddingBottom: 100 },
  adFooter: { paddingHorizontal: 16, paddingVertical: 12, borderTopWidth: 0.5 },

  // Empty
  emptyCenter: { flex: 1, alignItems: "center", justifyContent: "center", padding: 40, gap: 8 },
  emptyTitle: { fontSize: 18, fontWeight: "600" },
  emptySubtitle: { fontSize: 14, textAlign: "center" },

  // Recall modal
  recallRow: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderBottomWidth: 0.5,
    gap: 10,
  },
  recallName: { fontSize: 15, fontWeight: "500" },
  recallMeta: { fontSize: 12, marginTop: 2 },
  restoreBtn: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 10,
    borderWidth: 1,
    gap: 4,
  },
  restoreBtnText: { fontSize: 13, fontWeight: "600" },

  // Modal
  modalOverlay: { flex: 1, backgroundColor: "rgba(0,0,0,0.5)", justifyContent: "flex-end" },
  modalSheet: { borderTopLeftRadius: 24, borderTopRightRadius: 24, padding: 24, paddingBottom: 40 },
  modalHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 16,
  },
  modalTitle: { fontSize: 20, fontWeight: "700" },
  modalSubtitle: { fontSize: 13, marginTop: 2 },
});
