import {
  ActivityIndicator,
  FlatList,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
  Animated,
  Alert,
} from "react-native";
import { useState, useRef, useCallback, useEffect } from "react";
import * as Haptics from "expo-haptics";
import {
  useAudioRecorder,
  useAudioRecorderState,
  requestRecordingPermissionsAsync,
  setAudioModeAsync,
  RecordingPresets,
} from "expo-audio";
import * as FileSystem from "expo-file-system/legacy";
import { ScreenContainer } from "@/components/screen-container";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { useColors } from "@/hooks/use-colors";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/hooks/use-auth";
import { router } from "expo-router";

// ─── Types ────────────────────────────────────────────────────────────────────
type ActionType = "task" | "event" | "grocery" | "note" | "meeting" | "general" | "query";

interface Message {
  id: string;
  role: "user" | "assistant" | "system";
  content: string;
  timestamp: Date;
  isLoading?: boolean;
  isStreaming?: boolean;
  actionType?: ActionType;
  actionTitle?: string;
  actionItems?: string[];
}

// ─── Quick Prompt Chips (always visible above input bar) ──────────────────────
const QUICK_PROMPTS = [
  { text: "What's on my schedule today?", icon: "📅" },
  { text: "Add milk, eggs, bread to groceries", icon: "🛒" },
  { text: "Remind me to call mom tomorrow at 3pm", icon: "⏰" },
  { text: "Create a task: finish the report by Friday", icon: "✅" },
  { text: "Schedule a team meeting for Monday at 10am", icon: "👥" },
  { text: "What tasks are overdue?", icon: "🔴" },
  { text: "Add a note about my project ideas", icon: "📝" },
  { text: "Summarize my week", icon: "📊" },
  { text: "What groceries do I need?", icon: "🥦" },
  { text: "Show me my pending tasks", icon: "📋" },
];

// ─── Action Confirmation Card ─────────────────────────────────────────────────
const ACTION_CONFIG: Record<ActionType, { icon: string; label: string; color: string }> = {
  task:    { icon: "✅", label: "Task created",       color: "#22C55E" },
  event:   { icon: "📅", label: "Event scheduled",    color: "#3B82F6" },
  grocery: { icon: "🛒", label: "Added to groceries", color: "#4ECDC4" },
  note:    { icon: "📝", label: "Note saved",         color: "#FBBF24" },
  meeting: { icon: "👥", label: "Meeting saved",      color: "#A78BFA" },
  general: { icon: "✨", label: "Done",               color: "#6B7280" },
  query:   { icon: "💬", label: "Answer",             color: "#6B7280" },
};

function ActionCard({
  actionType,
  title,
  items,
  colors,
}: {
  actionType: ActionType;
  title: string;
  items?: string[];
  colors: any;
}) {
  const cfg = ACTION_CONFIG[actionType] ?? ACTION_CONFIG.general;
  return (
    <View
      style={[
        styles.actionCard,
        { backgroundColor: cfg.color + "18", borderColor: cfg.color + "44" },
      ]}
    >
      <Text style={{ fontSize: 18 }}>{cfg.icon}</Text>
      <View style={{ flex: 1, gap: 2 }}>
        <Text style={[styles.actionCardLabel, { color: cfg.color }]}>{cfg.label}</Text>
        <Text style={[styles.actionCardTitle, { color: colors.foreground }]} numberOfLines={2}>
          {title}
        </Text>
        {items && items.length > 0 && (
          <Text style={[styles.actionCardItems, { color: colors.muted }]}>
            {items.slice(0, 3).join(" · ")}
            {items.length > 3 ? ` +${items.length - 3} more` : ""}
          </Text>
        )}
      </View>
    </View>
  );
}

// ─── Typing Dots ──────────────────────────────────────────────────────────────
function TypingDots({ colors }: { colors: any }) {
  const dot1 = useRef(new Animated.Value(0)).current;
  const dot2 = useRef(new Animated.Value(0)).current;
  const dot3 = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    const anim = (dot: Animated.Value, delay: number) =>
      Animated.loop(
        Animated.sequence([
          Animated.delay(delay),
          Animated.timing(dot, { toValue: 1, duration: 300, useNativeDriver: true }),
          Animated.timing(dot, { toValue: 0, duration: 300, useNativeDriver: true }),
          Animated.delay(600),
        ])
      );
    const a1 = anim(dot1, 0);
    const a2 = anim(dot2, 200);
    const a3 = anim(dot3, 400);
    a1.start(); a2.start(); a3.start();
    return () => { a1.stop(); a2.stop(); a3.stop(); };
  }, [dot1, dot2, dot3]);

  const dotStyle = (dot: Animated.Value) => ({
    width: 7,
    height: 7,
    borderRadius: 3.5,
    backgroundColor: colors.primary,
    opacity: dot,
    transform: [{ translateY: dot.interpolate({ inputRange: [0, 1], outputRange: [0, -4] }) }],
  });

  return (
    <View style={{ flexDirection: "row", gap: 4, alignItems: "center", paddingVertical: 4 }}>
      <Animated.View style={dotStyle(dot1)} />
      <Animated.View style={dotStyle(dot2)} />
      <Animated.View style={dotStyle(dot3)} />
    </View>
  );
}

// ─── Message Bubble ───────────────────────────────────────────────────────────
function MessageBubble({ message, colors }: { message: Message; colors: any }) {
  const isUser = message.role === "user";
  const isSystem = message.role === "system";

  if (isSystem) {
    return (
      <View style={styles.systemMsg}>
        <Text style={[styles.systemMsgText, { color: colors.muted }]}>{message.content}</Text>
      </View>
    );
  }

  return (
    <View style={[styles.bubbleRow, isUser && styles.bubbleRowUser]}>
      {!isUser && (
        <View style={[styles.avatar, { backgroundColor: colors.primary + "22" }]}>
          <Text style={{ fontSize: 15 }}>✨</Text>
        </View>
      )}
      <View style={{ maxWidth: "80%", gap: 4 }}>
        {message.isLoading ? (
          <View
            style={[
              styles.bubble,
              { backgroundColor: colors.surface, borderColor: colors.border, borderWidth: 1 },
            ]}
          >
            <TypingDots colors={colors} />
          </View>
        ) : message.actionType && !["general", "query"].includes(message.actionType) ? (
          <>
            <ActionCard
              actionType={message.actionType}
              title={message.actionTitle ?? message.content}
              items={message.actionItems}
              colors={colors}
            />
            {message.content ? (
              <View
                style={[
                  styles.bubble,
                  { backgroundColor: colors.surface, borderColor: colors.border, borderWidth: 1 },
                ]}
              >
                <Text style={[styles.bubbleText, { color: colors.foreground }]}>
                  {message.content}
                </Text>
              </View>
            ) : null}
          </>
        ) : (
          <View
            style={[
              styles.bubble,
              isUser
                ? { backgroundColor: colors.primary }
                : { backgroundColor: colors.surface, borderColor: colors.border, borderWidth: 1 },
            ]}
          >
            <Text style={[styles.bubbleText, { color: isUser ? "#fff" : colors.foreground }]}>
              {message.content}{message.isStreaming ? "▌" : ""}
            </Text>
          </View>
        )}
        <Text
          style={[
            styles.timestamp,
            { color: colors.muted, alignSelf: isUser ? "flex-end" : "flex-start" },
          ]}
        >
          {message.timestamp.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
        </Text>
      </View>
    </View>
  );
}

// ─── Main Screen ──────────────────────────────────────────────────────────────
export default function AssistantScreen() {
  const colors = useColors();
  const { isAuthenticated } = useAuth();
  const utils = trpc.useUtils();

  const [messages, setMessages] = useState<Message[]>([
    {
      id: "welcome",
      role: "assistant",
      content:
        "Hi! I'm your NeuroLife AI assistant. I can create tasks, schedule events, add groceries, save notes, and answer questions about your data. What would you like to do?",
      timestamp: new Date(),
    },
  ]);
  const [inputText, setInputText] = useState("");
  const flatListRef = useRef<FlatList>(null);

  // ─── Audio recorder setup ─────────────────────────────────────────────────
  const audioRecorder = useAudioRecorder(RecordingPresets.HIGH_QUALITY);
  const recorderState = useAudioRecorderState(audioRecorder);
  const isRecording = recorderState.isRecording;

  // Set audio mode once on mount (native only)
  useEffect(() => {
    if (Platform.OS === "web") return;
    setAudioModeAsync({
      playsInSilentMode: true,
      allowsRecording: true,
    });
  }, []);

  // ─── tRPC mutations ───────────────────────────────────────────────────────
  const classifyMutation = trpc.ai.classify.useMutation();
  // Streaming state
  const [isStreamingResponse, setIsStreamingResponse] = useState(false);
  const createTaskMutation = trpc.tasks.create.useMutation();
  const createEventMutation = trpc.events.create.useMutation();
  const createGroceryMutation = trpc.groceries.createMany.useMutation();
  const createNoteMutation = trpc.notes.create.useMutation();
  const uploadMutation = trpc.voice.upload.useMutation();
  const transcribeMutation = trpc.voice.transcribe.useMutation();

  // ─── Helpers ─────────────────────────────────────────────────────────────
  const updateLoadingMessage = useCallback(
    (update: Partial<Message>) => {
      setMessages((prev) =>
        prev.map((m) => (m.isLoading ? { ...m, ...update, isLoading: false } : m))
      );
    },
    []
  );

  // ─── Send message with intent classification ──────────────────────────────
  const sendMessage = useCallback(
    async (text: string) => {
      const trimmed = text.trim();
      if (!trimmed) return;

      if (Platform.OS !== "web") {
        Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
      }

      const userMsg: Message = {
        id: Date.now().toString(),
        role: "user",
        content: trimmed,
        timestamp: new Date(),
      };
      const loadingMsg: Message = {
        id: "loading-" + Date.now(),
        role: "assistant",
        content: "",
        timestamp: new Date(),
        isLoading: true,
      };

      setMessages((prev) => [...prev, userMsg, loadingMsg]);
      setInputText("");
      setTimeout(() => flatListRef.current?.scrollToEnd({ animated: true }), 80);

      try {
        // Step 1: Classify intent — pass user's timezone offset so AI uses correct local date
        const tzOffset = new Date().getTimezoneOffset(); // minutes behind UTC (positive = behind)
        const classified = await classifyMutation.mutateAsync({ text: trimmed, tzOffset });
        const intent: ActionType = classified.intent ?? "general";
        // Helper: build ISO string with timezone offset from YYYY-MM-DD + HH:MM
        const buildISOWithTz = (dateStr: string | null | undefined, timeStr: string | null | undefined): string => {
          const date = dateStr ?? new Date().toISOString().split("T")[0];
          const time = timeStr ?? "09:00";
          // Build offset string e.g. "+05:30" or "-08:00"
          const sign = tzOffset <= 0 ? "+" : "-";
          const absMin = Math.abs(tzOffset);
          const h = String(Math.floor(absMin / 60)).padStart(2, "0");
          const m = String(absMin % 60).padStart(2, "0");
          return `${date}T${time}:00${sign}${h}:${m}`;
        };
        // Step 2: Act on intent
        if (intent === "task") {
          const taskTitle = classified.title ?? trimmed;
          // For tasks, dueDate is YYYY-MM-DD — convert to ISO with timezone
          const dueDate = classified.dueDate
            ? buildISOWithTz(classified.dueDate, classified.time ?? "09:00")
            : undefined;
          await createTaskMutation.mutateAsync({
            title: taskTitle,
            priority: classified.priority ?? "medium",
            dueDate,
          });
          utils.tasks.list.invalidate();
          updateLoadingMessage({
            id: Date.now().toString(),
            actionType: "task",
            actionTitle: taskTitle,
            content: classified.response ?? `Task "${taskTitle}" has been created!`,
          });
        } else if (intent === "event") {
          // Build startTime as ISO with correct timezone offset
          const startTime = classified.dueDate
            ? buildISOWithTz(classified.dueDate, classified.time)
            : buildISOWithTz(null, classified.time);;
          const eventTitle = classified.title ?? trimmed;
          await createEventMutation.mutateAsync({
            title: eventTitle,
            startTime,
            people: classified.people ?? [],
          });
          utils.events.list.invalidate();
          updateLoadingMessage({
            id: Date.now().toString(),
            actionType: "event",
            actionTitle: eventTitle,
            content: classified.response ?? `Event "${eventTitle}" has been scheduled!`,
          });
        } else if (intent === "grocery") {
          const items: string[] = classified.items?.length
            ? classified.items
            : [classified.title ?? trimmed];
          await createGroceryMutation.mutateAsync(
            items.map((name: string) => ({ name, category: "other" as const }))
          );
          utils.groceries.list.invalidate();
          updateLoadingMessage({
            id: Date.now().toString(),
            actionType: "grocery",
            actionTitle: items.length === 1 ? items[0] : `${items.length} items`,
            actionItems: items,
            content: classified.response ?? `Added ${items.length} item(s) to your grocery list!`,
          });
        } else if (intent === "note" || intent === "meeting") {
          const noteTitle = classified.title ?? trimmed;
          await createNoteMutation.mutateAsync({
            title: noteTitle,
            content: classified.response,
            category: intent === "meeting" ? "meeting" : "note",
          });
          utils.notes.list.invalidate();
          updateLoadingMessage({
            id: Date.now().toString(),
            actionType: intent,
            actionTitle: noteTitle,
            content: classified.response ?? `Note "${noteTitle}" has been saved!`,
          });
        } else {
          // query / general — streaming SSE for word-by-word response
          const { getApiBaseUrl } = await import("@/constants/oauth");
          const { getSessionToken } = await import("@/lib/_core/auth");
          const apiBase = getApiBaseUrl();
          const token = await getSessionToken();
          const tzOff = new Date().getTimezoneOffset();
          const historySlice = messages
            .filter((m) => !m.isLoading && !m.isStreaming && m.role !== "system")
            .slice(-10)
            .map((m) => ({ role: m.role as "user" | "assistant", content: m.content }));

          // Replace loading bubble with empty streaming bubble
          const streamId = Date.now().toString();
          setIsStreamingResponse(true);
          setMessages((prev) =>
            prev.map((m) =>
              m.isLoading
                ? { ...m, id: streamId, isLoading: false, isStreaming: true, content: "", actionType: "query" as ActionType }
                : m
            )
          );

          const hdrs: Record<string, string> = { "Content-Type": "application/json" };
          if (token) hdrs["Authorization"] = `Bearer ${token}`;

          try {
            const resp = await fetch(`${apiBase}/api/ai/stream-chat`, {
              method: "POST",
              headers: hdrs,
              credentials: "include",
              body: JSON.stringify({ message: trimmed, history: historySlice, tzOffset: tzOff }),
            });

            if (!resp.ok || !resp.body) {
              const errText = await resp.text().catch(() => "Stream failed");
              setMessages((prev) =>
                prev.map((m) => m.id === streamId ? { ...m, isStreaming: false, content: errText } : m)
              );
            } else {
              const reader = resp.body.getReader();
              const decoder = new TextDecoder();
              let accumulated = "";
              try {
                outer: while (true) {
                  const { done, value } = await reader.read();
                  if (done) break;
                  const chunk = decoder.decode(value, { stream: true });
                  for (const line of chunk.split("\n")) {
                    if (!line.startsWith("data: ")) continue;
                    const data = line.slice(6).trim();
                    try {
                      const parsed = JSON.parse(data);
                      if (parsed.delta) {
                        accumulated += parsed.delta;
                        setMessages((prev) =>
                          prev.map((m) => m.id === streamId ? { ...m, content: accumulated } : m)
                        );
                      }
                      if (parsed.done) break outer;
                    } catch { /* skip malformed */ }
                  }
                }
              } finally {
                reader.releaseLock();
              }
            }
          } finally {
            setMessages((prev) =>
              prev.map((m) => m.id === streamId ? { ...m, isStreaming: false } : m)
            );
            setIsStreamingResponse(false);
          }
        }
      } catch (err: any) {
        updateLoadingMessage({
          id: Date.now().toString(),
          content: err?.message ?? "Sorry, something went wrong. Please try again.",
        });
      }
    },
    [
      classifyMutation,
      createTaskMutation,
      createEventMutation,
      createGroceryMutation,
      createNoteMutation,
      messages,
      utils,
      updateLoadingMessage,
    ]
  );

  // ─── Voice recording (fixed: prepareToRecordAsync before record) ──────────
  const startRecording = async () => {
    if (Platform.OS === "web") return;
    const { granted } = await requestRecordingPermissionsAsync();
    if (!granted) {
      Alert.alert("Microphone Permission", "Please allow microphone access to use voice input.");
      return;
    }
    try {
      await audioRecorder.prepareToRecordAsync();
      audioRecorder.record();
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    } catch (e) {
      console.warn("[Voice] Failed to start recording:", e);
      Alert.alert("Recording Error", "Could not start recording. Please try again.");
    }
  };

  const stopRecording = async () => {
    if (!isRecording) return;
    try {
      await audioRecorder.stop();
      const uri = audioRecorder.uri;
      if (!uri) {
        console.warn("[Voice] No URI after stop");
        return;
      }
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);

      // Show transcribing indicator in input
      setInputText("Transcribing…");

      const base64 = await FileSystem.readAsStringAsync(uri, {
        encoding: FileSystem.EncodingType.Base64,
      });
      const uploadResult = await uploadMutation.mutateAsync({ base64, mimeType: "audio/m4a" });
      const result = await transcribeMutation.mutateAsync({ audioUrl: uploadResult.url });
      if (result.text) {
        setInputText(result.text);
        Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      } else {
        setInputText("");
        Alert.alert("Transcription", "Could not transcribe audio. Please try typing instead.");
      }
    } catch (e) {
      console.warn("[Voice] Recording/transcription failed:", e);
      setInputText("");
      Alert.alert("Voice Error", "Could not process voice input. Please try again.");
    }
  };

  const clearHistory = () => {
    if (Platform.OS !== "web") Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    setMessages([
      {
        id: "welcome-" + Date.now(),
        role: "assistant",
        content: "Chat cleared! How can I help you?",
        timestamp: new Date(),
      },
    ]);
  };

  // ─── Not authenticated ────────────────────────────────────────────────────
  if (!isAuthenticated) {
    return (
      <ScreenContainer>
        <View style={[styles.emptyState, { backgroundColor: colors.background }]}>
          <Text style={{ fontSize: 48 }}>🔒</Text>
          <Text style={[styles.emptyTitle, { color: colors.foreground }]}>Sign in required</Text>
          <Text style={[styles.emptySubtitle, { color: colors.muted }]}>
            Please sign in to use the AI assistant.
          </Text>
          <TouchableOpacity
            onPress={() => router.push("/sign-in" as any)}
            style={[styles.signInBtn, { backgroundColor: colors.primary }]}
          >
            <Text style={{ color: "#fff", fontWeight: "700", fontSize: 16 }}>Sign In</Text>
          </TouchableOpacity>
        </View>
      </ScreenContainer>
    );
  }

  const isBusy = uploadMutation.isPending || transcribeMutation.isPending;
  const isSending = classifyMutation.isPending || isStreamingResponse;

  return (
    <ScreenContainer containerClassName="bg-background">
      {/* Header */}
      <View style={[styles.header, { borderBottomColor: colors.border }]}>
        <View style={styles.headerLeft}>
          <View style={[styles.headerAvatar, { backgroundColor: colors.primary + "22" }]}>
            <Text style={{ fontSize: 22 }}>✨</Text>
          </View>
          <View>
            <Text style={[styles.headerTitle, { color: colors.foreground }]}>NeuroLife AI</Text>
            <Text style={[styles.headerSubtitle, { color: colors.success }]}>● Ready</Text>
          </View>
        </View>
        <TouchableOpacity
          onPress={clearHistory}
          style={[styles.clearBtn, { backgroundColor: colors.surface, borderColor: colors.border }]}
        >
          <IconSymbol name="trash" size={15} color={colors.muted} />
        </TouchableOpacity>
      </View>

      <KeyboardAvoidingView
        style={{ flex: 1 }}
        behavior={Platform.OS === "ios" ? "padding" : "height"}
        keyboardVerticalOffset={Platform.OS === "ios" ? 90 : 0}
      >
        {/* Messages — flex:1 so it fills remaining space and scrolls */}
        <FlatList
          ref={flatListRef}
          data={messages}
          keyExtractor={(item) => item.id}
          renderItem={({ item }) => <MessageBubble message={item} colors={colors} />}
          contentContainerStyle={styles.messageList}
          showsVerticalScrollIndicator={false}
          onContentSizeChange={() => flatListRef.current?.scrollToEnd({ animated: true })}
          style={{ flex: 1 }}
        />

        {/* ── Fixed Bottom Bar: chips + voice + text input ── */}
        <View style={[styles.bottomBar, { backgroundColor: colors.background, borderTopColor: colors.border }]}>
          {/* Quick Prompt Chips */}
          <ScrollView
            horizontal
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={styles.promptChipsRow}
            style={styles.promptChipsContainer}
            keyboardShouldPersistTaps="handled"
          >
            {QUICK_PROMPTS.map((prompt, i) => (
              <TouchableOpacity
                key={i}
                onPress={() => sendMessage(prompt.text)}
                style={[
                  styles.promptChip,
                  { backgroundColor: colors.surface, borderColor: colors.border },
                ]}
                activeOpacity={0.7}
              >
                <Text style={{ fontSize: 13 }}>{prompt.icon}</Text>
                <Text style={[styles.promptChipText, { color: colors.foreground }]}>
                  {prompt.text}
                </Text>
              </TouchableOpacity>
            ))}
          </ScrollView>

          {/* Standalone Voice Button Row (native only) */}
          {Platform.OS !== "web" && (
            <View style={[styles.voiceRow, { borderTopColor: colors.border }]}>
              <TouchableOpacity
                onPress={isRecording ? stopRecording : startRecording}
                disabled={isBusy && !isRecording}
                style={[
                  styles.voiceBtn,
                  { backgroundColor: isRecording ? colors.error : colors.primary + "22", borderColor: isRecording ? colors.error : colors.primary },
                  (isBusy && !isRecording) && { opacity: 0.4 },
                ]}
                activeOpacity={0.75}
              >
                <IconSymbol
                  name={isRecording ? "stop.fill" : "mic.fill"}
                  size={20}
                  color={isRecording ? "#fff" : colors.primary}
                />
                <Text style={[styles.voiceBtnLabel, { color: isRecording ? "#fff" : colors.primary }]}>
                  {isRecording ? "Tap to stop recording" : "Hold to speak"}
                </Text>
                {isRecording && (
                  <View style={[styles.recordingDot, { backgroundColor: "#fff" }]} />
                )}
              </TouchableOpacity>
            </View>
          )}

          {/* Text Input Bar */}
          <View
            style={[
              styles.inputBar,
              { borderTopColor: colors.border },
            ]}
          >
            <View
              style={[
                styles.inputWrapper,
                { backgroundColor: colors.surface, borderColor: isRecording ? colors.error : colors.border },
                isRecording && { borderWidth: 1.5 },
              ]}
            >
              <TextInput
                style={[styles.textInput, { color: colors.foreground }]}
                placeholder={isRecording ? "Recording… tap stop when done" : "Ask me anything…"}
                placeholderTextColor={isRecording ? colors.error : colors.muted}
                value={inputText}
                onChangeText={setInputText}
                multiline
                maxLength={500}
                returnKeyType="send"
                onSubmitEditing={() => sendMessage(inputText)}
                editable={!isRecording && !isBusy}
              />
            </View>
            {/* Send button */}
            <TouchableOpacity
              onPress={() => sendMessage(inputText)}
              disabled={!inputText.trim() || isSending || isRecording}
              style={[
                styles.sendBtn,
                {
                  backgroundColor:
                    inputText.trim() && !isSending && !isRecording
                      ? colors.primary
                      : colors.border,
                },
              ]}
            >
              {isSending ? (
                <ActivityIndicator size="small" color="#fff" />
              ) : (
                <IconSymbol name="paperplane.fill" size={17} color="#fff" />
              )}
            </TouchableOpacity>
          </View>
        </View>
      </KeyboardAvoidingView>
    </ScreenContainer>
  );
}

// ─── Styles ───────────────────────────────────────────────────────────────────
const styles = StyleSheet.create({
  header: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderBottomWidth: 0.5,
  },
  headerLeft: { flexDirection: "row", alignItems: "center", gap: 10 },
  headerAvatar: {
    width: 42,
    height: 42,
    borderRadius: 21,
    alignItems: "center",
    justifyContent: "center",
  },
  headerTitle: { fontSize: 16, fontWeight: "700" },
  headerSubtitle: { fontSize: 11, fontWeight: "600" },
  clearBtn: {
    padding: 8,
    borderRadius: 10,
    borderWidth: 1,
  },
  messageList: { padding: 16, gap: 14, paddingBottom: 8 },
  bubbleRow: { flexDirection: "row", alignItems: "flex-end", gap: 8 },
  bubbleRowUser: { flexDirection: "row-reverse" },
  avatar: {
    width: 32,
    height: 32,
    borderRadius: 16,
    alignItems: "center",
    justifyContent: "center",
    flexShrink: 0,
  },
  bubble: {
    paddingHorizontal: 14,
    paddingVertical: 10,
    borderRadius: 18,
    maxWidth: "100%",
  },
  bubbleText: { fontSize: 15, lineHeight: 22 },
  timestamp: { fontSize: 11, marginTop: 2 },
  systemMsg: { alignItems: "center", paddingVertical: 4 },
  systemMsgText: { fontSize: 12, fontStyle: "italic" },
  actionCard: {
    flexDirection: "row",
    alignItems: "flex-start",
    gap: 10,
    padding: 12,
    borderRadius: 14,
    borderWidth: 1,
  },
  actionCardLabel: {
    fontSize: 10,
    fontWeight: "700",
    textTransform: "uppercase",
    letterSpacing: 0.8,
  },
  actionCardTitle: { fontSize: 14, fontWeight: "600", marginTop: 2, lineHeight: 20 },
  actionCardItems: { fontSize: 12, marginTop: 2, lineHeight: 18 },
  // Fixed bottom bar container
  bottomBar: {
    borderTopWidth: 0.5,
  },
  // Quick prompt chips row
  promptChipsContainer: {
    maxHeight: 48,
  },
  promptChipsRow: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 12,
    paddingVertical: 8,
    gap: 8,
  },
  promptChip: {
    flexDirection: "row",
    alignItems: "center",
    gap: 5,
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 16,
    borderWidth: 1,
    flexShrink: 0,
  },
  promptChipText: {
    fontSize: 12,
    fontWeight: "500",
  },
  // Input bar
  inputBar: {
    flexDirection: "row",
    alignItems: "flex-end",
    gap: 8,
    paddingHorizontal: 12,
    paddingVertical: 10,
    borderTopWidth: 0.5, // hairline separator between voice row and text input
  },
  inputWrapper: {
    flex: 1,
    flexDirection: "row",
    alignItems: "flex-end",
    borderRadius: 22,
    borderWidth: 1,
    paddingHorizontal: 14,
    paddingVertical: 8,
    gap: 8,
  },
  textInput: {
    flex: 1,
    fontSize: 15,
    lineHeight: 22,
    maxHeight: 120,
    paddingTop: 0,
    paddingBottom: 0,
  },
  micBtn: {
    padding: 5,
    borderRadius: 14,
    alignItems: "center",
    justifyContent: "center",
    width: 30,
    height: 30,
  },
  voiceRow: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderTopWidth: 0.5,
  },
  voiceBtn: {
    flex: 1,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 8,
    paddingVertical: 11,
    borderRadius: 24,
    borderWidth: 1.5,
  },
  voiceBtnLabel: {
    fontSize: 14,
    fontWeight: "600",
  },
  recordingDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
  },
  sendBtn: {
    width: 44,
    height: 44,
    borderRadius: 22,
    alignItems: "center",
    justifyContent: "center",
  },
  emptyState: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    gap: 14,
    padding: 32,
  },
  emptyTitle: { fontSize: 22, fontWeight: "700" },
  emptySubtitle: { fontSize: 15, textAlign: "center", lineHeight: 22 },
  signInBtn: {
    paddingHorizontal: 32,
    paddingVertical: 14,
    borderRadius: 14,
    marginTop: 8,
  },
});
