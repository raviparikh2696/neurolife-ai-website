import { useState, useEffect } from "react";
import { router } from "expo-router";
import {
  Alert,
  Platform,
  ScrollView,
  StyleSheet,
  Switch,
  Text,
  TouchableOpacity,
  View,
} from "react-native";
import * as Haptics from "expo-haptics";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { useQueryClient } from "@tanstack/react-query";

import { ScreenContainer } from "@/components/screen-container";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { useColors } from "@/hooks/use-colors";
import { useAuth } from "@/hooks/use-auth";
import { useThemeContext } from "@/lib/theme-provider";
import { trpc } from "@/lib/trpc";
import {
  requestNotificationPermissions,
  scheduleDailyMorningBriefing,
  scheduleEveningReminder,
} from "@/lib/notifications";
import * as Notifications from "expo-notifications";

const NOTIF_PREFS_KEY = "@neurolife/notifPrefs";

// ─── Setting Row ──────────────────────────────────────────────────────────────

function SettingRow({
  icon, iconBg, label, subtitle, value, onPress, isSwitch, switchValue, onSwitchChange, colors, destructive,
}: {
  icon: string; iconBg: string; label: string; subtitle?: string;
  value?: string; onPress?: () => void; isSwitch?: boolean;
  switchValue?: boolean; onSwitchChange?: (v: boolean) => void;
  colors: any; destructive?: boolean;
}) {
  return (
    <TouchableOpacity
      style={[styles.settingRow, { borderBottomColor: colors.border }]}
      onPress={onPress}
      disabled={isSwitch || !onPress}
      activeOpacity={0.7}
    >
      <View style={[styles.settingIcon, { backgroundColor: iconBg }]}>
        <Text style={{ fontSize: 18 }}>{icon}</Text>
      </View>
      <View style={styles.settingBody}>
        <Text style={[styles.settingLabel, { color: destructive ? colors.error : colors.foreground }]}>{label}</Text>
        {subtitle ? <Text style={[styles.settingSubtitle, { color: colors.muted }]}>{subtitle}</Text> : null}
      </View>
      {isSwitch ? (
        <Switch
          value={switchValue}
          onValueChange={onSwitchChange}
          trackColor={{ false: colors.border, true: colors.primary }}
          thumbColor="#fff"
          ios_backgroundColor={colors.border}
        />
      ) : value ? (
        <Text style={[styles.settingValue, { color: colors.muted }]}>{value}</Text>
      ) : onPress ? (
        <IconSymbol name="chevron.right" size={16} color={colors.muted} />
      ) : null}
    </TouchableOpacity>
  );
}

function SectionHeader({ title, colors }: { title: string; colors: any }) {
  return (
    <Text style={[styles.sectionHeader, { color: colors.muted }]}>{title.toUpperCase()}</Text>
  );
}

// ─── Main Screen ──────────────────────────────────────────────────────────────

export default function SettingsScreen() {
  const colors = useColors();
  const { colorScheme, setColorScheme, isDark } = useThemeContext();
  const { user, isAuthenticated } = useAuth();

  const [notificationsEnabled, setNotificationsEnabled] = useState(false);
  const [morningBriefing, setMorningBriefing] = useState(false);
  const [eveningReminder, setEveningReminder] = useState(false);

  const { logout: authLogout } = useAuth();
  const queryClient = useQueryClient();
  const clearHistory = trpc.ai.clearHistory.useMutation();
  const logoutMutation = trpc.auth.logout.useMutation();

  // Load notification preferences from AsyncStorage
  useEffect(() => {
    const loadPrefs = async () => {
      try {
        // Check actual permission status
        if (Platform.OS !== "web") {
          const { status } = await Notifications.getPermissionsAsync();
          setNotificationsEnabled(status === "granted");
        }
        // Load saved toggles
        const stored = await AsyncStorage.getItem(NOTIF_PREFS_KEY);
        if (stored) {
          const prefs = JSON.parse(stored);
          setMorningBriefing(prefs.morningBriefing ?? false);
          setEveningReminder(prefs.eveningReminder ?? false);
        }
      } catch {}
    };
    loadPrefs();
  }, []);

  const saveNotifPrefs = async (prefs: { morningBriefing: boolean; eveningReminder: boolean }) => {
    try {
      await AsyncStorage.setItem(NOTIF_PREFS_KEY, JSON.stringify(prefs));
    } catch {}
  };

  // ─── Dark Mode ───────────────────────────────────────────────────────────────

  const handleDarkModeToggle = (value: boolean) => {
    const scheme = value ? "dark" : "light";
    setColorScheme(scheme);
    if (Platform.OS !== "web") Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
  };

  // ─── Notifications ───────────────────────────────────────────────────────────

  const handleNotificationsToggle = async (value: boolean) => {
    if (value) {
      const granted = await requestNotificationPermissions();
      setNotificationsEnabled(granted);
      if (!granted) {
        Alert.alert(
          "Permission denied",
          "Please enable notifications for NeuroLife in your device Settings app.",
          [{ text: "OK" }]
        );
      }
    } else {
      setNotificationsEnabled(false);
    }
    if (Platform.OS !== "web") Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
  };

  const handleMorningBriefing = async (value: boolean) => {
    setMorningBriefing(value);
    await saveNotifPrefs({ morningBriefing: value, eveningReminder });
    if (value) {
      const granted = await requestNotificationPermissions();
      if (granted) {
        await scheduleDailyMorningBriefing();
        if (Platform.OS !== "web") Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      } else {
        setMorningBriefing(false);
        Alert.alert("Permission required", "Please enable notifications first.");
      }
    }
    if (Platform.OS !== "web") Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
  };

  const handleEveningReminder = async (value: boolean) => {
    setEveningReminder(value);
    await saveNotifPrefs({ morningBriefing, eveningReminder: value });
    if (value) {
      const granted = await requestNotificationPermissions();
      if (granted) {
        await scheduleEveningReminder();
        if (Platform.OS !== "web") Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      } else {
        setEveningReminder(false);
        Alert.alert("Permission required", "Please enable notifications first.");
      }
    }
    if (Platform.OS !== "web") Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
  };

  const handleClearChatHistory = () => {
    Alert.alert("Clear Chat History", "This will delete all AI conversation history. Continue?", [
      { text: "Cancel", style: "cancel" },
      {
        text: "Clear",
        style: "destructive",
        onPress: () => {
          clearHistory.mutate();
          if (Platform.OS !== "web") Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
        },
      },
    ]);
  };

  const handleLogout = () => {
    Alert.alert("Sign Out", "Are you sure you want to sign out?", [
      { text: "Cancel", style: "cancel" },
      {
        text: "Sign Out",
        style: "destructive",
        onPress: async () => {
          logoutMutation.mutate();
          await authLogout();
          // Clear all cached query data so the next user sees a clean state
          queryClient.clear();
          if (Platform.OS !== "web") Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
          router.replace("/sign-in" as any);
        },
      },
    ]);
  };

  return (
    <ScreenContainer containerClassName="bg-background">
      {/* Header */}
      <View style={[styles.header, { borderBottomColor: colors.border }]}>
        <Text style={[styles.screenTitle, { color: colors.foreground }]}>Settings</Text>
      </View>

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.scrollContent}>
        {/* Profile Card */}
        {isAuthenticated && user ? (
          <View style={[styles.profileCard, { backgroundColor: colors.surface, borderColor: colors.border }]}>
            <View style={[styles.profileAvatar, { backgroundColor: colors.primary + "22" }]}>
              <Text style={[styles.profileInitial, { color: colors.primary }]}>
                {user.name ? user.name.charAt(0).toUpperCase() : "U"}
              </Text>
            </View>
            <View style={styles.profileInfo}>
              <Text style={[styles.profileName, { color: colors.foreground }]}>{user.name ?? "User"}</Text>
              <Text style={[styles.profileEmail, { color: colors.muted }]}>{user.email ?? ""}</Text>
            </View>
            <View style={[styles.profileBadge, { backgroundColor: colors.success + "22" }]}>
              <Text style={[styles.profileBadgeText, { color: colors.success }]}>Active</Text>
            </View>
          </View>
        ) : (
          <View style={[styles.profileCard, { backgroundColor: colors.surface, borderColor: colors.border }]}>
            <View style={[styles.profileAvatar, { backgroundColor: colors.muted + "22" }]}>
              <Text style={{ fontSize: 28 }}>👤</Text>
            </View>
            <View style={styles.profileInfo}>
              <Text style={[styles.profileName, { color: colors.foreground }]}>Not signed in</Text>
              <Text style={[styles.profileEmail, { color: colors.muted }]}>Sign in to sync your data</Text>
            </View>
          </View>
        )}

        {/* Appearance */}
        <SectionHeader title="Appearance" colors={colors} />
        <View style={[styles.section, { backgroundColor: colors.surface, borderColor: colors.border }]}>
          <SettingRow
            icon={isDark ? "🌙" : "☀️"}
            iconBg={colors.primary + "22"}
            label="Dark Mode"
            subtitle={isDark ? "Dark theme active — tap to switch to Light" : "Light theme active — tap to switch to Dark"}
            isSwitch
            switchValue={isDark}
            onSwitchChange={handleDarkModeToggle}
            colors={colors}
          />
          <SettingRow
            icon="🎨"
            iconBg={colors.primary + "22"}
            label="Current Theme"
            value={colorScheme === "dark" ? "Dark" : "Light"}
            colors={colors}
          />
        </View>

        {/* Notifications */}
        <SectionHeader title="Notifications" colors={colors} />
        <View style={[styles.section, { backgroundColor: colors.surface, borderColor: colors.border }]}>
          <SettingRow
            icon="🔔"
            iconBg={colors.warning + "22"}
            label="Enable Notifications"
            subtitle={notificationsEnabled ? "Notifications are enabled" : "Tap to allow NeuroLife notifications"}
            isSwitch
            switchValue={notificationsEnabled}
            onSwitchChange={handleNotificationsToggle}
            colors={colors}
          />
          <SettingRow
            icon="☀️"
            iconBg={colors.warning + "22"}
            label="Morning Briefing"
            subtitle="Daily schedule reminder at 8:00 AM"
            isSwitch
            switchValue={morningBriefing}
            onSwitchChange={handleMorningBriefing}
            colors={colors}
          />
          <SettingRow
            icon="🌙"
            iconBg={colors.primary + "22"}
            label="Evening Reminder"
            subtitle="Task review reminder at 8:00 PM"
            isSwitch
            switchValue={eveningReminder}
            onSwitchChange={handleEveningReminder}
            colors={colors}
          />
          <SettingRow
            icon="⏰"
            iconBg={colors.success + "22"}
            label="Event Reminders"
            subtitle="1hr, 30min, 10min before events & tasks"
            value="Auto"
            colors={colors}
          />
        </View>

        {/* AI & Data */}
        <SectionHeader title="AI & Data" colors={colors} />
        <View style={[styles.section, { backgroundColor: colors.surface, borderColor: colors.border }]}>
          <SettingRow
            icon="🤖"
            iconBg={colors.primary + "22"}
            label="AI Assistant"
            subtitle="Powered by NeuroLife AI"
            value="Active"
            colors={colors}
          />
          <SettingRow
            icon="🗑️"
            iconBg={colors.error + "22"}
            label="Clear Chat History"
            subtitle="Delete all AI conversations"
            onPress={handleClearChatHistory}
            colors={colors}
            destructive
          />
        </View>

        {/* About */}
        <SectionHeader title="About" colors={colors} />
        <View style={[styles.section, { backgroundColor: colors.surface, borderColor: colors.border }]}>
          <SettingRow
            icon="📱"
            iconBg={colors.muted + "22"}
            label="App Version"
            value="1.0.0"
            colors={colors}
          />
          <SettingRow
            icon="✨"
            iconBg={colors.primary + "22"}
            label="NeuroLife AI"
            subtitle="Your AI-powered life organizer"
            colors={colors}
          />
          <SettingRow
            icon="🔒"
            iconBg={colors.success + "22"}
            label="Privacy"
            subtitle="Your data is stored securely"
            colors={colors}
          />
        </View>

        {/* Account */}
        {isAuthenticated && (
          <>
            <SectionHeader title="Account" colors={colors} />
            <View style={[styles.section, { backgroundColor: colors.surface, borderColor: colors.border }]}>
              <SettingRow
                icon="🚪"
                iconBg={colors.error + "22"}
                label="Sign Out"
                onPress={handleLogout}
                colors={colors}
                destructive
              />
            </View>
          </>
        )}

        {/* Footer */}
        <View style={styles.footer}>
          <Text style={[styles.footerText, { color: colors.muted }]}>NeuroLife AI · Built with ❤️</Text>
          <Text style={[styles.footerText, { color: colors.muted }]}>Your personal AI life organizer</Text>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  header: { paddingHorizontal: 16, paddingVertical: 12, borderBottomWidth: 0.5 },
  screenTitle: { fontSize: 28, fontWeight: "700" },
  scrollContent: { paddingBottom: 100 },
  profileCard: { flexDirection: "row", alignItems: "center", margin: 16, borderRadius: 16, borderWidth: 1, padding: 16, gap: 12 },
  profileAvatar: { width: 56, height: 56, borderRadius: 28, alignItems: "center", justifyContent: "center" },
  profileInitial: { fontSize: 24, fontWeight: "700" },
  profileInfo: { flex: 1 },
  profileName: { fontSize: 17, fontWeight: "600" },
  profileEmail: { fontSize: 13, marginTop: 2 },
  profileBadge: { paddingHorizontal: 10, paddingVertical: 4, borderRadius: 10 },
  profileBadgeText: { fontSize: 12, fontWeight: "700" },
  sectionHeader: { fontSize: 12, fontWeight: "700", paddingHorizontal: 16, paddingTop: 20, paddingBottom: 6, letterSpacing: 0.5 },
  section: { marginHorizontal: 16, borderRadius: 16, borderWidth: 1, overflow: "hidden" },
  settingRow: { flexDirection: "row", alignItems: "center", paddingHorizontal: 16, paddingVertical: 14, borderBottomWidth: 0.5, gap: 12 },
  settingIcon: { width: 36, height: 36, borderRadius: 10, alignItems: "center", justifyContent: "center" },
  settingBody: { flex: 1 },
  settingLabel: { fontSize: 15, fontWeight: "500" },
  settingSubtitle: { fontSize: 12, marginTop: 2 },
  settingValue: { fontSize: 14 },
  footer: { alignItems: "center", paddingTop: 24, gap: 4 },
  footerText: { fontSize: 12 },
});
