import { useRouter } from "expo-router";
import { useEffect, useState, useRef } from "react";
import {
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
  RefreshControl,
  Platform,
} from "react-native";

import { ScreenContainer } from "@/components/screen-container";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { useColors } from "@/hooks/use-colors";
import { trpc } from "@/lib/trpc";
import {
  requestNotificationPermissions,
  scheduleDailyMorningBriefing,
  scheduleEveningReminder,
} from "@/lib/notifications";
import { useAuth } from "@/hooks/use-auth";
import { NativeAdCard, type NativeAdCardHandle } from "@/components/native-ad-card";

// Platform-specific ad unit IDs for Home screen
const HOME_AD_UNIT_ID = Platform.select({
  android: 'ca-app-pub-1720679341163644/8844075255',
  ios: 'ca-app-pub-1720679341163644/6765344858',
  default: '',
});

// ─── Grocery Category Emojis ─────────────────────────────────────────────────

const GROCERY_EMOJIS: Record<string, string> = {
  fruits: "🍎",
  dairy: "🥛",
  vegetables: "🥕",
  bakery: "🍞",
  meat: "🥩",
  beverages: "☕",
  other: "🛒",
};

// ─── Helpers ──────────────────────────────────────────────────────────────────

function getGreeting(): string {
  const hour = new Date().getHours();
  if (hour < 12) return "Good morning";
  if (hour < 17) return "Good afternoon";
  return "Good evening";
}

function formatDate(date: Date): string {
  return date.toLocaleDateString("en-US", {
    weekday: "long",
    month: "long",
    day: "numeric",
  });
}

function formatTime(date: Date): string {
  return date.toLocaleTimeString("en-US", {
    hour: "numeric",
    minute: "2-digit",
    hour12: true,
  });
}

function getTimeOfDay(date: Date): "morning" | "afternoon" | "evening" {
  const h = date.getHours();
  if (h < 12) return "morning";
  if (h < 17) return "afternoon";
  return "evening";
}

const PRIORITY_COLORS: Record<string, string> = {
  high: "#F87171",
  medium: "#FBBF24",
  low: "#34D399",
};

// ─── Sub-components ───────────────────────────────────────────────────────────

function SectionHeader({ title, color }: { title: string; color: string }) {
  return (
    <View style={styles.sectionHeader}>
      <View style={[styles.sectionDot, { backgroundColor: color }]} />
      <Text style={[styles.sectionTitle, { color }]}>{title}</Text>
    </View>
  );
}

function EventCard({ event, colors }: { event: any; colors: any }) {
  return (
    <View
      style={[
        styles.eventCard,
        { backgroundColor: colors.surface, borderColor: colors.border },
      ]}
    >
      <View style={[styles.eventTimeBar, { backgroundColor: "#8B5CF6" }]} />
      <View style={styles.eventContent}>
        <Text
          style={[styles.eventTitle, { color: colors.foreground }]}
          numberOfLines={1}
        >
          {event.title}
        </Text>
        <Text style={[styles.eventTime, { color: colors.muted }]}>
          {formatTime(new Date(event.startTime))}
        </Text>
        {event.location ? (
          <Text
            style={[styles.eventLocation, { color: colors.muted }]}
            numberOfLines={1}
          >
            📍 {event.location}
          </Text>
        ) : null}
      </View>
    </View>
  );
}

function TaskCard({
  task,
  colors,
  onComplete,
}: {
  task: any;
  colors: any;
  onComplete: () => void;
}) {
  return (
    <View
      style={[
        styles.taskCard,
        { backgroundColor: colors.surface, borderColor: colors.border },
      ]}
    >
      <TouchableOpacity
        onPress={onComplete}
        style={[
          styles.taskCheckbox,
          { borderColor: PRIORITY_COLORS[task.priority] },
        ]}
        hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}
      />
      <View style={styles.taskContent}>
        <Text
          style={[styles.taskTitle, { color: colors.foreground }]}
          numberOfLines={2}
        >
          {task.title}
        </Text>
        {task.dueDate ? (
          <Text style={[styles.taskDue, { color: colors.muted }]}>
            Due:{" "}
            {new Date(task.dueDate).toLocaleDateString("en-US", {
              month: "short",
              day: "numeric",
              hour: "numeric",
              minute: "2-digit",
            })}
          </Text>
        ) : null}
      </View>
      <View
        style={[
          styles.priorityBadge,
          { backgroundColor: PRIORITY_COLORS[task.priority] + "22" },
        ]}
      >
        <Text
          style={[
            styles.priorityText,
            { color: PRIORITY_COLORS[task.priority] },
          ]}
        >
          {task.priority.toUpperCase()}
        </Text>
      </View>
    </View>
  );
}

// ─── Smart Summary Card ───────────────────────────────────────────────────────

function SmartSummaryCard({
  colors,
  todayEventCount,
  nextEvent,
  pendingTaskCount,
  completedTaskCount,
  totalTaskCount,
  groceryCount,
  purchasedGroceryCount,
  onNavigate,
}: {
  colors: any;
  todayEventCount: number;
  nextEvent: any | null;
  pendingTaskCount: number;
  completedTaskCount: number;
  totalTaskCount: number;
  groceryCount: number;
  purchasedGroceryCount: number;
  onNavigate: (route: string) => void;
}) {
  const taskPct =
    totalTaskCount > 0
      ? Math.round((completedTaskCount / totalTaskCount) * 100)
      : 0;
  const groceryPct =
    groceryCount > 0
      ? Math.round((purchasedGroceryCount / groceryCount) * 100)
      : 0;

  return (
    <View
      style={[
        styles.summaryCard,
        { backgroundColor: colors.surface, borderColor: colors.border },
      ]}
    >
      {/* Header */}
      <View style={styles.summaryHeader}>
        <Text style={[styles.summaryTitle, { color: colors.foreground }]}>
          Day at a Glance
        </Text>
        <Text style={[styles.summarySubtitle, { color: colors.muted }]}>
          {formatDate(new Date())}
        </Text>
      </View>

      {/* Three stat pills */}
      <View style={styles.pillRow}>
        {/* Events */}
        <TouchableOpacity
          style={[
            styles.pill,
            { backgroundColor: "#8B5CF6" + "18", borderColor: "#8B5CF6" + "40" },
          ]}
          onPress={() => onNavigate("/calendar")}
        >
          <Text style={[styles.pillIcon]}>📅</Text>
          <Text style={[styles.pillCount, { color: "#8B5CF6" }]}>
            {todayEventCount}
          </Text>
          <Text style={[styles.pillLabel, { color: colors.muted }]}>
            {todayEventCount === 1 ? "Event" : "Events"}
          </Text>
        </TouchableOpacity>

        {/* Tasks */}
        <TouchableOpacity
          style={[
            styles.pill,
            {
              backgroundColor: colors.primary + "18",
              borderColor: colors.primary + "40",
            },
          ]}
          onPress={() => onNavigate("/tasks")}
        >
          <Text style={styles.pillIcon}>✅</Text>
          <Text style={[styles.pillCount, { color: colors.primary }]}>
            {pendingTaskCount}
          </Text>
          <Text style={[styles.pillLabel, { color: colors.muted }]}>
            Pending
          </Text>
        </TouchableOpacity>

        {/* Groceries */}
        <TouchableOpacity
          style={[
            styles.pill,
            {
              backgroundColor: colors.success + "18",
              borderColor: colors.success + "40",
            },
          ]}
          onPress={() => onNavigate("/groceries")}
        >
          <Text style={styles.pillIcon}>🛒</Text>
          <Text style={[styles.pillCount, { color: colors.success }]}>
            {groceryCount - purchasedGroceryCount}
          </Text>
          <Text style={[styles.pillLabel, { color: colors.muted }]}>
            To Buy
          </Text>
        </TouchableOpacity>
      </View>

      {/* Progress rows */}
      <View style={styles.progressSection}>
        {/* Task progress */}
        <View style={styles.progressRow}>
          <View style={styles.progressLabelRow}>
            <Text style={[styles.progressLabel, { color: colors.foreground }]}>
              Tasks
            </Text>
            <Text style={[styles.progressPct, { color: colors.primary }]}>
              {completedTaskCount}/{totalTaskCount} done
            </Text>
          </View>
          <View
            style={[styles.progressBar, { backgroundColor: colors.border }]}
          >
            <View
              style={[
                styles.progressFill,
                {
                  backgroundColor: colors.primary,
                  width: `${taskPct}%` as any,
                },
              ]}
            />
          </View>
        </View>

        {/* Grocery progress */}
        <View style={[styles.progressRow, { marginTop: 10 }]}>
          <View style={styles.progressLabelRow}>
            <Text style={[styles.progressLabel, { color: colors.foreground }]}>
              Groceries
            </Text>
            <Text style={[styles.progressPct, { color: colors.success }]}>
              {purchasedGroceryCount}/{groceryCount} bought
            </Text>
          </View>
          <View
            style={[styles.progressBar, { backgroundColor: colors.border }]}
          >
            <View
              style={[
                styles.progressFill,
                {
                  backgroundColor: colors.success,
                  width: `${groceryPct}%` as any,
                },
              ]}
            />
          </View>
        </View>
      </View>

      {/* Next event banner */}
      {nextEvent ? (
        <TouchableOpacity
          style={[
            styles.nextEventBanner,
            { backgroundColor: "#8B5CF6" + "12", borderColor: "#8B5CF6" + "30" },
          ]}
          onPress={() => onNavigate("/calendar")}
        >
          <View
            style={[styles.nextEventDot, { backgroundColor: "#8B5CF6" }]}
          />
          <View style={{ flex: 1 }}>
            <Text style={[styles.nextEventLabel, { color: colors.muted }]}>
              Next up
            </Text>
            <Text
              style={[styles.nextEventTitle, { color: colors.foreground }]}
              numberOfLines={1}
            >
              {nextEvent.title}
            </Text>
          </View>
          <Text style={[styles.nextEventTime, { color: "#8B5CF6" }]}>
            {formatTime(new Date(nextEvent.startTime))}
          </Text>
        </TouchableOpacity>
      ) : null}
    </View>
  );
}

// ─── Main Screen ──────────────────────────────────────────────────────────────

export default function HomeScreen() {
  const colors = useColors();
  const router = useRouter();
  const { user, isAuthenticated } = useAuth();
  const [refreshing, setRefreshing] = useState(false);
  const adRef = useRef<NativeAdCardHandle>(null);

  const today = new Date();
  const startOfDay = new Date(today);
  startOfDay.setHours(0, 0, 0, 0);
  const endOfDay = new Date(today);
  endOfDay.setHours(23, 59, 59, 999);

  // ── Data queries ────────────────────────────────────────────────────────────
  // staleTime: 0 ensures data refreshes immediately after AI creates items
  const { data: allTasks, refetch: refetchTasks } = trpc.tasks.list.useQuery(
    { includeCompleted: true },
    { enabled: isAuthenticated, staleTime: 0 }
  );
  const { data: events, refetch: refetchEvents } = trpc.events.list.useQuery(
    {
      startDate: startOfDay.toISOString(),
      endDate: endOfDay.toISOString(),
    },
    { enabled: isAuthenticated, staleTime: 0 }
  );
  const { data: groceries, refetch: refetchGroceries } = trpc.groceries.list.useQuery(undefined, {
    enabled: isAuthenticated,
    staleTime: 0,
    gcTime: 5 * 60 * 1000,
  });

  const handleRefresh = async () => {
    setRefreshing(true);
    try {
      // Refetch all data sources in parallel for instant home screen update
      await Promise.all([refetchTasks(), refetchEvents(), refetchGroceries()]);
      // Rotate the native ad with fresh content on every pull-to-refresh
      adRef.current?.refresh();
    } finally {
      setRefreshing(false);
    }
  };

  const completeTask = trpc.tasks.update.useMutation({
    onSuccess: () => refetchTasks(),
  });

  // Request notification permissions on mount
  useEffect(() => {
    requestNotificationPermissions().then((granted) => {
      if (granted) {
        scheduleDailyMorningBriefing();
        scheduleEveningReminder();
      }
    });
  }, []);

  // ── Derived data ─────────────────────────────────────────────────────────────
  const pendingTasks = (allTasks ?? []).filter((t) => !t.completed);
  const completedTasks = (allTasks ?? []).filter((t) => t.completed);

  const topPendingTasks = [...pendingTasks]
    .sort((a, b) => {
      const pOrder: Record<string, number> = { high: 0, medium: 1, low: 2 };
      return (pOrder[a.priority] ?? 1) - (pOrder[b.priority] ?? 1);
    })
    .slice(0, 5);

  const morningEvents = (events ?? []).filter(
    (e) => getTimeOfDay(new Date(e.startTime)) === "morning"
  );
  const afternoonEvents = (events ?? []).filter(
    (e) => getTimeOfDay(new Date(e.startTime)) === "afternoon"
  );
  const eveningEvents = (events ?? []).filter(
    (e) => getTimeOfDay(new Date(e.startTime)) === "evening"
  );

  // Next upcoming event (after now)
  const now = Date.now();
  const nextEvent =
    (events ?? [])
      .filter((e) => new Date(e.startTime).getTime() > now)
      .sort(
        (a, b) =>
          new Date(a.startTime).getTime() - new Date(b.startTime).getTime()
      )[0] ?? null;

  // groceries.list returns a flat array of grocery items
  const allGroceries = (groceries ?? []) as any[];
  const purchasedGroceries = allGroceries.filter((i: any) => i.purchased);
  const groceriesWithEmoji = allGroceries.map((g) => ({
    ...g,
    emoji: GROCERY_EMOJIS[g.category] || "🛒",
  }));

  const hasTodayContent =
    morningEvents.length > 0 ||
    afternoonEvents.length > 0 ||
    eveningEvents.length > 0;

  const handleCompleteTask = (taskId: number) => {
    completeTask.mutate({
      id: taskId,
      completed: true,
      completedAt: new Date().toISOString(),
    });
  };

  return (
    <ScreenContainer containerClassName="bg-background">
      <ScrollView
        style={{ flex: 1 }}
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false}
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={handleRefresh}
            tintColor={colors.primary}
          />
        }
      >
        {/* ── Header ──────────────────────────────────────────────────────── */}
        <View style={styles.header}>
          <View>
            <Text style={[styles.greeting, { color: colors.foreground }]}>
              {getGreeting()}
              {user?.name ? `, ${user.name.split(" ")[0]}` : ""}
            </Text>
            <Text style={[styles.dateText, { color: colors.muted }]}>
              {formatDate(today)}
            </Text>
          </View>
          <TouchableOpacity
            style={[
              styles.settingsBtn,
              { backgroundColor: colors.surface, borderColor: colors.border },
            ]}
            onPress={() => router.navigate("/settings" as any)}
          >
            <IconSymbol name="gearshape.fill" size={20} color={colors.muted} />
          </TouchableOpacity>
        </View>

        {/* ── Smart Summary Card ───────────────────────────────────────────── */}
        {isAuthenticated ? (
          <SmartSummaryCard
            colors={colors}
            todayEventCount={(events ?? []).length}
            nextEvent={nextEvent}
            pendingTaskCount={pendingTasks.length}
            completedTaskCount={completedTasks.length}
            totalTaskCount={(allTasks ?? []).length}
            groceryCount={allGroceries.length}
            purchasedGroceryCount={purchasedGroceries.length}
            onNavigate={(route) => router.navigate(route as any)}
          />
        ) : (
          <View
            style={[
              styles.signInBanner,
              { backgroundColor: colors.primary + "12", borderColor: colors.primary + "30" },
            ]}
          >
            <Text style={[styles.signInText, { color: colors.foreground }]}>
              Sign in to see your daily summary
            </Text>
            <TouchableOpacity
              style={[styles.signInBtn, { backgroundColor: colors.primary }]}
              onPress={() => router.navigate("/sign-in" as any)}
            >
              <Text style={styles.signInBtnText}>Sign In</Text>
            </TouchableOpacity>
          </View>
        )}

        {/* ── Today's Schedule ─────────────────────────────────────────────── */}
        <View style={styles.section}>
          <View style={styles.sectionRow}>
            <Text style={[styles.sectionHeading, { color: colors.foreground }]}>
              Today's Schedule
            </Text>
            <TouchableOpacity onPress={() => router.navigate("/calendar" as any)}>
              <Text style={[styles.seeAll, { color: colors.primary }]}>
                See all
              </Text>
            </TouchableOpacity>
          </View>

          {!isAuthenticated ? null : !hasTodayContent ? (
            <View
              style={[
                styles.emptyCard,
                { backgroundColor: colors.surface, borderColor: colors.border },
              ]}
            >
              <IconSymbol name="calendar" size={32} color={colors.muted} />
              <Text style={[styles.emptyText, { color: colors.muted }]}>
                No events today
              </Text>
              <TouchableOpacity
                style={[
                  styles.emptyAction,
                  { backgroundColor: colors.primary },
                ]}
                onPress={() => router.navigate("/calendar" as any)}
              >
                <Text style={[styles.emptyActionText, { color: "#fff" }]}>
                  Add Event
                </Text>
              </TouchableOpacity>
            </View>
          ) : (
            <>
              {morningEvents.length > 0 && (
                <>
                  <SectionHeader title="Morning" color="#FBBF24" />
                  {morningEvents.map((e) => (
                    <EventCard key={e.id} event={e} colors={colors} />
                  ))}
                </>
              )}
              {afternoonEvents.length > 0 && (
                <>
                  <SectionHeader title="Afternoon" color="#8B5CF6" />
                  {afternoonEvents.map((e) => (
                    <EventCard key={e.id} event={e} colors={colors} />
                  ))}
                </>
              )}
              {eveningEvents.length > 0 && (
                <>
                  <SectionHeader title="Evening" color={colors.primary} />
                  {eveningEvents.map((e) => (
                    <EventCard key={e.id} event={e} colors={colors} />
                  ))}
                </>
              )}
            </>
          )}
        </View>

        {/* ── Pending Tasks ────────────────────────────────────────────────── */}
        {isAuthenticated && (
          <View style={styles.section}>
            <View style={styles.sectionRow}>
              <Text
                style={[styles.sectionHeading, { color: colors.foreground }]}
              >
                Pending Tasks
              </Text>
              <TouchableOpacity onPress={() => router.navigate("/tasks" as any)}>
                <Text style={[styles.seeAll, { color: colors.primary }]}>
                  See all
                </Text>
              </TouchableOpacity>
            </View>

            {topPendingTasks.length === 0 ? (
              <View
                style={[
                  styles.emptyCard,
                  {
                    backgroundColor: colors.surface,
                    borderColor: colors.border,
                  },
                ]}
              >
                <IconSymbol
                  name="checkmark.circle.fill"
                  size={32}
                  color={colors.success}
                />
                <Text style={[styles.emptyText, { color: colors.muted }]}>
                  All tasks complete! 🎉
                </Text>
              </View>
            ) : (
              topPendingTasks.map((task) => (
                <TaskCard
                  key={task.id}
                  task={task}
                  colors={colors}
                  onComplete={() => handleCompleteTask(task.id)}
                />
              ))
            )}
          </View>
        )}

        {/* ── Quick Actions ────────────────────────────────────────────────── */}
        <View style={styles.section}>
          <Text style={[styles.sectionHeading, { color: colors.foreground }]}>
            Quick Actions
          </Text>
          <View style={styles.quickActionsGrid}>
            {[
              {
                label: "Add Task",
                icon: "checkmark.circle.fill" as const,
                color: colors.primary,
                route: "/tasks",
              },
              {
                label: "Add Event",
                icon: "calendar" as const,
                color: "#8B5CF6",
                route: "/calendar",
              },
              {
                label: "Groceries",
                icon: "cart.fill" as const,
                color: colors.success,
                route: "/groceries",
              },
              {
                label: "AI Chat",
                icon: "sparkles" as const,
                color: "#F59E0B",
                route: "/assistant",
              },
              {
                label: "Memory",
                icon: "brain.head.profile" as const,
                color: "#EC4899",
                route: "/memory",
              },
              {
                label: "Settings",
                icon: "gearshape.fill" as const,
                color: colors.muted,
                route: "/settings",
              },
            ].map((action) => (
              <TouchableOpacity
                key={action.label}
                style={[
                  styles.quickAction,
                  {
                    backgroundColor: action.color + "15",
                    borderColor: action.color + "40",
                  },
                ]}
                onPress={() => router.navigate(action.route as any)}
              >
                <IconSymbol name={action.icon} size={24} color={action.color} />
                <Text
                  style={[styles.quickActionLabel, { color: action.color }]}
                >
                  {action.label}
                </Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>

        {/* ── Native Ad (AdMob Native Advanced) ─────────────────────── */}
        <View style={styles.section}>
          <NativeAdCard ref={adRef} adUnitId={HOME_AD_UNIT_ID} />
        </View>
        <View style={{ height: 32 }} />
      </ScrollView>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  scrollContent: { paddingHorizontal: 16, paddingTop: 8 },
  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "flex-start",
    marginBottom: 20,
  },
  greeting: { fontSize: 26, fontWeight: "700", letterSpacing: -0.5 },
  dateText: { fontSize: 14, marginTop: 2 },
  settingsBtn: {
    width: 40,
    height: 40,
    borderRadius: 20,
    borderWidth: 1,
    alignItems: "center",
    justifyContent: "center",
  },
  // Smart Summary Card
  summaryCard: {
    borderRadius: 20,
    borderWidth: 1,
    padding: 18,
    marginBottom: 24,
    gap: 16,
  },
  summaryHeader: { gap: 2 },
  summaryTitle: { fontSize: 18, fontWeight: "700" },
  summarySubtitle: { fontSize: 13 },
  pillRow: { flexDirection: "row", gap: 10 },
  pill: {
    flex: 1,
    borderRadius: 14,
    borderWidth: 1,
    paddingVertical: 12,
    alignItems: "center",
    gap: 2,
  },
  pillIcon: { fontSize: 18 },
  pillCount: { fontSize: 22, fontWeight: "800", lineHeight: 26 },
  pillLabel: { fontSize: 11, fontWeight: "500" },
  progressSection: { gap: 0 },
  progressRow: {},
  progressLabelRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginBottom: 6,
  },
  progressLabel: { fontSize: 13, fontWeight: "600" },
  progressPct: { fontSize: 12, fontWeight: "600" },
  progressBar: { height: 6, borderRadius: 3, overflow: "hidden" },
  progressFill: { height: "100%", borderRadius: 3 },
  nextEventBanner: {
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
    borderRadius: 12,
    borderWidth: 1,
    padding: 12,
  },
  nextEventDot: { width: 8, height: 8, borderRadius: 4 },
  nextEventLabel: { fontSize: 11, fontWeight: "500" },
  nextEventTitle: { fontSize: 14, fontWeight: "600", marginTop: 1 },
  nextEventTime: { fontSize: 14, fontWeight: "700" },
  // Sign in banner
  signInBanner: {
    borderRadius: 16,
    borderWidth: 1,
    padding: 20,
    alignItems: "center",
    gap: 12,
    marginBottom: 24,
  },
  signInText: { fontSize: 15, fontWeight: "500", textAlign: "center" },
  signInBtn: {
    paddingHorizontal: 24,
    paddingVertical: 10,
    borderRadius: 20,
  },
  signInBtnText: { color: "#fff", fontSize: 14, fontWeight: "700" },
  // Sections
  section: { marginBottom: 24 },
  sectionRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 12,
  },
  sectionHeading: { fontSize: 18, fontWeight: "700" },
  seeAll: { fontSize: 14, fontWeight: "600" },
  sectionHeader: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 8,
    marginTop: 4,
  },
  sectionDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    marginRight: 8,
  },
  sectionTitle: {
    fontSize: 13,
    fontWeight: "600",
    textTransform: "uppercase",
    letterSpacing: 0.5,
  },
  emptyCard: {
    borderRadius: 16,
    borderWidth: 1,
    padding: 24,
    alignItems: "center",
    gap: 8,
  },
  emptyText: { fontSize: 14, textAlign: "center" },
  emptyAction: {
    paddingHorizontal: 20,
    paddingVertical: 8,
    borderRadius: 20,
    marginTop: 4,
  },
  emptyActionText: { fontSize: 14, fontWeight: "600" },
  // Event card
  eventCard: {
    flexDirection: "row",
    borderRadius: 12,
    borderWidth: 1,
    marginBottom: 8,
    overflow: "hidden",
  },
  eventTimeBar: { width: 4 },
  eventContent: { flex: 1, padding: 12 },
  eventTitle: { fontSize: 15, fontWeight: "600", marginBottom: 2 },
  eventTime: { fontSize: 13 },
  eventLocation: { fontSize: 12, marginTop: 2 },
  // Task card
  taskCard: {
    flexDirection: "row",
    alignItems: "center",
    borderRadius: 12,
    borderWidth: 1,
    padding: 12,
    marginBottom: 8,
    gap: 12,
  },
  taskCheckbox: {
    width: 22,
    height: 22,
    borderRadius: 11,
    borderWidth: 2,
  },
  taskContent: { flex: 1 },
  taskTitle: { fontSize: 15, fontWeight: "500" },
  taskDue: { fontSize: 12, marginTop: 2 },
  priorityBadge: {
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: 8,
  },
  priorityText: { fontSize: 10, fontWeight: "700" },
  // Quick actions
  quickActionsGrid: { flexDirection: "row", flexWrap: "wrap", gap: 10 },
  quickAction: {
    width: "30%",
    borderRadius: 14,
    borderWidth: 1,
    padding: 14,
    alignItems: "center",
    gap: 6,
  },
  quickActionLabel: { fontSize: 12, fontWeight: "600", textAlign: "center" },
});
