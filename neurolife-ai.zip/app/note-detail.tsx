import { useState, useEffect, useCallback } from "react";
import {
  Alert,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
  Share,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
  ActivityIndicator,
} from "react-native";
import { useLocalSearchParams, useRouter } from "expo-router";
import * as Haptics from "expo-haptics";
import * as FileSystem from "expo-file-system/legacy";
import * as SharingLib from "expo-sharing";
import { useAudioPlayer, setAudioModeAsync } from "expo-audio";

import { ScreenContainer } from "@/components/screen-container";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { useColors } from "@/hooks/use-colors";
import { trpc } from "@/lib/trpc";

// ─── Category Config ──────────────────────────────────────────────────────────

const NOTE_CATEGORIES = {
  note:    { label: "Note",    icon: "📝", color: "#6C63FF" },
  voice:   { label: "Voice",  icon: "🎙️", color: "#F87171" },
  idea:    { label: "Idea",   icon: "💡", color: "#FBBF24" },
  meeting: { label: "Meeting",icon: "👥", color: "#4ECDC4" },
  general: { label: "General",icon: "📌", color: "#9CA3AF" },
} as const;

type NoteCategory = keyof typeof NOTE_CATEGORIES;

// ─── Audio Player Component ───────────────────────────────────────────────────

function AudioPlayer({ audioUrl, colors }: { audioUrl: string; colors: any }) {
  const player = useAudioPlayer(audioUrl);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isReady, setIsReady] = useState(false);

  useEffect(() => {
    setAudioModeAsync({ playsInSilentMode: true }).catch(() => {});
    // Mark ready after a short delay
    const t = setTimeout(() => setIsReady(true), 500);
    return () => {
      clearTimeout(t);
      try { player.pause(); } catch {}
    };
  }, []);

  const handleToggle = useCallback(async () => {
    try {
      if (isPlaying) {
        player.pause();
        setIsPlaying(false);
      } else {
        player.seekTo(0);
        player.play();
        setIsPlaying(true);
        if (Platform.OS !== "web") Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
      }
    } catch (e) {
      console.warn("[AudioPlayer] Error:", e);
    }
  }, [isPlaying, player]);

  return (
    <View style={[styles.audioPlayer, { backgroundColor: colors.error + "15", borderColor: colors.error + "40" }]}>
      <TouchableOpacity
        onPress={handleToggle}
        disabled={!isReady}
        style={[styles.audioPlayBtn, { backgroundColor: colors.error }]}
        hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}
      >
        <IconSymbol name={isPlaying ? "pause.fill" : "play.fill"} size={16} color="#fff" />
      </TouchableOpacity>
      <View style={{ flex: 1 }}>
        <Text style={[styles.audioPlayerLabel, { color: colors.error }]}>Voice Recording</Text>
        <Text style={[styles.audioPlayerSub, { color: colors.muted }]}>
          {isPlaying ? "Playing…" : isReady ? "Tap to play" : "Loading…"}
        </Text>
      </View>
      <IconSymbol name="waveform" size={20} color={colors.error + "80"} />
    </View>
  );
}

// ─── Key Points Display ───────────────────────────────────────────────────────

function KeyPointsList({ content, colors }: { content: string; colors: any }) {
  try {
    const parsed = JSON.parse(content);
    if (parsed.keyPoints || parsed.summary) {
      return (
        <View style={{ gap: 12 }}>
          {parsed.summary ? (
            <View style={[styles.summaryBox, { backgroundColor: colors.primary + "15", borderColor: colors.primary + "40" }]}>
              <Text style={[styles.summaryLabel, { color: colors.primary }]}>Summary</Text>
              <Text style={[styles.summaryText, { color: colors.foreground }]}>{parsed.summary}</Text>
            </View>
          ) : null}
          {parsed.keyPoints?.length > 0 ? (
            <View style={{ gap: 6 }}>
              <Text style={[styles.sectionLabel, { color: colors.muted }]}>Key Points</Text>
              {parsed.keyPoints.map((pt: string, i: number) => (
                <View key={i} style={styles.keyPointRow}>
                  <View style={[styles.keyPointDot, { backgroundColor: colors.primary }]} />
                  <Text style={[styles.keyPointText, { color: colors.foreground }]}>{pt}</Text>
                </View>
              ))}
            </View>
          ) : null}
          {parsed.actionItems?.length > 0 ? (
            <View style={{ gap: 6 }}>
              <Text style={[styles.sectionLabel, { color: colors.muted }]}>Action Items</Text>
              {parsed.actionItems.map((item: string, i: number) => (
                <View key={i} style={styles.keyPointRow}>
                  <View style={[styles.keyPointDot, { backgroundColor: "#4ECDC4" }]} />
                  <Text style={[styles.keyPointText, { color: colors.foreground }]}>{item}</Text>
                </View>
              ))}
            </View>
          ) : null}
          {parsed.nextSteps?.length > 0 ? (
            <View style={{ gap: 6 }}>
              <Text style={[styles.sectionLabel, { color: colors.muted }]}>Next Steps</Text>
              {parsed.nextSteps.map((step: string, i: number) => (
                <View key={i} style={styles.keyPointRow}>
                  <View style={[styles.keyPointDot, { backgroundColor: "#FBBF24" }]} />
                  <Text style={[styles.keyPointText, { color: colors.foreground }]}>{step}</Text>
                </View>
              ))}
            </View>
          ) : null}
          {parsed.attendees?.length > 0 ? (
            <View style={{ gap: 6 }}>
              <Text style={[styles.sectionLabel, { color: colors.muted }]}>Attendees</Text>
              <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 6 }}>
                {parsed.attendees.map((a: string, i: number) => (
                  <View key={i} style={[styles.attendeeBadge, { backgroundColor: "#4ECDC4" + "22" }]}>
                    <Text style={{ fontSize: 13, color: "#4ECDC4", fontWeight: "600" }}>👤 {a}</Text>
                  </View>
                ))}
              </View>
            </View>
          ) : null}
        </View>
      );
    }
  } catch {
    // Not JSON — fall through
  }
  return <Text style={[styles.plainContent, { color: colors.foreground }]}>{content}</Text>;
}

// ─── Main Screen ──────────────────────────────────────────────────────────────

export default function NoteDetailScreen() {
  const colors = useColors();
  const router = useRouter();
  const params = useLocalSearchParams<{ id: string }>();
  const noteId = Number(params.id);

  const [isEditing, setIsEditing] = useState(false);
  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");
  const [tags, setTags] = useState("");
  const [category, setCategory] = useState<NoteCategory>("note");
  const [isDirty, setIsDirty] = useState(false);

  const { data: notes = [], isLoading, refetch } = trpc.notes.list.useQuery({});
  const utils = trpc.useUtils();

  const updateNote = trpc.notes.update.useMutation({
    onMutate: async (updated) => {
      await utils.notes.list.cancel();
      const prev = utils.notes.list.getData({});
      utils.notes.list.setData({} as any, (old: any) =>
        (old ?? []).map((n: any) => n.id === updated.id ? { ...n, ...updated } : n)
      );
      setIsEditing(false);
      setIsDirty(false);
      if (Platform.OS !== "web") Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      return { prev };
    },
    onError: (_err: any, _vars: any, ctx: any) => { if (ctx?.prev) utils.notes.list.setData({} as any, ctx.prev); },
    onSettled: () => utils.notes.list.invalidate(),
  });
  const deleteNote = trpc.notes.delete.useMutation({
    onMutate: async ({ id }) => {
      await utils.notes.list.cancel();
      const prev = utils.notes.list.getData({});
      utils.notes.list.setData({} as any, (old: any) =>
        (old ?? []).filter((n: any) => n.id !== id)
      );
      router.back();
      return { prev };
    },
    onError: (_err: any, _vars: any, ctx: any) => { if (ctx?.prev) utils.notes.list.setData({} as any, ctx.prev); },
    onSettled: () => utils.notes.list.invalidate(),
  });

  const note = notes.find((n: any) => n.id === noteId);

  useEffect(() => {
    if (note) {
      setTitle(note.title ?? "");
      setContent(note.content ?? "");
      setCategory((note.category as NoteCategory) ?? "note");
      const parsedTags = note.tags ? JSON.parse(note.tags) : [];
      setTags(parsedTags.join(", "));
    }
  }, [note]);

  const handleSave = () => {
    if (!title.trim()) return;
    const tagList = tags.split(",").map((t: string) => t.trim()).filter(Boolean);
    updateNote.mutate({ id: noteId, title: title.trim(), content: content.trim() || undefined, category, tags: tagList });
  };

  const handleDelete = () => {
    Alert.alert("Delete Note", "This note will be permanently deleted.", [
      { text: "Cancel", style: "cancel" },
      { text: "Delete", style: "destructive", onPress: () => deleteNote.mutate({ id: noteId }) },
    ]);
  };

  const handleBack = () => {
    if (isDirty) {
      Alert.alert("Unsaved Changes", "You have unsaved changes. Discard them?", [
        { text: "Keep Editing", style: "cancel" },
        { text: "Discard", style: "destructive", onPress: () => router.back() },
      ]);
    } else {
      router.back();
    }
  };

  const handlePin = () => {
    if (!note) return;
    updateNote.mutate({ id: noteId, pinned: !note.pinned });
    if (Platform.OS !== "web") Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
  };

  const handleShare = async () => {
    if (!note) return;
    try {
      // Build plain-text export
      let shareText = `📝 ${note.title}\n`;
      shareText += `Category: ${NOTE_CATEGORIES[note.category as NoteCategory]?.label ?? note.category}\n`;
      shareText += `Date: ${new Date(note.createdAt).toLocaleDateString("en-US", { weekday: "short", month: "long", day: "numeric", year: "numeric" })}\n\n`;
      if (note.transcription) shareText += `Transcript:\n${note.transcription}\n\n`;
      if (note.content) {
        try {
          const parsed = JSON.parse(note.content);
          if (parsed.summary) shareText += `Summary:\n${parsed.summary}\n\n`;
          if (parsed.keyPoints?.length) shareText += `Key Points:\n${parsed.keyPoints.map((p: string) => `• ${p}`).join("\n")}\n\n`;
          if (parsed.actionItems?.length) shareText += `Action Items:\n${parsed.actionItems.map((a: string) => `☐ ${a}`).join("\n")}\n\n`;
          if (parsed.nextSteps?.length) shareText += `Next Steps:\n${parsed.nextSteps.map((s: string) => `→ ${s}`).join("\n")}\n\n`;
        } catch {
          shareText += `${note.content}\n\n`;
        }
      }
      const parsedTags: string[] = note.tags ? JSON.parse(note.tags) : [];
      if (parsedTags.length) shareText += `Tags: ${parsedTags.map((t: string) => `#${t}`).join(" ")}\n`;
      shareText += `\n— Shared from NeuroLife AI`;

      if (Platform.OS === "web") {
        // On web, use React Native's built-in Share
        await Share.share({ message: shareText, title: note.title });
      } else {
        // On native: write to a temp file and share it
        const fileUri = FileSystem.cacheDirectory + `note-${noteId}.txt`;
        await FileSystem.writeAsStringAsync(fileUri, shareText, { encoding: FileSystem.EncodingType.UTF8 });
        const available = await SharingLib.isAvailableAsync();
        if (available) {
          await SharingLib.shareAsync(fileUri, { mimeType: "text/plain", dialogTitle: `Share: ${note.title}` });
        } else {
          await Share.share({ message: shareText, title: note.title });
        }
      }
      if (Platform.OS !== "web") Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    } catch (e: any) {
      if (e?.message !== "User did not share") {
        Alert.alert("Share Failed", "Could not share this note.");
      }
    }
  };

  if (isLoading) {
    return (
      <ScreenContainer>
        <View style={{ flex: 1, alignItems: "center", justifyContent: "center" }}>
          <ActivityIndicator color={colors.primary} />
        </View>
      </ScreenContainer>
    );
  }

  if (!note) {
    return (
      <ScreenContainer>
        <View style={{ flex: 1, alignItems: "center", justifyContent: "center", gap: 8 }}>
          <Text style={{ fontSize: 48 }}>🔍</Text>
          <Text style={[styles.emptyTitle, { color: colors.foreground }]}>Note not found</Text>
          <TouchableOpacity onPress={() => router.back()} style={[styles.backBtn, { backgroundColor: colors.primary }]}>
            <Text style={{ color: "#fff", fontWeight: "600" }}>Go Back</Text>
          </TouchableOpacity>
        </View>
      </ScreenContainer>
    );
  }

  const cfg = NOTE_CATEGORIES[note.category as NoteCategory] ?? NOTE_CATEGORIES.note;
  const parsedTags: string[] = note.tags ? JSON.parse(note.tags) : [];

  return (
    <ScreenContainer containerClassName="bg-background">
      <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === "ios" ? "padding" : "height"}>
        {/* Top Bar */}
        <View style={[styles.topBar, { borderBottomColor: colors.border }]}>
          <TouchableOpacity onPress={handleBack} style={styles.topBarBtn} hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}>
            <IconSymbol name="chevron.left" size={22} color={colors.primary} />
            <Text style={[styles.topBarBtnText, { color: colors.primary }]}>Memory</Text>
          </TouchableOpacity>

          <View style={{ flexDirection: "row", gap: 8, alignItems: "center" }}>
            {!isEditing && (
              <>
                {/* Pin button */}
                <TouchableOpacity
                  onPress={handlePin}
                  style={[styles.iconBtn, { backgroundColor: note.pinned ? "#FBBF24" + "30" : colors.surface }]}
                  hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}
                >
                  <IconSymbol name="pin.fill" size={16} color={note.pinned ? "#FBBF24" : colors.muted} />
                </TouchableOpacity>
                {/* Share button */}
                <TouchableOpacity
                  onPress={handleShare}
                  style={[styles.iconBtn, { backgroundColor: colors.surface }]}
                  hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}
                >
                  <IconSymbol name="square.and.arrow.up" size={16} color={colors.primary} />
                </TouchableOpacity>
              </>
            )}

            {isEditing ? (
              <>
                <TouchableOpacity
                  onPress={() => { setIsEditing(false); setIsDirty(false); }}
                  style={[styles.topBarAction, { backgroundColor: colors.surface }]}
                >
                  <Text style={[styles.topBarActionText, { color: colors.muted }]}>Cancel</Text>
                </TouchableOpacity>
                <TouchableOpacity
                  onPress={handleSave}
                  style={[styles.topBarAction, { backgroundColor: colors.primary }]}
                  disabled={updateNote.isPending}
                >
                  {updateNote.isPending ? (
                    <ActivityIndicator size="small" color="#fff" />
                  ) : (
                    <Text style={[styles.topBarActionText, { color: "#fff" }]}>Save</Text>
                  )}
                </TouchableOpacity>
              </>
            ) : (
              <>
                <TouchableOpacity
                  onPress={() => setIsEditing(true)}
                  style={[styles.topBarAction, { backgroundColor: colors.primary + "20" }]}
                >
                  <IconSymbol name="pencil" size={16} color={colors.primary} />
                  <Text style={[styles.topBarActionText, { color: colors.primary }]}>Edit</Text>
                </TouchableOpacity>
                <TouchableOpacity
                  onPress={handleDelete}
                  style={[styles.topBarAction, { backgroundColor: colors.error + "20" }]}
                >
                  <IconSymbol name="trash" size={16} color={colors.error} />
                </TouchableOpacity>
              </>
            )}
          </View>
        </View>

        <ScrollView
          style={{ flex: 1 }}
          contentContainerStyle={styles.scrollContent}
          keyboardShouldPersistTaps="handled"
          showsVerticalScrollIndicator={false}
        >
          {isEditing ? (
            // ─── Edit Mode ──────────────────────────────────────────────────
            <View style={{ gap: 12 }}>
              <Text style={[styles.fieldLabel, { color: colors.muted }]}>Title</Text>
              <TextInput
                style={[styles.titleInput, { color: colors.foreground, borderColor: colors.border, backgroundColor: colors.surface }]}
                value={title}
                onChangeText={(v) => { setTitle(v); setIsDirty(true); }}
                placeholder="Note title..."
                placeholderTextColor={colors.muted}
                autoFocus
              />

              <Text style={[styles.fieldLabel, { color: colors.muted }]}>Category</Text>
              <ScrollView horizontal showsHorizontalScrollIndicator={false}>
                <View style={{ flexDirection: "row", gap: 8, paddingBottom: 4 }}>
                  {(Object.entries(NOTE_CATEGORIES) as [NoteCategory, typeof NOTE_CATEGORIES[NoteCategory]][]).map(([key, c]) => (
                    <TouchableOpacity
                      key={key}
                      style={[styles.catChip, {
                        backgroundColor: category === key ? c.color : c.color + "22",
                        borderColor: c.color,
                      }]}
                      onPress={() => { setCategory(key); setIsDirty(true); }}
                    >
                      <Text style={{ fontSize: 14 }}>{c.icon}</Text>
                      <Text style={[styles.catChipText, { color: category === key ? "#fff" : c.color }]}>{c.label}</Text>
                    </TouchableOpacity>
                  ))}
                </View>
              </ScrollView>

              <Text style={[styles.fieldLabel, { color: colors.muted }]}>Content</Text>
              <TextInput
                style={[styles.contentInput, { color: colors.foreground, borderColor: colors.border, backgroundColor: colors.surface }]}
                value={content}
                onChangeText={(v) => { setContent(v); setIsDirty(true); }}
                placeholder="Write your note here..."
                placeholderTextColor={colors.muted}
                multiline
                textAlignVertical="top"
              />

              <Text style={[styles.fieldLabel, { color: colors.muted }]}>Tags (comma-separated)</Text>
              <TextInput
                style={[styles.tagsInput, { color: colors.foreground, borderColor: colors.border, backgroundColor: colors.surface }]}
                value={tags}
                onChangeText={(v) => { setTags(v); setIsDirty(true); }}
                placeholder="work, personal, important..."
                placeholderTextColor={colors.muted}
                returnKeyType="done"
              />
            </View>
          ) : (
            // ─── View Mode ──────────────────────────────────────────────────
            <View style={{ gap: 16 }}>
              {/* Category badge + pin indicator + date */}
              <View style={styles.metaRow}>
                <View style={{ flexDirection: "row", alignItems: "center", gap: 8 }}>
                  <View style={[styles.categoryBadge, { backgroundColor: cfg.color + "22" }]}>
                    <Text style={{ fontSize: 14 }}>{cfg.icon}</Text>
                    <Text style={[styles.categoryBadgeText, { color: cfg.color }]}>{cfg.label}</Text>
                  </View>
                  {note.pinned ? (
                    <View style={[styles.pinnedBadge, { backgroundColor: "#FBBF24" + "22" }]}>
                      <IconSymbol name="pin.fill" size={11} color="#FBBF24" />
                      <Text style={{ fontSize: 11, color: "#FBBF24", fontWeight: "700" }}>Pinned</Text>
                    </View>
                  ) : null}
                </View>
                <Text style={[styles.dateText, { color: colors.muted }]}>
                  {new Date(note.createdAt).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" })}
                </Text>
              </View>

              {/* Title */}
              <Text style={[styles.noteTitle, { color: colors.foreground }]}>{note.title}</Text>

              {/* Tags */}
              {parsedTags.length > 0 ? (
                <View style={styles.tagsRow}>
                  {parsedTags.map((tag: string) => (
                    <View key={tag} style={[styles.tag, { backgroundColor: colors.primary + "20" }]}>
                      <Text style={[styles.tagText, { color: colors.primary }]}>#{tag}</Text>
                    </View>
                  ))}
                </View>
              ) : null}

              {/* Audio Playback — shown when audioUrl is present */}
              {note.audioUrl ? (
                <AudioPlayer audioUrl={note.audioUrl} colors={colors} />
              ) : null}

              {/* Transcription (for voice notes) */}
              {note.transcription ? (
                <View style={[styles.transcriptionBox, { backgroundColor: colors.surface, borderColor: colors.border }]}>
                  <View style={styles.transcriptionHeader}>
                    <IconSymbol name="waveform" size={16} color={colors.primary} />
                    <Text style={[styles.transcriptionLabel, { color: colors.primary }]}>Voice Transcript</Text>
                  </View>
                  <Text style={[styles.transcriptionText, { color: colors.muted }]}>{note.transcription}</Text>
                </View>
              ) : null}

              {/* Content — smart key points or plain text */}
              {note.content ? (
                <View style={[styles.contentBox, { backgroundColor: colors.surface, borderColor: colors.border }]}>
                  <KeyPointsList content={note.content} colors={colors} />
                </View>
              ) : (
                <View style={[styles.contentBox, { backgroundColor: colors.surface, borderColor: colors.border }]}>
                  <Text style={[styles.emptyContent, { color: colors.muted }]}>No content. Tap Edit to add notes.</Text>
                </View>
              )}
            </View>
          )}
        </ScrollView>
      </KeyboardAvoidingView>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  topBar: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", paddingHorizontal: 16, paddingVertical: 12, borderBottomWidth: 0.5 },
  topBarBtn: { flexDirection: "row", alignItems: "center", gap: 4 },
  topBarBtnText: { fontSize: 16, fontWeight: "500" },
  topBarAction: { flexDirection: "row", alignItems: "center", paddingHorizontal: 12, paddingVertical: 7, borderRadius: 10, gap: 4 },
  topBarActionText: { fontSize: 14, fontWeight: "600" },
  iconBtn: { width: 34, height: 34, borderRadius: 10, alignItems: "center", justifyContent: "center" },
  scrollContent: { padding: 20, paddingBottom: 60 },
  metaRow: { flexDirection: "row", justifyContent: "space-between", alignItems: "center" },
  categoryBadge: { flexDirection: "row", alignItems: "center", paddingHorizontal: 10, paddingVertical: 4, borderRadius: 12, gap: 5 },
  categoryBadgeText: { fontSize: 12, fontWeight: "700" },
  pinnedBadge: { flexDirection: "row", alignItems: "center", paddingHorizontal: 8, paddingVertical: 4, borderRadius: 10, gap: 4 },
  dateText: { fontSize: 13 },
  noteTitle: { fontSize: 26, fontWeight: "800", lineHeight: 34 },
  tagsRow: { flexDirection: "row", flexWrap: "wrap", gap: 6 },
  tag: { paddingHorizontal: 10, paddingVertical: 4, borderRadius: 10 },
  tagText: { fontSize: 12, fontWeight: "600" },
  // Audio player
  audioPlayer: { flexDirection: "row", alignItems: "center", gap: 12, borderRadius: 14, borderWidth: 1, padding: 14 },
  audioPlayBtn: { width: 38, height: 38, borderRadius: 19, alignItems: "center", justifyContent: "center" },
  audioPlayerLabel: { fontSize: 13, fontWeight: "700" },
  audioPlayerSub: { fontSize: 12, marginTop: 2 },
  // Transcription
  transcriptionBox: { borderRadius: 14, borderWidth: 1, padding: 14, gap: 8 },
  transcriptionHeader: { flexDirection: "row", alignItems: "center", gap: 6 },
  transcriptionLabel: { fontSize: 13, fontWeight: "700" },
  transcriptionText: { fontSize: 14, lineHeight: 21 },
  contentBox: { borderRadius: 14, borderWidth: 1, padding: 16 },
  plainContent: { fontSize: 16, lineHeight: 26 },
  emptyContent: { fontSize: 15, fontStyle: "italic" },
  // Key points
  summaryBox: { borderRadius: 12, borderWidth: 1, padding: 14, gap: 4 },
  summaryLabel: { fontSize: 12, fontWeight: "700", textTransform: "uppercase", letterSpacing: 0.5 },
  summaryText: { fontSize: 15, lineHeight: 22 },
  sectionLabel: { fontSize: 12, fontWeight: "700", textTransform: "uppercase", letterSpacing: 0.5 },
  keyPointRow: { flexDirection: "row", alignItems: "flex-start", gap: 10 },
  keyPointDot: { width: 7, height: 7, borderRadius: 4, marginTop: 7 },
  keyPointText: { flex: 1, fontSize: 15, lineHeight: 22 },
  attendeeBadge: { paddingHorizontal: 10, paddingVertical: 5, borderRadius: 10 },
  // Edit mode
  fieldLabel: { fontSize: 13, fontWeight: "600" },
  titleInput: { borderRadius: 12, borderWidth: 1, padding: 14, fontSize: 18, fontWeight: "700" },
  contentInput: { borderRadius: 12, borderWidth: 1, padding: 14, fontSize: 15, minHeight: 180, lineHeight: 22 },
  tagsInput: { borderRadius: 12, borderWidth: 1, padding: 14, fontSize: 15 },
  catChip: { flexDirection: "row", alignItems: "center", paddingHorizontal: 12, paddingVertical: 7, borderRadius: 14, borderWidth: 1, gap: 5 },
  catChipText: { fontSize: 13, fontWeight: "600" },
  emptyTitle: { fontSize: 18, fontWeight: "600" },
  backBtn: { paddingHorizontal: 20, paddingVertical: 10, borderRadius: 12, marginTop: 8 },
});
