/**
 * NativeAdCard — AdMob Native Advanced Ad
 *
 * Implements the Google Mobile Ads SDK Native Advanced Ad format.
 * Default Ad Unit IDs (overridden per-placement via adUnitId prop):
 *  - Android default: ca-app-pub-1720679341163644/8844075255
 *  - iOS default: (set per-placement via adUnitId prop)
 *
 * AdMob Policy compliance:
 *  - "Ad" label is always shown (required by AdMob policy)
 *  - Ad styling is clearly distinguishable from app content
 *  - No deceptive placement or misleading UI
 *  - Native-only guard: renders nothing on web
 *  - Ad is destroyed on unmount to prevent memory leaks
 *  - Loads a new ad on mount; shows skeleton while loading
 *
 * Native Advanced ads allow full custom rendering using NativeAdView,
 * NativeAsset, and NativeMediaView from react-native-google-mobile-ads.
 */

import React, { useEffect, useState, useCallback, useImperativeHandle, forwardRef } from 'react';
import {
  View,
  Text,
  Image,
  StyleSheet,
  Platform,
  TouchableOpacity,
  ActivityIndicator,
} from 'react-native';
import { useColors } from '@/hooks/use-colors';

// ─── Native module guard ──────────────────────────────────────────────────────
// The SDK is stubbed to an empty module on web via metro.config.js.
let NativeAd: any = null;
let NativeAdView: any = null;
let NativeAsset: any = null;
let NativeAssetType: any = null;
let NativeMediaView: any = null;

// Load on Android and iOS — not on web.
if (Platform.OS === 'android' || Platform.OS === 'ios') {
  try {
    const module = require('react-native-google-mobile-ads');
    NativeAd = module.NativeAd;
    NativeAdView = module.NativeAdView;
    NativeAsset = module.NativeAsset;
    NativeAssetType = module.NativeAssetType;
    NativeMediaView = module.NativeMediaView;
  } catch (e) {
    console.warn('[NativeAd] Failed to load react-native-google-mobile-ads:', e);
  }
}

// ─── Constants ────────────────────────────────────────────────────────────────
const NATIVE_AD_UNIT_ID = 'ca-app-pub-1720679341163644/8844075255';

// ─── Skeleton loader shown while ad is loading ───────────────────────────────
function AdSkeleton({ colors }: { colors: any }) {
  return (
    <View style={[styles.container, { backgroundColor: colors.surface, borderColor: colors.border }]}>
      <View style={[styles.adLabel, { backgroundColor: colors.warning + '22', borderColor: colors.warning + '44' }]}>
        <Text style={[styles.adLabelText, { color: colors.warning }]}>Ad</Text>
      </View>
      <View style={styles.skeletonRow}>
        <View style={[styles.skeletonIcon, { backgroundColor: colors.border }]} />
        <View style={{ flex: 1, gap: 6 }}>
          <View style={[styles.skeletonLine, { width: '70%', backgroundColor: colors.border }]} />
          <View style={[styles.skeletonLine, { width: '90%', backgroundColor: colors.border }]} />
        </View>
      </View>
      <View style={[styles.skeletonLine, { width: '100%', height: 10, backgroundColor: colors.border, marginTop: 8 }]} />
      <ActivityIndicator size="small" color={colors.muted} style={{ marginTop: 10 }} />
    </View>
  );
}

// ─── Ref handle type (exported so Home screen can type the ref) ──────────────
export type NativeAdCardHandle = {
  /** Destroy the current ad and load a fresh one */
  refresh: () => void;
};

// ─── Props ───────────────────────────────────────────────────────────────────
export type NativeAdCardProps = {
  /** Override the default ad unit ID for this placement */
  adUnitId?: string;
};

// ─── Main component ───────────────────────────────────────────────────────────
export const NativeAdCard = forwardRef<NativeAdCardHandle, NativeAdCardProps>(function NativeAdCard({ adUnitId }, ref) {
  const colors = useColors();
  const [nativeAd, setNativeAd] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [hasError, setHasError] = useState(false);

  const loadAd = useCallback(async () => {
    if (Platform.OS === 'web' || !NativeAd) return;

    try {
      setIsLoading(true);
      setHasError(false);

      // Destroy previous ad instance to free memory
      if (nativeAd) {
        try { nativeAd.destroy(); } catch (_) {}
      }

      const ad = await NativeAd.createForAdRequest(adUnitId ?? NATIVE_AD_UNIT_ID, {
        keywords: ['productivity', 'task management', 'organizer', 'planner', 'calendar', 'app'],
        requestNonPersonalizedAdsOnly: false,
      });

      setNativeAd(ad);
      setIsLoading(false);
    } catch (e: any) {
      console.warn('[NativeAd] Failed to load ad:', e?.message ?? e);
      setHasError(true);
      setIsLoading(false);
    }
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  // Expose refresh() to parent via ref
  useImperativeHandle(ref, () => ({
    refresh: () => {
      console.log('[NativeAd] Refreshing ad via pull-to-refresh');
      loadAd();
    },
  }), [loadAd]);

  useEffect(() => {
    loadAd();
    return () => {
      // Destroy ad on unmount to prevent memory leaks
      if (nativeAd) {
        try { nativeAd.destroy(); } catch (_) {}
      }
    };
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  // Only render on native (Android + iOS) — not on web
  if (Platform.OS === 'web') return null;

  // Show skeleton while loading
  if (isLoading) return <AdSkeleton colors={colors} />;

  // Don't render if ad failed or not available
  if (hasError || !nativeAd || !NativeAdView || !NativeAsset || !NativeAssetType) return null;

  const iconUri = nativeAd.icon?.url;

  return (
    <NativeAdView nativeAd={nativeAd} style={[styles.container, { backgroundColor: colors.surface, borderColor: colors.border }]}>
      {/* ── AdMob required "Ad" label (policy compliance) ── */}
      <View style={[styles.adLabel, { backgroundColor: colors.warning + '22', borderColor: colors.warning + '44' }]}>
        <Text style={[styles.adLabelText, { color: colors.warning }]}>Ad</Text>
      </View>

      {/* ── Header row: icon + headline + advertiser ── */}
      <View style={styles.headerRow}>
        {iconUri ? (
          <NativeAsset assetType={NativeAssetType.ICON}>
            <Image
              source={{ uri: iconUri }}
              style={styles.icon}
              resizeMode="cover"
            />
          </NativeAsset>
        ) : (
          <View style={[styles.iconPlaceholder, { backgroundColor: colors.primary + '22' }]}>
            <Text style={{ fontSize: 18 }}>📢</Text>
          </View>
        )}

        <View style={styles.headerText}>
          <NativeAsset assetType={NativeAssetType.HEADLINE}>
            <Text
              style={[styles.headline, { color: colors.foreground }]}
              numberOfLines={2}
            >
              {nativeAd.headline}
            </Text>
          </NativeAsset>

          {nativeAd.advertiser ? (
            <NativeAsset assetType={NativeAssetType.ADVERTISER}>
              <Text style={[styles.advertiser, { color: colors.muted }]} numberOfLines={1}>
                {nativeAd.advertiser}
              </Text>
            </NativeAsset>
          ) : null}
        </View>
      </View>

      {/* ── Body text ── */}
      {nativeAd.body ? (
        <NativeAsset assetType={NativeAssetType.BODY}>
          <Text style={[styles.body, { color: colors.muted }]} numberOfLines={3}>
            {nativeAd.body}
          </Text>
        </NativeAsset>
      ) : null}

      {/* ── Media (image/video) — only shown if ad has media content ── */}
      {nativeAd.mediaContent ? (
        <NativeMediaView
          style={styles.media}
          resizeMode="cover"
        />
      ) : null}

      {/* ── Call to action button ── */}
      {nativeAd.callToAction ? (
        <NativeAsset assetType={NativeAssetType.CALL_TO_ACTION}>
          <TouchableOpacity
            style={[styles.ctaButton, { backgroundColor: colors.primary }]}
            activeOpacity={0.8}
          >
            <Text style={styles.ctaText}>{nativeAd.callToAction}</Text>
          </TouchableOpacity>
        </NativeAsset>
      ) : null}
    </NativeAdView>
  );
});
// ─── Styless ───────────────────────────────────────────────────────────────────
const styles = StyleSheet.create({
  container: {
    borderRadius: 16,
    borderWidth: 1,
    padding: 14,
    gap: 10,
    marginTop: 4,
  },
  adLabel: {
    alignSelf: 'flex-start',
    paddingHorizontal: 7,
    paddingVertical: 2,
    borderRadius: 6,
    borderWidth: 1,
  },
  adLabelText: {
    fontSize: 10,
    fontWeight: '700',
    letterSpacing: 0.5,
  },
  headerRow: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 10,
  },
  icon: {
    width: 44,
    height: 44,
    borderRadius: 10,
    flexShrink: 0,
  },
  iconPlaceholder: {
    width: 44,
    height: 44,
    borderRadius: 10,
    alignItems: 'center',
    justifyContent: 'center',
    flexShrink: 0,
  },
  headerText: {
    flex: 1,
    gap: 2,
  },
  headline: {
    fontSize: 15,
    fontWeight: '700',
    lineHeight: 20,
  },
  advertiser: {
    fontSize: 12,
    fontWeight: '500',
  },
  body: {
    fontSize: 13,
    lineHeight: 19,
  },
  media: {
    width: '100%',
    borderRadius: 10,
    overflow: 'hidden',
    backgroundColor: '#00000010',
  },
  ctaButton: {
    alignSelf: 'flex-start',
    paddingHorizontal: 18,
    paddingVertical: 9,
    borderRadius: 20,
    marginTop: 2,
  },
  ctaText: {
    color: '#fff',
    fontSize: 13,
    fontWeight: '700',
    letterSpacing: 0.2,
  },
  // Skeleton
  skeletonRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  skeletonIcon: {
    width: 44,
    height: 44,
    borderRadius: 10,
  },
  skeletonLine: {
    height: 12,
    borderRadius: 6,
  },
});
