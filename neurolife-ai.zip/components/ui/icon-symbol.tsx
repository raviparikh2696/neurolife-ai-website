// Fallback for using MaterialIcons on Android and web.

import MaterialIcons from "@expo/vector-icons/MaterialIcons";
import { SymbolWeight, SymbolViewProps } from "expo-symbols";
import { ComponentProps } from "react";
import { OpaqueColorValue, type StyleProp, type TextStyle } from "react-native";

type IconMapping = Partial<Record<SymbolViewProps["name"], ComponentProps<typeof MaterialIcons>["name"]>>;
type IconSymbolName = keyof typeof MAPPING;

/**
 * SF Symbols → Material Icons mapping for NeuroLife AI
 */
const MAPPING = {
  // Navigation
  "house.fill":                              "home",
  "checkmark.circle.fill":                   "check-circle",
  "calendar":                                "calendar-today",
  "cart.fill":                               "shopping-cart",
  "brain.head.profile":                      "psychology",
  "sparkles":                                "auto-awesome",
  "gearshape.fill":                          "settings",
  // Common actions
  "paperplane.fill":                         "send",
  "plus":                                    "add",
  "plus.circle.fill":                        "add-circle",
  "mic.fill":                                "mic",
  "mic":                                     "mic-none",
  "magnifyingglass":                         "search",
  "xmark":                                   "close",
  "xmark.circle.fill":                       "cancel",
  "chevron.right":                           "chevron-right",
  "chevron.left":                            "chevron-left",
  "chevron.down":                            "expand-more",
  "chevron.up":                              "expand-less",
  "chevron.left.forwardslash.chevron.right": "code",
  "ellipsis":                                "more-horiz",
  "ellipsis.circle":                         "more-horiz",
  "trash.fill":                              "delete",
  "trash":                                   "delete-outline",
  "pencil":                                  "edit",
  "square.and.pencil":                       "edit-note",
  "arrow.left":                              "arrow-back",
  "arrow.uturn.backward":                     "undo",
  "pin.fill":                                 "push-pin",
  "pin":                                      "push-pin",
  "mic.slash.fill":                           "mic-off",
  "speaker.wave.2.fill":                      "volume-up",
  "photo":                                    "photo",
  "camera.fill":                              "camera-alt",
  "doc.fill":                                 "insert-drive-file",
  "folder.fill":                              "folder",
  "link":                                     "link",
  "lock.fill":                                "lock",
  "eye.fill":                                 "visibility",
  "eye.slash.fill":                           "visibility-off",
  "hand.thumbsup.fill":                       "thumb-up",
  "heart.fill":                               "favorite",
  "location.fill":                            "location-on",
  "map.fill":                                 "map",
  "phone.fill":                               "phone",
  "envelope.fill":                            "email",
  "globe":                                    "language",
  "questionmark.circle":                      "help-outline",
  "exclamationmark.triangle.fill":            "warning",
  "checkmark.seal.fill":                      "verified",
  "arrow.triangle.2.circlepath":              "sync",
  "cloud.fill":                               "cloud",
  "cloud.upload.fill":                        "cloud-upload",
  "cloud.download.fill":                      "cloud-download",
  "tray.fill":                                "inbox",
  "archivebox.fill":                          "archive",
  "list.bullet":                              "list",
  "list.bullet.rectangle":                    "view-list",
  "square.grid.2x2.fill":                     "grid-view",
  "person.crop.circle.fill":                  "account-circle",
  "person.badge.plus.fill":                   "person-add",
  "chart.bar.fill":                           "bar-chart",
  "chart.pie.fill":                           "pie-chart",
  "number":                                   "tag",
  "text.quote":                               "format-quote",
  "text.alignleft":                           "format-align-left",
  "bold":                                     "format-bold",
  "italic":                                   "format-italic",
  "underline":                                "format-underlined",
  "paintbrush.fill":                          "brush",
  "scissors":                                 "content-cut",
  "doc.on.doc.fill":                          "content-copy",
  "arrow.up.circle.fill":                     "arrow-upward",
  "arrow.down.circle":                        "arrow-downward",
  "minus.circle.fill":                        "remove-circle",
  "multiply.circle.fill":                     "cancel",
  "power":                                    "power-settings-new",
  "bell.badge.fill":                          "notification-important",
  "arrow.right":                             "arrow-forward",
  "arrow.clockwise":                         "refresh",
  // Task / Priority
  "flag.fill":                               "flag",
  "flag":                                    "outlined-flag",
  "exclamationmark.circle.fill":             "error",
  "checkmark":                               "check",
  "circle":                                  "radio-button-unchecked",
  "checkmark.circle":                        "check-circle-outline",
  // Calendar / Time
  "clock.fill":                              "schedule",
  "clock":                                   "access-time",
  "bell.fill":                               "notifications",
  "bell":                                    "notifications-none",
  "bell.slash.fill":                         "notifications-off",
  "alarm.fill":                              "alarm",
  // Notes / Memory
  "note.text":                               "article",
  "doc.text.fill":                           "description",
  "lightbulb.fill":                          "lightbulb",
  "lightbulb":                               "lightbulb-outline",
  "tag.fill":                                "label",
  "bookmark.fill":                           "bookmark",
  "bookmark":                                "bookmark-border",
  // Voice / Audio
  "waveform":                                "graphic-eq",
  "stop.fill":                               "stop",
  "play.fill":                               "play-arrow",
  "pause.fill":                              "pause",
  "record.circle.fill":                      "fiber-manual-record",
  // Grocery
  "basket.fill":                             "local-grocery-store",
  "leaf.fill":                               "eco",
  // Meeting
  "person.2.fill":                           "people",
  "person.fill":                             "person",
  "video.fill":                              "videocam",
  // Misc
  "info.circle":                             "info",
  "info.circle.fill":                        "info",
  "star.fill":                               "star",
  "moon.fill":                               "dark-mode",
  "sun.max.fill":                            "light-mode",
  "iphone":                                  "smartphone",
  "square.and.arrow.up":                     "ios-share",
  "arrow.down.circle.fill":                  "download",
  "wifi":                                    "wifi",
  "wifi.slash":                              "wifi-off",
} as IconMapping;

/**
 * An icon component that uses native SF Symbols on iOS, and Material Icons on Android and web.
 */
export function IconSymbol({
  name,
  size = 24,
  color,
  style,
}: {
  name: IconSymbolName;
  size?: number;
  color: string | OpaqueColorValue;
  style?: StyleProp<TextStyle>;
  weight?: SymbolWeight;
}) {
  return <MaterialIcons color={color} size={size} name={MAPPING[name]} style={style} />;
}
