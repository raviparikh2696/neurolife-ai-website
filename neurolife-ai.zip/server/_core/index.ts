import "dotenv/config";
import express from "express";
import { createServer } from "http";
import net from "net";
import { createExpressMiddleware } from "@trpc/server/adapters/express";
import { registerOAuthRoutes } from "./oauth";
import { appRouter } from "../routers";
import { createContext } from "./context";

function isPortAvailable(port: number): Promise<boolean> {
  return new Promise((resolve) => {
    const server = net.createServer();
    server.listen(port, () => {
      server.close(() => resolve(true));
    });
    server.on("error", () => resolve(false));
  });
}

async function findAvailablePort(startPort: number = 3000): Promise<number> {
  for (let port = startPort; port < startPort + 20; port++) {
    if (await isPortAvailable(port)) {
      return port;
    }
  }
  throw new Error(`No available port found starting from ${startPort}`);
}

async function startServer() {
  const app = express();
  const server = createServer(app);

  // Enable CORS for all routes - reflect the request origin to support credentials
  app.use((req, res, next) => {
    const origin = req.headers.origin;
    if (origin) {
      res.header("Access-Control-Allow-Origin", origin);
    }
    res.header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS");
    res.header(
      "Access-Control-Allow-Headers",
      "Origin, X-Requested-With, Content-Type, Accept, Authorization",
    );
    res.header("Access-Control-Allow-Credentials", "true");

    // Handle preflight requests
    if (req.method === "OPTIONS") {
      res.sendStatus(200);
      return;
    }
    next();
  });

  app.use(express.json({ limit: "50mb" }));
  app.use(express.urlencoded({ limit: "50mb", extended: true }));

  registerOAuthRoutes(app);

  app.get("/api/health", (_req, res) => {
    res.json({ ok: true, timestamp: Date.now() });
  });

  // Streaming AI chat endpoint (SSE) — bypasses tRPC for real-time word-by-word responses
  app.post("/api/ai/stream-chat", async (req, res) => {
    try {
      const { sdk } = await import("./sdk");
      const user = await sdk.authenticateRequest(req).catch(() => null);
      if (!user) { res.status(401).json({ error: "Unauthorized" }); return; }

      const { message, history, tzOffset } = req.body as {
        message: string;
        history?: { role: string; content: string }[];
        tzOffset?: number;
      };
      if (!message) { res.status(400).json({ error: "message required" }); return; }

      const { getUserTasks, getUserEvents, getUserGroceries, getUserNotes, saveChatMessage } = await import("../db");
      const [userTasks, userEvents, userGroceries, userNotes] = await Promise.all([
        getUserTasks(user.id, false),
        getUserEvents(user.id, new Date(), new Date(Date.now() + 7 * 24 * 60 * 60 * 1000)),
        getUserGroceries(user.id),
        getUserNotes(user.id),
      ]);

      // Build local date string using user's timezone offset
      const offsetMin = tzOffset ?? 0;
      const localMs = Date.now() - offsetMin * 60 * 1000;
      const localDate = new Date(localMs);
      const pad = (n: number) => String(n).padStart(2, "0");
      const localDateStr = `${localDate.getUTCFullYear()}-${pad(localDate.getUTCMonth()+1)}-${pad(localDate.getUTCDate())} ${pad(localDate.getUTCHours())}:${pad(localDate.getUTCMinutes())}`;

      const ctxSummary = [
        `Today: ${localDateStr}`,
        `Pending Tasks: ${userTasks.slice(0,5).map((t: any) => `"${t.title}" (${t.priority})`).join(", ") || "none"}`,
        `Upcoming Events: ${userEvents.slice(0,5).map((e: any) => `"${e.title}" at ${e.startTime.toISOString()}`).join(", ") || "none"}`,
        `Groceries: ${userGroceries.filter((g: any) => !g.purchased).slice(0,10).map((g: any) => g.name).join(", ") || "none"}`,
        `Notes: ${userNotes.slice(0,3).map((n: any) => `"${n.title}"`).join(", ") || "none"}`,
      ].join("\n");

      const messages: { role: "system" | "user" | "assistant"; content: string }[] = [
        { role: "system", content: `You are NeuroLife AI, a personal life organizer. User data:\n${ctxSummary}\nAnswer concisely and helpfully.` },
        ...((history ?? []) as { role: "user" | "assistant"; content: string }[]),
        { role: "user", content: message },
      ];

      const { invokeLLM } = await import("./llm");
      const streamResponse = await invokeLLM({ messages, stream: true }) as unknown as Response;

      // SSE headers
      res.setHeader("Content-Type", "text/event-stream");
      res.setHeader("Cache-Control", "no-cache");
      res.setHeader("Connection", "keep-alive");
      res.flushHeaders();

      let fullText = "";
      const reader = (streamResponse.body as any).getReader();
      const decoder = new TextDecoder();

      try {
        while (true) {
          const { done, value } = await reader.read();
          if (done) break;
          const chunk = decoder.decode(value, { stream: true });
          for (const line of chunk.split("\n")) {
            if (!line.startsWith("data: ")) continue;
            const data = line.slice(6).trim();
            if (data === "[DONE]") continue;
            try {
              const parsed = JSON.parse(data);
              const delta: string = parsed?.choices?.[0]?.delta?.content ?? "";
              if (delta) {
                fullText += delta;
                res.write(`data: ${JSON.stringify({ delta })}\n\n`);
              }
            } catch { /* skip malformed chunks */ }
          }
        }
      } finally {
        reader.releaseLock();
      }

      // Save full conversation after stream completes
      await saveChatMessage({ userId: user.id, role: "user", content: message });
      await saveChatMessage({ userId: user.id, role: "assistant", content: fullText });
      res.write(`data: ${JSON.stringify({ done: true })}\n\n`);
      res.end();
    } catch (err: any) {
      console.error("[stream-chat] error:", err);
      if (!res.headersSent) res.status(500).json({ error: err.message });
      else res.end();
    }
  });

  app.use(
    "/api/trpc",
    createExpressMiddleware({
      router: appRouter,
      createContext,
    }),
  );

  const preferredPort = parseInt(process.env.PORT || "3000");
  const port = await findAvailablePort(preferredPort);

  if (port !== preferredPort) {
    console.log(`Port ${preferredPort} is busy, using port ${port} instead`);
  }

  server.listen(port, () => {
    console.log(`[api] server listening on port ${port}`);
  });
}

startServer().catch(console.error);
