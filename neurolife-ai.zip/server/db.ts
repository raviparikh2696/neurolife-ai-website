import { and, desc, eq, gte, isNotNull, isNull, like, lte, or } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import {
  chatMessages,
  events,
  groceryItems,
  InsertChatMessage,
  InsertEvent,
  InsertGroceryItem,
  InsertMeeting,
  InsertNote,
  InsertTask,
  InsertUser,
  meetings,
  notes,
  tasks,
  users,
} from "../drizzle/schema";
import { ENV } from "./_core/env";

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = "admin";
      updateSet.role = "admin";
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

// ─── Local Auth Helpers ──────────────────────────────────────────────────────
export async function getUserByEmail(email: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.email, email)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function createLocalUser(data: { name: string; email: string; passwordHash: string }) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const openId = `local:${data.email}`;
  await db.insert(users).values({
    openId,
    name: data.name,
    email: data.email,
    passwordHash: data.passwordHash,
    loginMethod: "email",
    lastSignedIn: new Date(),
  });
  const created = await getUserByOpenId(openId);
  if (!created) throw new Error("Failed to create user");
  return created;
}

export async function updateUserPassword(userId: number, passwordHash: string) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.update(users).set({ passwordHash }).where(eq(users.id, userId));
}

// ─── Tasks ────────────────────────────────────────────────────────────────────
export async function getUserTasks(userId: number, includeCompleted = false) {
  const db = await getDb();
  if (!db) return [];
  const conditions = [eq(tasks.userId, userId)];
  if (!includeCompleted) conditions.push(eq(tasks.completed, false));
  return db.select().from(tasks).where(and(...conditions)).orderBy(desc(tasks.createdAt));
}
export async function createTask(data: InsertTask) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(tasks).values(data);
  return result[0].insertId;
}
export async function updateTask(id: number, userId: number, data: Partial<InsertTask>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.update(tasks).set(data).where(and(eq(tasks.id, id), eq(tasks.userId, userId)));
}
export async function deleteTask(id: number, userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.delete(tasks).where(and(eq(tasks.id, id), eq(tasks.userId, userId)));
}

// ─── Events ───────────────────────────────────────────────────────────────────
export async function getUserEvents(userId: number, startDate?: Date, endDate?: Date) {
  const db = await getDb();
  if (!db) return [];
  const conditions = [eq(events.userId, userId)];
  if (startDate) conditions.push(gte(events.startTime, startDate));
  if (endDate) conditions.push(lte(events.startTime, endDate));
  return db.select().from(events).where(and(...conditions)).orderBy(events.startTime);
}
export async function createEvent(data: InsertEvent) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(events).values(data);
  return result[0].insertId;
}
export async function updateEvent(id: number, userId: number, data: Partial<InsertEvent>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.update(events).set(data).where(and(eq(events.id, id), eq(events.userId, userId)));
}
export async function deleteEvent(id: number, userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.delete(events).where(and(eq(events.id, id), eq(events.userId, userId)));
}

// ─── Grocery Items ────────────────────────────────────────────────────────────
export async function getUserGroceries(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(groceryItems).where(and(eq(groceryItems.userId, userId), isNull(groceryItems.deletedAt))).orderBy(groceryItems.category, groceryItems.name);
}
export async function createGroceryItem(data: InsertGroceryItem) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(groceryItems).values(data);
  return result[0].insertId;
}
export async function updateGroceryItem(id: number, userId: number, data: Partial<InsertGroceryItem>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.update(groceryItems).set(data).where(and(eq(groceryItems.id, id), eq(groceryItems.userId, userId)));
}
export async function deleteGroceryItem(id: number, userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.delete(groceryItems).where(and(eq(groceryItems.id, id), eq(groceryItems.userId, userId)));
}
export async function softDeleteGroceryItem(id: number, userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.update(groceryItems).set({ deletedAt: new Date() }).where(and(eq(groceryItems.id, id), eq(groceryItems.userId, userId)));
}
export async function restoreGroceryItem(id: number, userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.update(groceryItems).set({ deletedAt: null }).where(and(eq(groceryItems.id, id), eq(groceryItems.userId, userId)));
}
export async function getDeletedGroceries(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(groceryItems).where(and(eq(groceryItems.userId, userId), isNotNull(groceryItems.deletedAt))).orderBy(desc(groceryItems.updatedAt));
}
export async function clearPurchasedGroceries(userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.delete(groceryItems).where(and(eq(groceryItems.userId, userId), eq(groceryItems.purchased, true)));
}

// ─── Notes ────────────────────────────────────────────────────────────────────
export async function getUserNotes(userId: number, category?: string, search?: string) {
  const db = await getDb();
  if (!db) return [];
  const conditions = [eq(notes.userId, userId)];
  if (category && category !== "all") conditions.push(eq(notes.category, category as "note" | "voice" | "idea" | "meeting" | "general"));
  if (search) conditions.push(or(like(notes.title, `%${search}%`), like(notes.content, `%${search}%`))!);
  return db.select().from(notes).where(and(...conditions)).orderBy(desc(notes.createdAt));
}
export async function createNote(data: InsertNote) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(notes).values(data);
  return result[0].insertId;
}
export async function updateNote(id: number, userId: number, data: Partial<InsertNote>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.update(notes).set(data).where(and(eq(notes.id, id), eq(notes.userId, userId)));
}
export async function deleteNote(id: number, userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.delete(notes).where(and(eq(notes.id, id), eq(notes.userId, userId)));
}

// ─── Meetings ─────────────────────────────────────────────────────────────────
export async function getUserMeetings(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(meetings).where(eq(meetings.userId, userId)).orderBy(desc(meetings.date));
}
export async function createMeeting(data: InsertMeeting) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(meetings).values(data);
  return result[0].insertId;
}
export async function updateMeeting(id: number, userId: number, data: Partial<InsertMeeting>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.update(meetings).set(data).where(and(eq(meetings.id, id), eq(meetings.userId, userId)));
}
export async function deleteMeeting(id: number, userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.delete(meetings).where(and(eq(meetings.id, id), eq(meetings.userId, userId)));
}

// ─── Chat Messages ────────────────────────────────────────────────────────────
export async function getUserChatHistory(userId: number, limit = 50) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(chatMessages).where(eq(chatMessages.userId, userId)).orderBy(chatMessages.createdAt).limit(limit);
}
export async function saveChatMessage(data: InsertChatMessage) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(chatMessages).values(data);
  return result[0].insertId;
}
export async function clearChatHistory(userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.delete(chatMessages).where(eq(chatMessages.userId, userId));
}
