import { z } from "zod";
import { TRPCError } from "@trpc/server";
import { COOKIE_NAME } from "../shared/const.js";
import { getSessionCookieOptions } from "./_core/cookies";
import { invokeLLM } from "./_core/llm";
import { systemRouter } from "./_core/systemRouter";
import { transcribeAudio } from "./_core/voiceTranscription";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import * as db from "./db";

/**
 * Extract plain text from an LLM response content that may be a string
 * or an array of content parts (e.g. when thinking is enabled, the model
 * returns [{type:"thinking",thinking:"..."},{type:"text",text:"..."}]).
 * We only want the "text" part for downstream processing.
 */
function extractTextContent(content: unknown): string {
  if (typeof content === "string") return content;
  if (Array.isArray(content)) {
    // Find the first text part
    const textPart = content.find((p: any) => p?.type === "text");
    if (textPart && typeof textPart.text === "string") return textPart.text;
    // Fallback: concatenate all string-like parts
    return content
      .filter((p: any) => p?.type === "text" || typeof p === "string")
      .map((p: any) => (typeof p === "string" ? p : p.text ?? ""))
      .join("");
  }
  return JSON.stringify(content);
}

const taskSchema = z.object({
  title: z.string().min(1).max(500),
  notes: z.string().optional(),
  priority: z.enum(["low", "medium", "high"]).default("medium"),
  dueDate: z.string().optional(),
});

const eventSchema = z.object({
  title: z.string().min(1).max(500),
  description: z.string().optional(),
  startTime: z.string(),
  endTime: z.string().optional(),
  location: z.string().optional(),
  people: z.array(z.string()).optional(),
  project: z.string().optional(),
});

const grocerySchema = z.object({
  name: z.string().min(1).max(255),
  category: z.enum(["fruits", "dairy", "vegetables", "bakery", "meat", "pantry", "beverages", "other"]).default("other"),
  quantity: z.string().optional(),
});

const noteSchema = z.object({
  title: z.string().min(1).max(500),
  content: z.string().optional(),
  category: z.enum(["note", "voice", "idea", "meeting", "general"]).default("note"),
  audioUrl: z.string().optional(),
  transcription: z.string().optional(),
  tags: z.array(z.string()).optional(),
});

const meetingSchema = z.object({
  title: z.string().min(1).max(500),
  date: z.string(),
  people: z.array(z.string()).optional(),
  project: z.string().optional(),
  audioUrl: z.string().optional(),
  transcription: z.string().optional(),
  summary: z.string().optional(),
});

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query((opts) => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),

    register: publicProcedure
      .input(z.object({
        name: z.string().min(1).max(100),
        email: z.string().email(),
        password: z.string().min(6).max(128),
      }))
      .mutation(async ({ ctx, input }) => {
        // Check if email already taken
        const existing = await db.getUserByEmail(input.email);
        if (existing) throw new TRPCError({ code: "CONFLICT", message: "An account with this email already exists." });

        // Hash password using Node crypto (PBKDF2)
        const { createHash, randomBytes, pbkdf2Sync } = await import("node:crypto");
        const salt = randomBytes(16).toString("hex");
        const hash = pbkdf2Sync(input.password, salt, 100_000, 64, "sha512").toString("hex");
        const passwordHash = `${salt}:${hash}`;

        // Create user
        const user = await db.createLocalUser({ name: input.name, email: input.email, passwordHash });

        // Create session token
        const { sdk } = await import("./_core/sdk");
        const { ONE_YEAR_MS } = await import("../shared/const.js");
        const sessionToken = await sdk.createSessionToken(user.openId, { name: user.name || "", expiresInMs: ONE_YEAR_MS });

        // Set cookie for web
        const cookieOptions = getSessionCookieOptions(ctx.req);
        ctx.res.cookie(COOKIE_NAME, sessionToken, { ...cookieOptions, maxAge: ONE_YEAR_MS });

        return {
          sessionToken,
          user: { id: user.id, openId: user.openId, name: user.name, email: user.email, loginMethod: user.loginMethod, lastSignedIn: user.lastSignedIn.toISOString() },
        };
      }),

    login: publicProcedure
      .input(z.object({
        email: z.string().email(),
        password: z.string().min(1),
      }))
      .mutation(async ({ ctx, input }) => {
        const user = await db.getUserByEmail(input.email);
        if (!user || !user.passwordHash) throw new TRPCError({ code: "UNAUTHORIZED", message: "Invalid email or password." });

        // Verify password
        const { pbkdf2Sync } = await import("node:crypto");
        const [salt, storedHash] = user.passwordHash.split(":");
        if (!salt || !storedHash) throw new TRPCError({ code: "UNAUTHORIZED", message: "Invalid email or password." });
        const hash = pbkdf2Sync(input.password, salt, 100_000, 64, "sha512").toString("hex");
        if (hash !== storedHash) throw new TRPCError({ code: "UNAUTHORIZED", message: "Invalid email or password." });

        // Update lastSignedIn
        await db.upsertUser({ openId: user.openId, lastSignedIn: new Date() });

        // Create session token
        const { sdk } = await import("./_core/sdk");
        const { ONE_YEAR_MS } = await import("../shared/const.js");
        const sessionToken = await sdk.createSessionToken(user.openId, { name: user.name || "", expiresInMs: ONE_YEAR_MS });

        // Set cookie for web
        const cookieOptions = getSessionCookieOptions(ctx.req);
        ctx.res.cookie(COOKIE_NAME, sessionToken, { ...cookieOptions, maxAge: ONE_YEAR_MS });

        return {
          sessionToken,
          user: { id: user.id, openId: user.openId, name: user.name, email: user.email, loginMethod: user.loginMethod, lastSignedIn: user.lastSignedIn.toISOString() },
        };
      }),
  }),

  tasks: router({
    list: protectedProcedure
      .input(z.object({ includeCompleted: z.boolean().optional() }))
      .query(({ ctx, input }) => db.getUserTasks(ctx.user.id, input.includeCompleted ?? false)),
    create: protectedProcedure.input(taskSchema).mutation(({ ctx, input }) =>
      db.createTask({ userId: ctx.user.id, title: input.title, notes: input.notes, priority: input.priority, dueDate: input.dueDate ? new Date(input.dueDate) : undefined })
    ),
    update: protectedProcedure
      .input(z.object({ id: z.number(), title: z.string().optional(), notes: z.string().optional(), priority: z.enum(["low", "medium", "high"]).optional(), dueDate: z.string().optional(), completed: z.boolean().optional(), completedAt: z.string().optional(), notificationIds: z.string().optional() }))
      .mutation(({ ctx, input }) => {
        const { id, dueDate, completedAt, ...rest } = input;
        return db.updateTask(id, ctx.user.id, { ...rest, dueDate: dueDate ? new Date(dueDate) : undefined, completedAt: completedAt ? new Date(completedAt) : undefined });
      }),
    delete: protectedProcedure.input(z.object({ id: z.number() })).mutation(({ ctx, input }) => db.deleteTask(input.id, ctx.user.id)),
  }),

  events: router({
    list: protectedProcedure
      .input(z.object({ startDate: z.string().optional(), endDate: z.string().optional() }))
      .query(({ ctx, input }) => db.getUserEvents(ctx.user.id, input.startDate ? new Date(input.startDate) : undefined, input.endDate ? new Date(input.endDate) : undefined)),
    create: protectedProcedure.input(eventSchema).mutation(({ ctx, input }) =>
      db.createEvent({ userId: ctx.user.id, title: input.title, description: input.description, startTime: new Date(input.startTime), endTime: input.endTime ? new Date(input.endTime) : undefined, location: input.location, people: input.people ? JSON.stringify(input.people) : undefined, project: input.project })
    ),
    update: protectedProcedure
      .input(z.object({ id: z.number(), title: z.string().optional(), description: z.string().optional(), startTime: z.string().optional(), endTime: z.string().optional(), location: z.string().optional(), people: z.array(z.string()).optional(), project: z.string().optional(), notificationIds: z.string().optional() }))
      .mutation(({ ctx, input }) => {
        const { id, startTime, endTime, people, ...rest } = input;
        return db.updateEvent(id, ctx.user.id, { ...rest, startTime: startTime ? new Date(startTime) : undefined, endTime: endTime ? new Date(endTime) : undefined, people: people ? JSON.stringify(people) : undefined });
      }),
    delete: protectedProcedure.input(z.object({ id: z.number() })).mutation(({ ctx, input }) => db.deleteEvent(input.id, ctx.user.id)),
  }),

  groceries: router({
    list: protectedProcedure.query(({ ctx }) => db.getUserGroceries(ctx.user.id)),
    create: protectedProcedure.input(grocerySchema).mutation(({ ctx, input }) => db.createGroceryItem({ userId: ctx.user.id, ...input })),
    createMany: protectedProcedure.input(z.array(grocerySchema)).mutation(async ({ ctx, input }) => Promise.all(input.map((item) => db.createGroceryItem({ userId: ctx.user.id, ...item })))),
    update: protectedProcedure
      .input(z.object({ id: z.number(), name: z.string().optional(), category: z.enum(["fruits", "dairy", "vegetables", "bakery", "meat", "beverages", "other"]).optional(), quantity: z.string().optional(), purchased: z.boolean().optional() }))
      .mutation(({ ctx, input }) => { const { id, ...data } = input; return db.updateGroceryItem(id, ctx.user.id, data); }),
    delete: protectedProcedure.input(z.object({ id: z.number() })).mutation(({ ctx, input }) => db.softDeleteGroceryItem(input.id, ctx.user.id)),
    restore: protectedProcedure.input(z.object({ id: z.number() })).mutation(({ ctx, input }) => db.restoreGroceryItem(input.id, ctx.user.id)),
    listDeleted: protectedProcedure.query(({ ctx }) => db.getDeletedGroceries(ctx.user.id)),
    clearPurchased: protectedProcedure.mutation(({ ctx }) => db.clearPurchasedGroceries(ctx.user.id)),
  }),

  notes: router({
    list: protectedProcedure
      .input(z.object({ category: z.string().optional(), search: z.string().optional() }))
      .query(({ ctx, input }) => db.getUserNotes(ctx.user.id, input.category, input.search)),
    create: protectedProcedure.input(noteSchema).mutation(({ ctx, input }) =>
      db.createNote({ userId: ctx.user.id, title: input.title, content: input.content, category: input.category, audioUrl: input.audioUrl, transcription: input.transcription, tags: input.tags ? JSON.stringify(input.tags) : undefined })
    ),
    update: protectedProcedure
      .input(z.object({ id: z.number(), title: z.string().optional(), content: z.string().optional(), category: z.enum(["note", "voice", "idea", "meeting", "general"]).optional(), audioUrl: z.string().optional(), transcription: z.string().optional(), tags: z.array(z.string()).optional(), pinned: z.boolean().optional() }))
      .mutation(({ ctx, input }) => { const { id, tags, ...rest } = input; return db.updateNote(id, ctx.user.id, { ...rest, tags: tags ? JSON.stringify(tags) : undefined }); }),
    delete: protectedProcedure.input(z.object({ id: z.number() })).mutation(({ ctx, input }) => db.deleteNote(input.id, ctx.user.id)),
  }),

  meetings: router({
    list: protectedProcedure.query(({ ctx }) => db.getUserMeetings(ctx.user.id)),
    create: protectedProcedure.input(meetingSchema).mutation(({ ctx, input }) =>
      db.createMeeting({ userId: ctx.user.id, title: input.title, date: new Date(input.date), people: input.people ? JSON.stringify(input.people) : undefined, project: input.project, audioUrl: input.audioUrl, transcription: input.transcription, summary: input.summary })
    ),
    update: protectedProcedure
      .input(z.object({ id: z.number(), title: z.string().optional(), date: z.string().optional(), people: z.array(z.string()).optional(), project: z.string().optional(), audioUrl: z.string().optional(), transcription: z.string().optional(), summary: z.string().optional() }))
      .mutation(({ ctx, input }) => { const { id, date, people, ...rest } = input; return db.updateMeeting(id, ctx.user.id, { ...rest, date: date ? new Date(date) : undefined, people: people ? JSON.stringify(people) : undefined }); }),
    delete: protectedProcedure.input(z.object({ id: z.number() })).mutation(({ ctx, input }) => db.deleteMeeting(input.id, ctx.user.id)),
  }),

  ai: router({
    classify: protectedProcedure
      .input(z.object({ text: z.string(), tzOffset: z.number().optional() }))
      .mutation(async ({ input }) => {
        // Build local date/time using user's timezone offset (minutes behind UTC, from JS getTimezoneOffset())
        const offsetMin = input.tzOffset ?? 0;
        const localMs = Date.now() - offsetMin * 60 * 1000;
        const localDate = new Date(localMs);
        const pad = (n: number) => String(n).padStart(2, "0");
        const localDateStr = `${localDate.getUTCFullYear()}-${pad(localDate.getUTCMonth()+1)}-${pad(localDate.getUTCDate())}`;
        const localTimeStr = `${pad(localDate.getUTCHours())}:${pad(localDate.getUTCMinutes())}`;
        const sign = offsetMin <= 0 ? "+" : "-";
        const absMin = Math.abs(offsetMin);
        const tzStr = `${sign}${pad(Math.floor(absMin/60))}:${pad(absMin%60)}`;
        const response = await invokeLLM({
          messages: [
            { role: "system", content: `You are NeuroLife AI. The user's local date is ${localDateStr} and time is ${localTimeStr} (timezone UTC${tzStr}). Analyze the user input and return JSON: {"intent":"task"|"event"|"grocery"|"note"|"meeting"|"query"|"general","title":"string","dueDate":"YYYY-MM-DD or null (use user local date, NOT ISO with time)","time":"HH:MM 24h or null","people":[],"items":[],"priority":"low"|"medium"|"high","response":"friendly message"}. RULES: dueDate must be YYYY-MM-DD only (no T, no Z, no time). If user says 'today' use ${localDateStr}. If user says '2pm' set time to '14:00'. If user says '2pm today' set dueDate to ${localDateStr} and time to '14:00'.` },
            { role: "user", content: input.text },
          ],
          response_format: { type: "json_object" },
        });
        const content = extractTextContent(response.choices[0].message.content);
        return JSON.parse(content);
      }),
    chat: protectedProcedure
      .input(z.object({ message: z.string(), history: z.array(z.object({ role: z.enum(["user", "assistant"]), content: z.string() })).optional() }))
      .mutation(async ({ ctx, input }) => {
        const [userTasks, userEvents, userGroceries, userNotes] = await Promise.all([
          db.getUserTasks(ctx.user.id, false),
          db.getUserEvents(ctx.user.id, new Date(), new Date(Date.now() + 7 * 24 * 60 * 60 * 1000)),
          db.getUserGroceries(ctx.user.id),
          db.getUserNotes(ctx.user.id),
        ]);
        const today = new Date().toISOString();
        const ctx_summary = `Today: ${today}\nPending Tasks: ${userTasks.slice(0,5).map(t=>`"${t.title}" (${t.priority})`).join(", ")}\nUpcoming Events: ${userEvents.slice(0,5).map(e=>`"${e.title}" at ${e.startTime.toISOString()}`).join(", ")}\nGroceries: ${userGroceries.filter(g=>!g.purchased).slice(0,10).map(g=>g.name).join(", ")}\nNotes: ${userNotes.slice(0,3).map(n=>`"${n.title}"`).join(", ")}`;
        const messages: { role: "system" | "user" | "assistant"; content: string }[] = [
          { role: "system", content: `You are NeuroLife AI, a personal life organizer. User data:\n${ctx_summary}\nAnswer questions concisely. Be helpful and friendly.` },
          ...(input.history ?? []),
          { role: "user", content: input.message },
        ];
        const response = await invokeLLM({ messages });
        const text = extractTextContent(response.choices[0].message.content);
        await db.saveChatMessage({ userId: ctx.user.id, role: "user", content: input.message });
        await db.saveChatMessage({ userId: ctx.user.id, role: "assistant", content: text });
        return { text };
      }),

    chatHistory: protectedProcedure.query(({ ctx }) => db.getUserChatHistory(ctx.user.id)),
    clearHistory: protectedProcedure.mutation(({ ctx }) => db.clearChatHistory(ctx.user.id)),

    // Convert audio to structured key-point notes
    audioToKeyPoints: protectedProcedure
      .input(z.object({ audioUrl: z.string(), noteType: z.enum(["note", "meeting", "idea"]).default("note") }))
      .mutation(async ({ input }) => {
        // Step 1: Transcribe the audio
        const transcription = await transcribeAudio({ audioUrl: input.audioUrl, language: "en" });
        if ("error" in transcription) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: transcription.error });
        const rawText = transcription.text;

        // Step 2: Use LLM to extract key points
        const systemPrompts: Record<string, string> = {
          note: `You are a note-taking assistant. Extract the key points from this transcript and return JSON: {"title":"concise title","summary":"1-2 sentence summary","keyPoints":["point 1","point 2",...],"tags":["tag1","tag2"]}`,
          meeting: `You are a meeting notes assistant. Extract structured meeting notes from this transcript and return JSON: {"title":"meeting title","summary":"brief summary","keyPoints":["decision or action item 1",...],"attendees":[],"actionItems":["action 1",...],"tags":["meeting"]}`,
          idea: `You are an ideas assistant. Extract and expand the ideas from this transcript and return JSON: {"title":"idea title","summary":"brief description","keyPoints":["key aspect 1",...],"nextSteps":["step 1",...],"tags":["idea"]}`,
        };
        const response = await invokeLLM({
          messages: [
            { role: "system", content: systemPrompts[input.noteType] },
            { role: "user", content: rawText },
          ],
          response_format: { type: "json_object" },
        });
        const parsed = JSON.parse(extractTextContent(response.choices[0].message.content));
        return { transcription: rawText, ...parsed };
      }),
  }),

  voice: router({
    // Upload raw audio bytes (base64) and get back a public URL for transcription
    upload: protectedProcedure
      .input(z.object({ base64: z.string(), mimeType: z.string().default("audio/m4a") }))
      .mutation(async ({ input }) => {
        const { storagePut } = await import("./storage");
        const buffer = Buffer.from(input.base64, "base64");
        const ext = input.mimeType.split("/")[1]?.split(";")[0] ?? "m4a";
        const key = `voice/${Date.now()}.${ext}`;
        const { url } = await storagePut(key, buffer, input.mimeType);
        return { url };
      }),
    transcribe: protectedProcedure
      .input(z.object({ audioUrl: z.string(), language: z.string().optional() }))
      .mutation(async ({ input }) => {
        const result = await transcribeAudio({ audioUrl: input.audioUrl, language: input.language ?? "en" });
        if ("error" in result) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: result.error });
        return { text: result.text };
      }),
  }),
});

export type AppRouter = typeof appRouter;
