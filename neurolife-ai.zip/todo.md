# NeuroLife AI — Project TODO

## Core Setup
- [x] Initialize Expo project scaffold
- [x] Port all source files from uploaded zips
- [x] Fix TypeScript errors (JsonSchema, oauth.ts, trpc.ts, llm.ts)
- [x] Fix AdMob native module crash on web (metro resolver stub)
- [x] Fix expo-sharing version mismatch
- [x] Run database migrations (7 tables: tasks, events, groceries, notes, meetings, users, chat_messages)
- [x] Rebuild assistant.tsx (source was truncated in upload)
- [x] Fix expo-audio API (allowsRecording, playsInSilentMode)
- [x] Fix tRPC procedure names (ai.chat, voice.transcribe, voice.upload)
- [x] Add AdMob App IDs to app.config.ts
- [x] Set up 7-tab navigation (Home, Tasks, Calendar, Groceries, Memory, AI, Settings)

## Screens
- [x] Home screen (daily dashboard, greeting, quick actions)
- [x] Tasks screen (task manager with priorities)
- [x] Calendar screen (weekly strip + daily timeline)
- [x] Groceries screen (smart grocery list)
- [x] Memory screen (notes + voice recordings)
- [x] Assistant screen (AI chat with voice input)
- [x] Settings screen (theme, notifications, sign out)
- [x] Sign In screen
- [x] Sign Up screen
- [x] Note Detail screen

## Pending (Round 8 from original todo)
- [ ] Upgrade LLM to latest model (gemini-2.0-pro or equivalent)
- [ ] Add streaming support to chat (real-time token display)
- [ ] Add thinking/reasoning display for complex queries
- [ ] Improved AI classification (task/event/grocery/note intent detection)
- [ ] Conversation context memory across sessions
- [ ] End-to-end testing

## Round 2 — Multi-user, AI Sync, Full CRUD, Fast UI
- [x] Multi-user auth: per-user data isolation via userId on all DB tables
- [x] Multi-user auth: logout clears QueryClient cache (no data leakage between users)
- [x] AI chat: full intent classification (task/event/grocery/note/meeting/query)
- [x] AI chat: auto-create tasks/events/groceries/notes from natural language
- [x] AI chat: sync created items to respective screens in real-time (no app restart needed)
- [x] AI chat: modern UI (animated typing dots, action confirmation cards, suggested prompts)
- [x] AI chat: voice recording with transcription (native)
- [x] Tasks: full CRUD with optimistic updates, swipe-to-complete, priority badges
- [x] Calendar: full CRUD events, real-time refresh after AI creates events
- [x] Groceries: full CRUD, sync with AI chat, category grouping, staleTime: 0
- [x] Notes: full CRUD, save properly, voice recording + Smart Notes AI feature
- [x] All screens: staleTime: 0 — instant updates without reopening app
- [x] All screens: refetchOnWindowFocus: true — switching tabs refreshes data
- [x] Home screen: pull-to-refresh fetches all 3 data sources in parallel
- [x] Home screen: live data from all modules (tasks count, upcoming events, grocery count)

## Round 3 — Chat Voice & Prompt Chips
- [x] Fix voice recording in AI chat (added prepareToRecordAsync() before record())
- [x] Remove "Try asking" section from chat
- [x] Add easy prompt chips above the input bar (always visible, horizontal scroll)
- [x] Fix duplicate Content-Type header that broke tRPC login on web
- [x] Downgrade Zod to v3 for tRPC v11 compatibility
- [x] Fix error message display (clean messages instead of raw Zod JSON)
- [x] Verified AI chat works end-to-end (schedule query, grocery creation)
- [x] Verified cross-module sync: AI creates groceries, home counter updates instantly

## Round 4 — Voice Button Fix & Fast Navigation
- [x] Move voice button out of text input row — standalone full-width mic button above input
- [x] Fix navigation from Home quick actions: router.push → router.navigate (instant tab switch)
- [x] All tab screens already have staleTime: 0 and refetchOnWindowFocus: true

## Round 5 — Date/Time Bug Fix
- [x] Fix AI chat date parsing: pass tzOffset to classify, AI returns YYYY-MM-DD, client builds ISO with correct timezone offset

## Round 6 — AI Streaming & Onboarding
- [x] AI streaming: word-by-word response via /api/ai/stream-chat SSE endpoint
- [x] Streaming: blinking cursor (▌) while AI types, transitions to static text when done
- [x] Onboarding: 3-slide first-launch walkthrough (Your Second Brain, AI That Understands You, Stay On Top)
- [x] Onboarding: shown only once, persisted in AsyncStorage (ONBOARDING_DONE_KEY)
- [x] Onboarding: Skip button, animated dot indicators, Get Started CTA on last slide

## Round 7 — Onboarding Mobile Fix
- [x] Fix 3-slide onboarding layout for perfect mobile portrait display (fixed SCREEN_WIDTH/HEIGHT, SafeArea insets, hairline borders, proper FlatList height)

## Round 8 — Chat Prompt Chips Fix
- [x] Fix prompt chips in AI chat: always visible, stays perfectly anchored above input bar with every message

## Round 9 — AdMob App Open Ad Integration
- [x] Install react-native-google-mobile-ads and configure App ID in app.config.ts
- [x] Implement App Open Ad shown when app launches (AppOpenAd)
- [x] Handle foreground/background app state to re-show ad on app resume
- [x] Follow AdMob policies: no ad on top of other ads, cooldown between shows
- [x] Verify 0 TypeScript errors

## Round 10 — Native Advanced Ad on Home Screen
- [x] Build NativeAdView component using NativeAd API (react-native-google-mobile-ads)
- [x] Place native ad below quick actions on Home screen
- [x] AdMob policy compliance: ad label, no deceptive styling, web guard
- [x] Verify 0 TypeScript errors

## Round 11 — Native Ad Refresh on Pull-to-Refresh
- [x] Expose refresh() method on NativeAdCard via useImperativeHandle
- [x] Call adRef.current.refresh() in Home screen onRefresh handler
- [x] Verify 0 TypeScript errors

## Round 12 — Native Advanced Ad on Tasks Screen
- [x] Update NativeAdCard to accept custom adUnitId prop
- [x] Add native ad at bottom of Tasks screen (ad unit: ca-app-pub-1720679341163644/5215120737)
- [x] AdMob policy compliance: ad label, distinct styling, web guard
- [x] Verify 0 TypeScript errors

## Round 13 — Native Advanced Ad on Calendar Screen
- [x] Add native ad at bottom of Calendar screen (ad unit: ca-app-pub-1720679341163644/3232655923)
- [x] AdMob policy compliance: ad label, distinct styling, web guard
- [x] Verify 0 TypeScript errors

## Round 14 — Native Advanced Ad on Notes Screen
- [x] Add native ad footer at bottom of Notes screen (ad unit: ca-app-pub-1720679341163644/5284104196)
- [x] AdMob policy compliance: ad label, distinct styling, web guard
- [x] Verify 0 TypeScript errors

## Round 15 — Fix AI Chat SSE Stream Parser
- [x] Fix AI chat stream parser: correctly assemble delta chunks into readable text
- [x] Verify 0 TypeScript errors

## Round 16 — AdMob Android-Only Guard
- [x] Guard App Open Ad hook: only run on Android (Platform.OS === 'android')
- [x] Guard NativeAdCard component: only render on Android
- [x] Update app.config.ts AdMob plugin: Android App ID only, iOS left blank
- [x] Verify 0 TypeScript errors

## Round 17 — iOS AdMob Integration
- [x] Update app.config.ts: add iOS App ID ca-app-pub-1720679341163644~5246910325, restore iOS ATT description
- [x] App Open Ad: support iOS ad unit ID ca-app-pub-1720679341163644/2465205443 (Platform.OS === 'ios')
- [x] Home screen native ad: iOS ad unit ID ca-app-pub-1720679341163644/6765344858
- [x] Calendar screen native ad: iOS ad unit ID ca-app-pub-1720679341163644/2434950702
- [x] Memory/Notes screen native ad: iOS ad unit ID ca-app-pub-1720679341163644/3807742122
- [x] Tasks screen native ad: iOS ad unit ID ca-app-pub-1720679341163644/4837752761
- [x] Groceries screen native ad: iOS ad unit ID ca-app-pub-1720679341163644/2251384772 (new placement)
- [x] All iOS ads at bottom of each page, Platform.OS === 'ios' guards
- [x] Verify 0 TypeScript errors

## Round 18 — App Store Submission Readiness
- [x] Verify app icons: 1024x1024 (iOS), 512x512 (Android), no transparency
- [x] Verify iOS ATT prompt is implemented and configured
- [x] Create app-ads.txt with AdMob seller code
- [x] Document Android Data Safety requirements (Device IDs, Advertising/Marketing)
- [x] Audit for placeholder content (Coming Soon, Lorem Ipsum)
- [x] Verify AdMob ads load correctly or show proper placeholders
- [x] Verify 0 TypeScript errors
